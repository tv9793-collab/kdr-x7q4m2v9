"""Avvio diretto di un titolo tramite il canale StreamingCommunity (HD, ITA) di Stream for Me.

Flusso: cerca il titolo sul canale (via JSON-RPC verso plugin.video.s4me), sceglie il risultato
ITA con titolo/anno corrispondenti, poi lancia la riproduzione. Nessuna finestra di ricerca canali.
"""
import base64
import json
import re
import threading
import time
import unicodedata
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import progress
import nextep

S4ME = "plugin.video.s4me"
CHANNEL = "streamingcommunity"
BASE = "plugin://%s/?" % S4ME

OK, NOTFOUND, NOSOURCE, FAIL, CANCEL = "ok", "notfound", "nosource", "fail", "cancel"
DOWN = "down"      # il sito non risponde (es. bloccato): non si sa se il titolo c'e'
CB01 = "cb01"      # fonte da usare subito (scelta dall'utente nella ricerca)


def available():
    return xbmc.getCondVisibility("System.HasAddon(%s)" % S4ME)


# ---------- utilita ----------
import sc  # noqa: E402
import cb  # noqa: E402
from sc import host as _host, norm as _norm  # noqa: E402


def _encode(d):
    return BASE + urllib.parse.quote(base64.b64encode(json.dumps(d).encode("utf8")).decode())


def _decode(url):
    try:
        q = url.split("?", 1)[1]
        return json.loads(base64.b64decode(urllib.parse.unquote(q)).decode("utf8"))
    except Exception:
        return {}


def _listdir(url):
    """Elenco file di una cartella plugin (blocca finche' s4me ha finito)."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": url, "media": "files", "properties": ["title"]}}
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return []
    return (r.get("result") or {}).get("files") or []


def _entries(url):
    out = []
    for f in _listdir(url):
        d = _decode(f.get("file", ""))
        if d:
            out.append((f.get("file"), d))
    return out


def _title_ok(cand, e):
    c = _norm(cand)
    return bool(c) and c in (_norm(e.get("title")), _norm(e.get("orig")))


def _year_ok(d, e):
    try:
        y1, y2 = int(d.get("year") or (d.get("infoLabels") or {}).get("year") or 0), int(e.get("year") or 0)
    except Exception:
        return True
    return not y1 or not y2 or abs(y1 - y2) <= 1


def pick(entries, e):
    """Sceglie tra i risultati del canale: stesso tipo, ITA (non Sub-ITA), stesso titolo, anno compatibile."""
    want = "tvshow" if e["type"] == "tv" else "movie"
    best = None
    for url, d in entries:
        if d.get("contentType") != want:
            continue
        if (d.get("language") or "").strip().upper() != "ITA":
            continue
        if d.get("action") not in ("findvideos", "episodios"):
            continue
        name = d.get("fulltitle") or d.get("contentTitle") or d.get("contentSerieName") or ""
        if not (_title_ok(name, e) and _year_ok(d, e)):
            continue
        exact = _norm(name) == _norm(e.get("title"))
        score = 2 if exact else 1
        if best is None or score > best[0]:
            best = (score, url, d)
    return (best[1], best[2]) if best else (None, None)


def search_channel(e, status=None):
    host = _host()
    if not host:
        return None, None
    terms = [e["title"]]
    if e.get("orig") and _norm(e["orig"]) != _norm(e["title"]):
        terms.append(e["orig"])
    for t in terms:
        if status:
            status('Cerco "%s"...' % t)
        item = {"channel": CHANNEL, "action": "peliculas", "search": True, "folder": True,
                "contentType": "tvshow" if e["type"] == "tv" else "movie",
                "url": "%s/it/search?q=%s" % (host, urllib.parse.quote(t))}
        url, d = pick(_entries(_encode(item)), e)
        if url:
            return url, d
    return None, None


# risposta da dare al dialogo "Riprendi" di Stream for Me: 3012 = riprendi, 3013 = dall'inizio.
# Se il punto di visione lo gestisce Addò-flix (piu' aggiornato, salvato anche in caso di crash)
# si sceglie "dall'inizio" e poi Addò-flix porta il video al punto giusto.
# skip = quanti server buoni saltare (nuovo tentativo dopo un server rotto); err = s4me ha mostrato
# un errore (es. "il file non esiste"); nohd = nella lista non c'era nessun server HD.
_s4me = {"choice": 3012, "skip": 0, "err": False, "nohd": False}
SERVER_LIST = 6   # lista dei server di Stream for Me (finestra DialogSelect.xml aperta da s4me)


def _labels(cid):
    try:
        n = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    except Exception:
        n = 0
    return [xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, i)) for i in range(n)]


def _choose(cid, idx):
    xbmc.executebuiltin("SetFocus(%d,%d)" % (cid, idx))
    xbmc.sleep(250)
    xbmc.executebuiltin("Action(Select)")
    xbmc.sleep(800)


def server_choice(labels, skip=0):
    """Indice del server da avviare nella lista di s4me, None se non ce n'e' uno buono.
    Mai i server [SD] ne' le voci che non sono server (videoteca, download); prima quelli [HD]."""
    good = []
    for i, l in enumerate(labels):
        low = l.lower()
        if "[color" in low or "videoteca" in low or "download" in low or not l.strip():
            continue
        if cb.tags(l) and not cb.is_hd(l):
            continue  # [SD] o altra qualita' bassa
        good.append(i)
    good.sort(key=lambda i: 0 if cb.is_hd(labels[i]) else 1)
    return good[skip] if skip < len(good) else None


def _auto_choose():
    """Risponde da solo ai dialoghi di s4me: lista 'Riproduci ...' (sceglie HD), lista dei server
    (sceglie un server HD), errori del server (li chiude) e 'Riprendi'
    (altrimenti s4me aspetterebbe fino a 10 secondi)."""
    if xbmc.getCondVisibility("Window.IsActive(ResumePlayback.xml)"):
        xbmc.executebuiltin("SetFocus(%d)" % _s4me["choice"])
        xbmc.sleep(150)
        xbmc.executebuiltin("Action(Select)")
        xbmc.sleep(400)
        return
    if xbmc.getCondVisibility("Window.IsActive(yesnodialog) | Window.IsActive(okdialog)"):
        # errore di s4me (server rotto, file cancellato): si chiude e si prova un altro server
        _s4me["err"] = True
        xbmc.executebuiltin("Action(Back)")
        xbmc.sleep(500)
        return
    if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        labels = _labels(3)
        play = [i for i, l in enumerate(labels) if l.lower().startswith("riproduci")]
        if play:
            hd = [i for i in play if "hd" in labels[i].lower() and "sd" not in labels[i].lower().replace("hd", "")]
            _choose(3, (hd or play)[0])
            return
    labels = _labels(SERVER_LIST)
    if not labels:
        return  # e' un'altra finestra: la lasciamo all'utente
    idx = server_choice(labels, _s4me["skip"])
    if idx is None:
        _s4me["nohd"] = True
        xbmc.executebuiltin("Action(Back)")
        xbmc.sleep(500)
        return
    _choose(SERVER_LIST, idx)


def _close_server_list(timeout=6.0):
    """Se il video si ferma prima della fine, Stream for Me riapre la sua lista dei server (CB01):
    la si chiude, cosi' si torna alla scheda di Addò-flix."""
    mon = xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if xbmc.Player().isPlaying():
            return
        if xbmc.getCondVisibility("Window.IsActive(DialogSelect.xml)") and _labels(SERVER_LIST):
            xbmc.executebuiltin("Action(Back)")
            return
        mon.waitForAbort(0.3)


def _wait_playing(timeout=50):
    mon = xbmc.Monitor()
    player = xbmc.Player()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if player.isPlaying():
            return True
        _auto_choose()
        if _s4me["err"] or _s4me["nohd"]:
            mon.waitForAbort(1.0)
            return player.isPlaying()
        mon.waitForAbort(0.5)
    return False


_SXE = (re.compile(r"(?<!\d)(\d{1,2})\s*[xX]\s*(\d{1,3})(?!\d)"),            # 1x01
        re.compile(r"[Ss](?:tagione)?\s*0*(\d{1,2})\s*[Ee](?:pisodio)?\s*0*(\d{1,3})"))  # S01E01 / Stagione 1 Episodio 1


def _sxe(title):
    for rx in _SXE:
        m = rx.search(title or "")
        if m:
            return int(m.group(1)), int(m.group(2))
    return 0, 0


def fix_numbers(eps):
    """s4me a volte da' stagione/episodio 0 (quando le sue ricerche TMDB falliscono) ma il numero
    e' nel titolo ('1x01 - ...'): senza questo l'episodio scelto non si trova e si apre la lista."""
    out = []
    for x in eps:
        s, n = x[0], x[1]
        if not s or not n:
            ts, tn = _sxe(x[3])
            s, n = s or ts, n or tn
        out.append([s, n, x[2], x[3]])
    out.sort(key=lambda x: (x[0], x[1]))
    return out


def _episodes(e, show_url, status=None, fresh=False):
    """Elenco episodi [[stagione, episodio, url, titolo]], memorizzato per un giorno."""
    k = "eps:%s" % e["id"]
    eps = None if fresh else progress.link_get(k, progress.LIST_TTL)
    if eps:
        return fix_numbers(eps)
    if status:
        status("Carico gli episodi...")

    def num(d, *names):
        for n in names:
            try:
                return int(d.get(n) or 0)
            except Exception:
                pass
        return 0

    eps = []
    for u, d in _entries(show_url):
        if d.get("action") != "findvideos":
            continue
        s, n = num(d, "contentSeason", "season"), num(d, "contentEpisodeNumber", "episode")
        t = re.sub(r"\[/?[^\]]*\]", "", d.get("title", "")).strip()
        eps.append([s, n, u, t or "Episodio %d" % n])
    eps = fix_numbers(eps)
    if eps:
        progress.link_put(k, eps)
    return eps


def _choose_episode(eps, want=None):
    """Dialoghi stagione/episodio; 'want' = episodio da proporre gia' selezionato."""
    seasons = sorted({x[0] for x in eps})
    s = seasons[0]
    if want and want.get("s") in seasons:
        s = want["s"]
    if len(seasons) > 1:
        i = xbmcgui.Dialog().select("Stagione", ["Stagione %d" % x for x in seasons], preselect=seasons.index(s))
        if i < 0:
            return CANCEL, None
        s = seasons[i]
    lst = [x for x in eps if x[0] == s]
    pre = 0
    if want and want.get("s") == s:
        pre = next((i for i, x in enumerate(lst) if x[1] == want.get("e")), 0)
    i = xbmcgui.Dialog().select("Stagione %d" % s, [x[3] for x in lst], preselect=pre)
    if i < 0:
        return CANCEL, None
    x = lst[i]
    return x[2], {"s": x[0], "e": x[1], "title": x[3]}


def _resolve(e, status=None, fresh=False, want=None, ask=True):
    """Trova il collegamento s4me da avviare. Ritorna (esito, url, episodio).
    Usa i collegamenti memorizzati (avvio rapido) salvo fresh=True."""
    k = progress.key(e)
    if e["type"] == "movie" and not fresh:
        url = progress.link_get(k)
        if url:
            return OK, url, None
    show = None if fresh else progress.link_get("show:%s" % e["id"])
    if not show:
        if not sc.reachable():
            # sito bloccato: la ricerca di s4me fallirebbe (con una sua finestra di errore)
            return DOWN, None, None
        url, d = search_channel(e, status)
        if not url:
            return NOTFOUND, None, None
        if d.get("action") == "findvideos":
            m = re.search(r"/watch/(\d+)", d.get("url") or "")
            if m and sc.movie_playable(int(m.group(1))) is False:
                return NOTFOUND, None, None  # titolo nel catalogo ma senza video disponibile
            progress.link_put(k, url)
            return OK, url, None
        show = url
        progress.link_put("show:%s" % e["id"], show)
    eps = _episodes(e, show, status, fresh)
    return _pick_episode(eps, want, ask)


def _pick_episode(eps, want, ask):
    if not eps:
        return NOTFOUND, None, None
    if want and not ask:  # stesso episodio, senza dialoghi (riavvio dopo un errore)
        for x in eps:
            if x[0] == want.get("s") and x[1] == want.get("e"):
                return OK, x[2], {"s": x[0], "e": x[1], "title": x[3]}
    url, ep = _choose_episode(eps, want)
    if url == CANCEL:
        return CANCEL, None, None
    return OK, url, ep


# ---------- CB01 (seconda fonte: solo HD, solo italiano) ----------
def _resolve_cb(e, status=None, fresh=False, want=None, ask=True):
    k = progress.key(e)
    if e["type"] == "movie":
        url = None if fresh else progress.link_get("cb:" + k)
        if url:
            return OK, url, None
    show = None if fresh else progress.link_get("cbshow:%s" % e["id"])
    if not show:
        url, d = cb.find(e, status)
        if not url:
            return (DOWN if d is False else NOTFOUND), None, None
        if e["type"] == "movie":
            progress.link_put("cb:" + k, url)
            return OK, url, None
        show = url
        progress.link_put("cbshow:%s" % e["id"], show)
    eps = None if fresh else progress.link_get("cbeps:%s" % e["id"], progress.LIST_TTL)
    if not eps:
        if status:
            status("Carico gli episodi...")
        eps = fix_numbers(cb.episodes(show) or [])
        eps = [x for x in eps if x[0] and x[1]]
        if eps:
            progress.link_put("cbeps:%s" % e["id"], eps)
    return _pick_episode(fix_numbers(eps), want, ask)


def _play_cb(e, url, ep, start, status=None):
    """Prova i server HD della lista uno dopo l'altro (un server puo' avere il file cancellato)."""
    try:
        for attempt in range(3):
            _s4me["skip"] = attempt
            if attempt and status:
                status("Provo un altro server HD...")
            res = _play(e, url, ep, start, status)
            if res == OK or not _s4me["err"]:
                return res  # partito, oppure nessun altro server HD da provare
        return FAIL
    finally:
        _s4me["skip"] = 0


_ctx = {}   # scelte gia' fatte nel tentativo su StreamingCommunity (punto di ripresa, episodio)


def _watch_cb(e, status=None, episode=None, ctx=None):
    series = e["type"] == "tv"
    start, want, ask = 0, None, True
    if episode and series:
        want, start, ask = {"s": episode["s"], "e": episode["e"]}, int(episode.get("start") or 0), False
    elif ctx and ctx.get("asked"):
        start, want = ctx.get("start") or 0, ctx.get("want")
        ask = not start  # si stava riprendendo: stesso episodio, senza dialoghi
    else:
        saved = progress.get(e)
        if saved:
            r = _ask_resume(saved, series)
            if r is None:
                return CANCEL
            want = saved.get("ep")
            if r:
                start = saved["pos"]
                ask = not series
            elif not series:
                start = 0
    _s4me["choice"] = 3013  # il punto di visione lo gestisce Addò-flix
    rc, url, ep = _resolve_cb(e, status, want=want, ask=ask if series else True)
    if rc != OK:
        return rc
    if want and ep and (ep.get("s"), ep.get("e")) != (want.get("s"), want.get("e")):
        start = 0  # altro episodio: dall'inizio
    res = _play_cb(e, url, ep, start, status)
    if res == FAIL and e["type"] == "movie":
        progress.link_drop("cb:" + progress.key(e))
    return res


def _cb(e, status=None, episode=None, ctx=None):
    res = _watch_cb(e, status, episode, ctx)
    if res == OK:
        sc.mark(e, True, "cb")
    elif res in (NOTFOUND, FAIL):
        sc.mark(e, False, "cb")  # su CB01 non c'e' (o nessun server HD funziona)
    return res




def _ask_resume(v, series):
    """True = riprendi, False = dall'inizio / altro episodio, None = annullato."""
    if progress.setting("resume", "ask") == "auto":
        return True
    other = "Scegli un altro episodio" if series else "Guarda dall'inizio"
    i = xbmcgui.Dialog().select("Addò-flix", ["Riprendi %s" % progress.label(v), other])
    return None if i < 0 else i == 0


def _notify(msg, ms=4000):
    xbmcgui.Dialog().notification("Addò-flix", msg, xbmcgui.NOTIFICATION_INFO, ms)


# ---------- controllo della visione (salvataggio continuo + riavvio se cade lo stream) ----------
_gen = {"n": 0}


class _Watch(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.user_stop = self.ended = self.error = False

    def onPlayBackStopped(self):
        self.user_stop = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackError(self):
        self.error = True


def _track(e, url, ep, start, gen, retries=2):
    p, mon = _Watch(), xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < 60 and not mon.abortRequested():
        try:
            if p.isPlayingVideo() and p.getTotalTime() > 0:
                break
        except Exception:
            pass
        mon.waitForAbort(0.5)
    try:
        playing = p.getPlayingFile()
    except Exception:
        playing = ""
    if start >= progress.MIN_RESUME:
        try:
            if abs(p.getTime() - start) > 20:
                p.seekTime(max(0, start - 5))  # qualche secondo prima, per riprendere il filo
        except Exception:
            pass
    if playing:
        progress.even_volume()  # vale solo per questo video (anche dopo un riavvio dello stream)
    pos = total = 0.0
    last = 0.0
    t_start = time.time()
    stalls = []          # momenti in cui il video si e' fermato a caricare
    caching = False
    lowered = False
    next_checked, go_next = False, None
    while not mon.abortRequested():
        try:
            if not p.isPlaying() or p.getPlayingFile() != playing:
                break
            pos, total = p.getTime(), p.getTotalTime()
        except Exception:
            break
        # serie: ai titoli di coda il popup "Prossimo episodio" (conto alla rovescia, Annulla, Guarda ora)
        if (not next_checked and ep and e.get("type") == "tv" and gen == _gen["n"] and total > 300
                and pos > 60 and total - pos <= nextep.trigger_secs() and nextep.enabled()):
            next_checked = True
            nxt = _next_of(e, ep)
            if nxt and nextep.ask(nxt, p, playing, mon, nxt.get("thumb", "")) in (nextep.GO, nextep.AUTO):
                go_next = nxt
                break
        if time.time() - last >= 5 and pos > 5 and not progress.is_done(pos, total):
            progress.put(e, pos, total, url, ep)  # ogni 5 s: un crash perde al massimo pochi secondi
            last = time.time()
        # blocchi per caricamento (dopo i primi 20 s, quando il buffer iniziale e' pieno)
        now_caching = xbmc.getCondVisibility("Player.Caching")
        if now_caching and not caching and time.time() - t_start > 20:
            stalls = [t for t in stalls if time.time() - t < 300] + [time.time()]
            if len(stalls) >= 3 and not lowered:
                # linea in calo: dalla prossima partenza (o dal riavvio) un gradino piu' in basso
                progress.step_down()
                lowered = True
        caching = now_caching
        mon.waitForAbort(1)
    if go_next is None:
        threading.Thread(target=_close_server_list, daemon=True).start()
    if go_next is not None and gen == _gen["n"]:
        # puntata finita (siamo ai titoli di coda): segnata come vista, poi parte la successiva
        progress.record(e, total, total, ep, force=True)
        progress.clear(e)
        _play_next(e, go_next)
        return
    mon.waitForAbort(1.5)  # lascia arrivare le notifiche del player (fine, errore, stop)
    if pos > 5:
        progress.record(e, pos, total, ep, force=True)  # cronologia: visto / a che punto
    if progress.is_done(pos, total):
        progress.clear(e)
    elif pos > 5:
        progress.put(e, pos, total, url, ep)
    broken = (p.error or p.ended) and not p.user_stop and total > 0 and not progress.is_done(pos, total)
    if (broken and retries > 0 and gen == _gen["n"] and not mon.abortRequested()
            and progress.setting("auto_retry", "true") == "true"):
        cap = progress.effective_cap() if lowered else progress.step_down()
        _notify("Connessione persa: riprendo da %s (max %s)" % (progress.fmt(pos), cap))
        mon.waitForAbort(3)
        _s4me["choice"] = 3013
        _stop_current()
        progress.cap_quality()  # il nuovo tetto vale dal riavvio
        _s4me["err"] = _s4me["nohd"] = False
        xbmc.executebuiltin("RunPlugin(%s)" % url)
        if _wait_playing():
            return _track(e, url, ep, pos, gen, retries - 1)
        _notify("Non riesco a riprendere: riprova tra poco")
    elif not broken and not stalls and time.time() - t_start > 20 * 60:
        progress.step_up()  # 20 minuti senza blocchi: la linea regge, si risale di un gradino
    if gen == _gen["n"]:
        progress.restore_quality()


def _next_of(e, ep):
    """Episodio dopo 'ep' (dall'elenco di s4me gia' trovato), con titolo e immagine di TMDB se ci sono."""
    try:
        show = progress.link_get("show:%s" % e["id"])
        if not show:
            return None
        nxt = nextep.find_next(_episodes(e, show), ep)
        if not nxt:
            return None
        try:
            import tmdb
            info = next((x for x in tmdb.season(e["id"], nxt["s"]) if x["e"] == nxt["e"]), None)
            if info:
                nxt["title"] = info["title"]
                nxt["thumb"] = info["still"]
        except Exception:
            pass
        nxt["title"] = re.sub(r"^\s*\d+\s*[xX]\s*\d+\s*-\s*", "", nxt.get("title") or "") or "Episodio %s" % nxt["e"]
        return nxt
    except Exception as ex:
        xbmc.log("[veloceflix] prossimo episodio: %r" % (ex,), xbmc.LOGINFO)
        return None


def _play_next(e, nxt):
    starting["n"] += 1
    try:
        _play_next_inner(e, nxt)
    finally:
        starting["n"] -= 1


def _play_next_inner(e, nxt):
    _s4me["choice"] = 3013
    rc, url, ep = _resolve(e, None, want={"s": nxt["s"], "e": nxt["e"]}, ask=False)
    if rc == OK and url and _play(e, url, ep, 0) == OK:
        return
    _notify("Non riesco ad avviare il prossimo episodio")
    if not xbmc.Player().isPlaying():
        progress.restore_quality()


def _stop_current(timeout=10):
    """Un video gia' in riproduzione si ferma prima di avviarne un altro: altrimenti l'attesa
    dell'avvio crederebbe partito il nuovo e non risponderebbe ai dialoghi di s4me ("scegli")."""
    p, mon = xbmc.Player(), xbmc.Monitor()
    if not p.isPlaying():
        return
    p.stop()
    t0 = time.time()
    while p.isPlaying() and time.time() - t0 < timeout and not mon.abortRequested():
        mon.waitForAbort(0.2)
    mon.waitForAbort(1.0)  # il controllo della visione precedente salva il punto e si chiude


starting = {"n": 0}   # avvii in corso: la home non riapre la scheda nel cambio tra due episodi


def _play(e, url, ep, start, status=None):
    starting["n"] += 1
    try:
        return _play_inner(e, url, ep, start, status)
    finally:
        starting["n"] -= 1


def _play_inner(e, url, ep, start, status=None):
    if status:
        status("Avvio la riproduzione...")
    _gen["n"] += 1  # prima di tutto: il controllo della visione precedente non tocca piu' la qualita'
    gen = _gen["n"]
    _stop_current()
    progress.cap_quality()
    _s4me["err"] = _s4me["nohd"] = False
    xbmc.executebuiltin("RunPlugin(%s)" % url)
    if not _wait_playing():
        if gen == _gen["n"]:
            progress.restore_quality()
        return FAIL
    threading.Thread(target=_track, args=(e, url, ep, start, gen), daemon=True).start()
    return OK


# ---------- API ----------
def watch(e, status=None, episode=None, prefer=None):
    """Ritorna OK, NOTFOUND, NOSOURCE, FAIL, DOWN o CANCEL. Da chiamare in un thread (blocca).
    episode = {"s", "e", "start"}: avvia direttamente quell'episodio (dalla scheda della serie).
    prefer = CB01: si va subito su CB01 (l'utente l'ha gia' scelto nella ricerca).
    Se StreamingCommunity non ha il titolo (o non risponde) si passa da soli a CB01."""
    if not available():
        return NOSOURCE
    if prefer == CB01:
        return _cb(e, status, episode)
    _ctx.clear()
    res = _watch(e, status, episode)
    if res == NOTFOUND:
        sc.mark(e, False)  # non e' su StreamingCommunity (sparisce solo se manca anche su CB01)
    if res in (NOTFOUND, DOWN, FAIL):
        # passaggio automatico a CB01, senza domande
        if status:
            status("Provo su CB01...")
        res = _cb(e, status, episode, dict(_ctx))
    return res


def _watch(e, status=None, episode=None):
    if not available():
        return NOSOURCE
    progress.restore_quality()  # se un crash precedente l'avesse lasciata limitata
    if episode and e["type"] == "tv":
        want = {"s": episode["s"], "e": episode["e"]}
        start = int(episode.get("start") or 0)
        _s4me["choice"] = 3013  # il punto lo gestisce Addò-flix
        rc, url, ep = _resolve(e, status, want=want, ask=False)
        if rc != OK:
            return rc
        if ep and (ep.get("s"), ep.get("e")) != (want["s"], want["e"]):
            start = 0  # episodio diverso da quello chiesto: dall'inizio
        res = _play(e, url, ep, start, status)
        if res == FAIL:
            if status:
                status("Riprovo...")
            rc, url2, ep2 = _resolve(e, status, fresh=True, want=want, ask=False)
            if rc == OK and url2:
                res = _play(e, url2, ep2 or ep, start, status)
        return res
    saved = progress.get(e)
    series = e["type"] == "tv"
    start, url, ep, want = 0, None, None, None
    if saved:
        r = _ask_resume(saved, series)
        if r is None:
            return CANCEL
        if r:
            start, url, ep = saved["pos"], saved.get("url"), saved.get("ep")
        elif series:
            want = saved.get("ep")  # propone l'ultimo episodio gia' selezionato
    _ctx.update(asked=True, start=start, want=ep or want)  # per CB01, se qui non si trova
    # col nostro punto di visione si fa partire s4me dall'inizio e si porta noi il video al punto giusto
    _s4me["choice"] = 3013 if saved else 3012
    if not url:
        rc, url, ep = _resolve(e, status, want=want)
        if rc != OK:
            return rc
        if ep and saved and ep != saved.get("ep"):
            start = 0  # altro episodio: si parte dall'inizio
    elif _decode(url).get("channel") == CHANNEL and not sc.reachable():
        return DOWN  # punto salvato su StreamingCommunity, che ora non risponde
    res = _play(e, url, ep, start, status)
    if res == FAIL:
        # il collegamento memorizzato potrebbe essere scaduto: nuova ricerca e un altro tentativo
        if status:
            status("Riprovo...")
        rc, url2, ep2 = _resolve(e, status, fresh=True, want=ep, ask=ep is None and series)
        if rc == OK and url2:
            res = _play(e, url2, ep2 or ep, start, status)
    return res
