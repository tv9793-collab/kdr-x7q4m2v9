import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import tmdb
import store
import source
import sc
import progress
import live
import livemenu

SKIN = ("default", "1080i")
CLOSE = (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU)
ROW_A, ROW_B = 101, 102          # le due righe visibili
GUARD_UP, GUARD_DOWN = 121, 120  # controlli "sentinella" per scorrere le righe
BTN_SEARCH, BTN_REFRESH = 10, 11
BTN_MODE = 13                     # interruttore Film e serie | Live
CONTEXT = (117, 101)              # ACTION_CONTEXT_MENU, pressione lunga del tasto OK/mouse destro
BTN_UP, BTN_DOWN = 130, 131       # frecce touch per scorrere le righe
ACC = "FFF5A524"
# swipe (touch) e rotella del mouse: il dito verso l'alto mostra le righe sotto
SWIPE_UP = set(range(531, 541))     # ACTION_GESTURE_SWIPE_UP .. _TEN
SWIPE_DOWN = set(range(541, 551))   # ACTION_GESTURE_SWIPE_DOWN .. _TEN
WHEEL_UP, WHEEL_DOWN = 104, 105     # ACTION_MOUSE_WHEEL_UP / _DOWN
_path = ""

# Thread in background: si tengono tutti qui e si aspettano prima che lo script finisca.
# Chiudere l'interprete Python con thread ancora vivi (magari dentro una richiesta di rete)
# puo' far cadere Kodi, soprattutto su Android: era la causa dei crash aprendo/chiudendo spesso.
_threads = []
_tlock = threading.Lock()


def _spawn(fn, *args):
    t = threading.Thread(target=fn, args=args, daemon=True)
    with _tlock:
        _threads[:] = [x for x in _threads if x.is_alive()] + [t]
    t.start()
    return t


def _join(threads, timeout):
    end = time.time() + timeout
    for t in threads:
        if t is not threading.current_thread():
            t.join(max(0.0, end - time.time()))


class Cancelled(Exception):
    pass


def _li(e):
    li = xbmcgui.ListItem(e["title"], e.get("label2", ""))
    li.setArt({"poster": e["poster"], "thumb": e["poster"]})
    if e.get("type") in ("live", "action"):
        li.setProperty("tile", e["type"])        # tessera con logo/icona al posto della locandina
        li.setProperty("initials", e.get("initials", ""))
    elif e.get("type") in ("movie", "tv"):
        _bar(li, progress.percent(e))
    li.setProperty("data", json.dumps(e))
    return li


def _bar(li, pct):
    """Barra rossa di avanzamento sotto la locandina (Kodi la disegna da ListItem.PercentPlayed)."""
    if pct <= 0:
        return
    li.setProperty("pct", str(pct))
    try:
        li.getVideoInfoTag().setResumePoint(min(pct, 99.5), 100.0)
    except Exception:
        pass


# ------------------------------------------------------------------ live
_live = {"busy": False}


def live_play(e, first=None):
    """Avvia un canale in background (controllo dei link, poi visione seguita)."""
    ch = live.get(e.get("key"))
    if not ch:
        return
    _spawn(_live_worker, ch, first)


def _live_worker(ch, first):
    mon = xbmc.Monitor()
    if _live["busy"]:  # un altro canale e' in corso: lo si ferma e si aspetta che il suo controllo finisca
        try:
            xbmc.Player().stop()
        except Exception:
            pass
        t0 = time.time()
        while _live["busy"] and time.time() - t0 < 8 and not mon.waitForAbort(0.2):
            pass
    _live["busy"] = True
    bg = xbmcgui.DialogProgressBG()
    bg.create("Addò-flix Live", ch["name"])
    st = {"open": True}

    def close():
        if st["open"]:
            st["open"] = False
            bg.close()

    def status(t):
        if st["open"]:
            bg.update(message=t)

    res = live.FAIL
    try:
        res = live.watch(ch, status, on_start=close, first=first)
    except Exception as ex:
        xbmc.log("[veloceflix] live error: %r" % (ex,), xbmc.LOGERROR)
    finally:
        close()
        _live["busy"] = False
    if res == live.FAIL:
        xbmcgui.Dialog().ok("Addò-flix Live", "Nessun link di %s funziona in questo momento.\n"
                            "Riprova tra poco o aggiungi un altro link (tieni premuto OK sul canale)." % ch["name"])


def live_context(e):
    """Menu del canale. Ritorna True se i canali sono cambiati."""
    what, link = livemenu.channel_menu(e)
    if what == "play":
        live_play(e, link)
    return what == "changed"


def _meta(e):
    parts = [e["year"], "Serie TV" if e["type"] == "tv" else "Film"]
    if e["vote"]:
        parts.append("★ %s" % e["vote"])
    return "   ·   ".join(p for p in parts if p)


def _entry(li):
    try:
        return json.loads(li.getProperty("data"))
    except Exception:
        return None


# ---------------------------------------------------------------- dettaglio
BTN_SEASON, EP_LIST = 23, 30   # scheda serie: stagione ed episodi


class _Ended(xbmc.Player):
    """Avvisa la scheda quando il video finisce o viene fermato (per aggiornare visti e barre)."""
    def __init__(self, cb):
        super().__init__()
        self.cb = cb

    def onPlayBackStopped(self):
        self.cb()

    def onPlayBackEnded(self):
        self.cb()


class Detail(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.e = k["entry"]
        self.owner = k.get("owner")
        self.prefer = k.get("prefer")   # source.CB01: l'utente ha scelto CB01 dalla ricerca
        self.started = False
        self.tv = self.e.get("type") == "tv"
        self.busy = False
        self.changed = False
        self.closed = False   # finestra chiusa: il thread non la tocca piu'
        self.worker = None
        self.seasons = []     # [(numero, nome, episodi)]
        self.season = None
        self.eps = []         # episodi della stagione mostrata
        self.ui = threading.RLock()
        self.ended = _Ended(self._after_play) if self.tv else None

    def onInit(self):
        e = self.e
        self.setProperty("Title", e["title"])
        self.setProperty("Year", e["year"] or "-")
        self.setProperty("Kind", "Serie TV" if self.tv else "Film")
        self.setProperty("Rating", "%s" % e["vote"] if e["vote"] else "")
        self.setProperty("Plot", e["plot"] or "Nessuna trama disponibile.")
        self.setProperty("Poster", e["poster"])
        self.setProperty("Backdrop", e["backdrop"])
        if self.tv:
            self.setProperty("IsTV", "1")
            self.setProperty("SeasonLabel", "Stagioni...")
            _spawn(self._load_seasons)
        self._lbl()
        self.setFocusId(20)

    # -- serie: stagioni ed episodi
    def _all_eps(self):
        return [(s, n) for s, _, cnt in self.seasons for n in range(1, cnt + 1)]

    def _load_seasons(self):
        try:
            self.seasons = tmdb.tv_seasons(self.e["id"])
        except Exception as ex:
            xbmc.log("[veloceflix] stagioni: %r" % (ex,), xbmc.LOGERROR)
        if self.closed or not self.seasons:
            if not self.closed:
                self.setProperty("SeasonLabel", "Episodi non disponibili")
            return
        nxt = progress.next_episode(self.e, self._all_eps())
        nums = [s[0] for s in self.seasons]
        self._load_season(nxt[0] if nxt and nxt[0] in nums else nums[0], focus_ep=nxt[1] if nxt else None)
        self._lbl()

    def _load_season(self, n, focus_ep=None):
        eps = tmdb.season(self.e["id"], n)
        if self.closed:
            return
        with self.ui:
            self.season, self.eps = n, eps
            nums = [x[0] for x in self.seasons]
            i = nums.index(n) if n in nums else 0
            name = next((x[1] for x in self.seasons if x[0] == n), "Stagione %s" % n)
            many = len(self.seasons) > 1
            # "Stagione 2 di 4" con le frecce: si vede subito che ci sono altre stagioni
            self.setProperty("SeasonLabel", "%s  (%d di %d)" % (name, i + 1, len(nums)) if many else name)
            self.setProperty("SeasonPrev", "1" if i > 0 else "")
            self.setProperty("SeasonNext", "1" if i + 1 < len(nums) else "")
            self.setProperty("SeasonCount", "%d stagioni" % len(nums) if many else "")
            self._fill_eps(focus_ep)

    def _step_season(self, delta):
        nums = [x[0] for x in self.seasons]
        if self.season not in nums:
            return
        i = nums.index(self.season) + delta
        if 0 <= i < len(nums):
            _spawn(self._load_season, nums[i])

    def _episode_menu(self):
        i = self.getControl(EP_LIST).getSelectedPosition()
        if not (0 <= i < len(self.eps)):
            return
        x = self.eps[i]
        st = progress.episode_state(self.e, x)
        seen = bool(st and st[2])
        opts = ["Segna come da vedere" if seen else "Segna come visto",
                "Segna tutta la stagione come vista", "Segna tutta la stagione come da vedere"]
        j = xbmcgui.Dialog().select("S%s E%s  %s" % (x["s"], x["e"], x["title"]), opts)
        if j == 0:
            progress.set_watched(self.e, [(x["s"], x["e"])], not seen)
        elif j in (1, 2):
            progress.set_watched(self.e, [(y["s"], y["e"]) for y in self.eps], j == 1)
        else:
            return
        self.changed = True
        with self.ui:
            self._fill_eps()
            self._lbl()

    def _fill_eps(self, focus_ep=None):
        c = self.getControl(EP_LIST)
        pos = c.getSelectedPosition() if focus_ep is None else 0
        c.reset()
        items = []
        nospoil = progress.setting("hide_spoilers", "false") == "true"
        nxt = progress.next_episode(self.e, self._all_eps()) if nospoil and self.seasons else None
        for i, x in enumerate(self.eps):
            li = xbmcgui.ListItem("%d. %s" % (x["e"], x["title"]),
                                  "%d min" % x["runtime"] if x["runtime"] else "")
            li.setArt({"thumb": x["still"] or self.e["backdrop"], "poster": x["still"] or self.e["backdrop"]})
            st = progress.episode_state(self.e, x)
            if st:
                p, tot, done = st
                if done:
                    li.setProperty("done", "1")
                    _bar(li, 100)
                elif tot and p >= progress.MIN_RESUME:
                    _bar(li, max(3, min(99, int(p * 100 / tot))))
            plot = x["plot"]
            # anti-spoiler: trama nascosta per gli episodi non ancora visti (tranne il prossimo)
            if nospoil and not (st and st[2]) and not (nxt and (nxt[0], nxt[1]) == (x["s"], x["e"])):
                plot = "Trama nascosta per evitare spoiler (si può cambiare nelle impostazioni)."
            li.setProperty("plot", plot)
            items.append(li)
            if focus_ep is not None and x["e"] == focus_ep:
                pos = i
        c.addItems(items)
        if items:
            c.selectItem(max(0, min(pos, len(items) - 1)))
        self._ep_plot()

    def _ep_plot(self):
        try:
            li = self.getControl(EP_LIST).getSelectedItem()
            self.setProperty("EpPlot", li.getProperty("plot") if li else "")
        except Exception:
            pass

    def _after_play(self):
        """Video finito/fermato: dopo il salvataggio del punto si aggiornano visti, barre e 'Riprendi'."""
        def later():
            xbmc.Monitor().waitForAbort(3)
            if self.closed:
                return
            with self.ui:
                self._lbl()
                if self.eps:
                    self._fill_eps()
        _spawn(later)

    def _choose_season(self):
        if len(self.seasons) < 2:
            return
        names = [x[1] for x in self.seasons]
        nums = [x[0] for x in self.seasons]
        i = xbmcgui.Dialog().select("Stagione", names, preselect=nums.index(self.season) if self.season in nums else 0)
        if i >= 0 and nums[i] != self.season:
            _spawn(self._load_season, nums[i])

    def _lbl(self):
        inl = store.in_list(self.e)
        self.setProperty("ListLabel", "Nella mia lista" if inl else "Aggiungi alla mia lista")
        self.setProperty("InList", "1" if inl else "")
        if self.tv and self.seasons:
            s, n, start = progress.next_episode(self.e, self._all_eps())
            self.next = {"s": s, "e": n, "start": start}
            self.setProperty("PlayLabel", "%s S%s E%s" % ("Riprendi" if start else "Guarda", s, n))
            self.setProperty("Resume", "S%s E%s da %s" % (s, n, progress.fmt(start)) if start else "")
            return
        self.next = None
        saved = progress.get(self.e)
        self.setProperty("PlayLabel", "Riprendi" if saved else "Guarda")
        self.setProperty("Resume", progress.label(saved).capitalize() if saved else "")

    def _status(self, txt):
        if self.closed:  # l'utente e' tornato indietro: si interrompe la ricerca
            raise Cancelled()
        self.setProperty("Status", txt)

    def _watch(self, episode=None):
        try:
            res = source.watch(self.e, self._status, episode=episode, prefer=self.prefer)
        except Cancelled:
            res = source.CANCEL
        except Exception as ex:  # mai lasciare la UI bloccata
            xbmc.log("[veloceflix] watch error: %r" % (ex,), xbmc.LOGERROR)
            res = source.FAIL
        self.busy = False
        if res == source.OK:
            store.add_recent(self.e)
            self.changed = True
        if res == source.NOTFOUND:
            self.changed = True  # non disponibile: la home lo toglie dalle righe
        if self.closed:
            return
        self.clearProperty("Status")
        self._lbl()
        what = "Serie" if self.tv else "Film"
        if res == source.NOTFOUND:
            xbmcgui.Dialog().ok("Addò-flix", "%s non trovato in italiano HD: non e' ne' su StreamingCommunity ne' su CB01." % what)
        elif res == source.NOSOURCE:
            xbmcgui.Dialog().ok("Addò-flix", "Serve l'addon Stream for Me (plugin.video.s4me).")
        elif res == source.DOWN:
            xbmcgui.Dialog().ok("Addò-flix", "Il sito non risponde in questo momento. Riprova tra poco.")
        elif res == source.FAIL:
            xbmcgui.Dialog().ok("Addò-flix", "%s trovato, ma nessun video HD in italiano parte adesso." % what)

    def _start(self, episode=None):
        if self.busy:
            return
        self.busy = True
        self.started = True
        if self.tv and self.owner is not None:
            # s4me chiude questa scheda all'avvio del video (senza avvisare): a fine visione la si riapre
            self.owner.reopen = self.e
        self._status("Cerco la serie..." if self.tv else "Cerco il film...")
        self.worker = _spawn(self._watch, episode)

    def onClick(self, cid):
        if cid == 20:
            self._start(self.next if self.tv else None)
        elif cid == 21:
            store.toggle_list(self.e)
            self.changed = True
            self._lbl()
        elif cid == 22:
            self._leave()
        elif cid == BTN_SEASON:
            self._choose_season()
        elif cid == EP_LIST:
            li = self.getControl(EP_LIST).getSelectedItem()
            i = self.getControl(EP_LIST).getSelectedPosition()
            if li is None or not (0 <= i < len(self.eps)):
                return
            x = self.eps[i]
            st = progress.episode_state(self.e, x)
            # a meta': si riprende da dove si era rimasti (come Netflix); visto o nuovo: dall'inizio
            start = st[0] if st and not st[2] and st[0] >= progress.MIN_RESUME else 0
            self._start({"s": x["s"], "e": x["e"], "start": start})

    def _leave(self):
        # anche durante la ricerca: il thread si ferma al passo successivo
        self.closed = True
        if self.owner is not None and self.owner.reopen is self.e:
            self.owner.reopen = None   # uscita dall'utente: a fine visione non si riapre
        self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in CLOSE:
            self._leave()
        elif not self.tv:
            return
        elif self.getFocusId() == BTN_SEASON and aid in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT):
            self._step_season(-1 if aid == xbmcgui.ACTION_MOVE_LEFT else 1)   # frecce: stagione prima/dopo
        elif self.getFocusId() == EP_LIST:
            if aid in CONTEXT:
                self._episode_menu()
            else:
                self._ep_plot()


def open_detail(e, home=None, prefer=None):
    """home = finestra (home o ricerca) che riapre la scheda di una serie a fine visione.
    Nota: quando s4me chiude la scheda per avviare il video, doModal puo' non tornare subito:
    per questo la riapertura e' decisa dalla scheda stessa (premendo Guarda), non qui."""
    d = Detail("VeloceFlixDetail.xml", _path, *SKIN, entry=e, owner=home, prefer=prefer)
    d.doModal()
    d.closed = True  # un'eventuale ricerca in corso si ferma da sola; run() la aspetta all'uscita
    changed = d.changed
    del d
    return changed


def _marked(items):
    """Risultati di ricerca con il segno della fonte nella seconda riga:
    niente = parte da StreamingCommunity, CB01 = solo su CB01, 'da verificare' = un sito non ha risposto.
    I titoli che mancano su entrambi i siti (verificato) non si mostrano."""
    out = []
    for e, st in items:
        if st == sc.NONE:
            continue
        kind = "Serie TV" if e["type"] == "tv" else "Film"
        lab = "%s  ·  %s" % (e["year"], kind) if e["year"] else kind
        if st == sc.CB:
            lab += "  ·  [COLOR %s]CB01[/COLOR]" % ACC
        elif st == sc.UNSURE:
            lab += "  ·  [COLOR FF8C8C96]da verificare[/COLOR]"
        out.append(dict(e, src=st, label2=lab))
    return out


def open_result(e, home=None):
    """Titolo scelto nella ricerca. 'Guarda' prova sempre prima StreamingCommunity (che puo' essere
    tornato disponibile), poi passa da solo a CB01."""
    clean = {k: v for k, v in e.items() if k not in ("src", "label2")}
    return open_detail(clean, home=home)


def _busy_call(fn, *args):
    """Esegue fn in un thread mostrando la rotellina di attesa; ritorna il suo risultato."""
    box = {}

    def run():
        try:
            box["r"] = fn(*args)
        except Exception as ex:
            xbmc.log("[veloceflix] %r" % (ex,), xbmc.LOGERROR)
    t = _spawn(run)
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        mon = xbmc.Monitor()
        while t.is_alive() and not mon.abortRequested():
            mon.waitForAbort(0.2)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    return box.get("r")


def _reopen_after(owner, alive):
    """Video fermato o finito: se era una serie partita dalla sua scheda, si torna alla scheda
    (come Netflix). Nel passaggio automatico all'episodio dopo si aspetta che riparta.
    owner = finestra (home o ricerca) con l'attributo 'reopen'. Ritorna True se ha riaperto."""
    e = owner.reopen
    xbmc.log("[veloceflix] fine visione: scheda da riaprire=%s" % (e.get("title") if e else None), xbmc.LOGINFO)
    if not e or not alive():
        return False
    mon, p = xbmc.Monitor(), xbmc.Player()
    t0 = time.time()
    while time.time() - t0 < 45 and not mon.abortRequested():
        if p.isPlaying():
            return False      # e' partito l'episodio successivo: si riapre alla prossima fermata
        if source.starting["n"] == 0 and time.time() - t0 > 2:
            break
        mon.waitForAbort(0.3)
    if owner.reopen is not e or not alive() or p.isPlaying():
        return False
    owner.reopen = None
    mon.waitForAbort(0.8)
    if xbmc.getInfoLabel("Window.Property(Title)") == e.get("title"):
        return False      # la scheda e' ancora aperta (s4me non l'ha chiusa): niente doppione
    open_detail(e, home=owner)
    return True


class _HomePlayer(xbmc.Player):
    def __init__(self, cb):
        super().__init__()
        self.cb = cb

    def onPlayBackStopped(self):
        self.cb()

    def onPlayBackEnded(self):
        self.cb()


# -------------------------------------------------------------- griglia
class Grid(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.items = k["items"]
        self.heading = k["heading"]
        self.changed = False

    def onInit(self):
        self.setProperty("Heading", self.heading)
        self.getControl(200).addItems([_li(e) for e in self.items])
        self.setFocusId(200)

    def onClick(self, cid):
        if cid == 200:
            e = _entry(self.getControl(200).getSelectedItem())
            if e and e.get("type") == "live":
                live_play(e)
            elif e and open_result(e):
                self.changed = True

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.close()
        elif action.getId() in CONTEXT and self.getFocusId() == 200:
            e = _entry(self.getControl(200).getSelectedItem())
            if e and e.get("type") == "live" and live_context(e):
                self.changed = True
                self.close()  # la home si ridisegna con le modifiche


# --------------------------------------------------------------- ricerca
KEYS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")


class Search(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.text = ""
        self.cur = 0  # posizione del cursore nel testo
        self.token = 0
        self.sugg = []
        self.changed = False
        self.closed = False
        self.reopen = None    # serie da riaprire a fine visione (scheda chiusa da s4me)
        self.ui = threading.RLock()
        self.player = _HomePlayer(lambda: _reopen_after(self, lambda: not self.closed))

    def onInit(self):
        self.getControl(300).addItems([xbmcgui.ListItem(k) for k in KEYS])
        self._show()
        self._load()
        self.setFocusId(300)

    def _show(self):
        t, c = self.text, self.cur
        start, n = 0, 22  # caratteri visibili nel campo: la finestra segue il cursore
        if len(t) > n:
            start = max(0, min(c - n // 2, len(t) - n))
        vis = t[start:start + n]
        cc = c - start
        esc = lambda x: x.replace("[", "(").replace("]", ")")
        self.setProperty("Query", "%s%s[COLOR %s]|[/COLOR]%s%s" % (
            "…" if start else "", esc(vis[:cc]), ACC, esc(vis[cc:]), "…" if start + n < len(t) else ""))
        self.setProperty("HasText", "1" if self.text else "")

    def _load(self):
        self.token += 1
        _spawn(self._worker, self.token, self.text)

    def _worker(self, token, text):
        try:
            self._fill(token, text)
        except Exception as ex:
            xbmc.log("[veloceflix] suggerimenti: %r" % (ex,), xbmc.LOGERROR)

    WAIT_FIRST = 4   # locandine trasparenti mostrate subito, prima ancora della risposta di TMDB

    def _fill(self, token, text):
        alive = lambda: token == self.token and not self.closed  # noqa: E731
        if text:
            time.sleep(0.3)  # attende che l'utente finisca di digitare
            if not alive():
                return
        # subito: locandine trasparenti lampeggianti (la ricerca e' in corso)
        self._put(token, "Cerco...", [], [], self.WAIT_FIRST)
        if text:
            res, head = tmdb.suggest(text), "Suggerimenti"
        else:
            res, head = tmdb.trending_all(), "Di tendenza oggi"
        if not alive():
            return
        state = {}
        self._put(token, "Cerco...", [], [], len(res))
        # 1) StreamingCommunity (veloce) e CB01 gia' controllato in passato
        for e, st in sc.classify(res, alive, use_cb=False):
            state[(e["type"], e["id"])] = st
        pending = [e for e in res if state.get((e["type"], e["id"])) == sc.UNSURE]
        waiting = set((e["type"], e["id"]) for e in pending)
        self._show_state(token, head, text, res, state, waiting)
        if not pending or not alive():
            return
        # 2) CB01 (via Stream for Me, 2-3 s a titolo, 2 alla volta): ogni titolo verificato prende il posto
        # della sua locandina trasparente; quelli che mancano su entrambi i siti spariscono
        lock = threading.Lock()

        def one(e):
            if not alive():
                return
            st = sc.classify([e], alive)[0][1]
            with lock:
                state[(e["type"], e["id"])] = st
                waiting.discard((e["type"], e["id"]))
                snap = set(waiting)
            self._show_state(token, head, text, res, dict(state), snap, keep=True)
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2) as ex:
            list(ex.map(one, pending))

    def _show_state(self, token, head, text, res, state, waiting, keep=False):
        """Elenco nell'ordine di TMDB: titoli verificati, locandine trasparenti per quelli in verifica."""
        shown, slots = [], []
        for e in res:
            k = (e["type"], e["id"])
            if k in waiting:
                slots.append(None)                      # segnaposto al posto giusto
            else:
                slots.append((e, state.get(k, sc.UNSURE)))
        items = _marked([s for s in slots if s is not None])
        it = iter(items)
        out = []
        for s in slots:
            if s is None:
                out.append(None)
            elif s[1] != sc.NONE:
                out.append(next(it))
        self._put(token, head if not waiting else "Cerco...", out, text, 0, keep=keep)

    def _put(self, token, head, entries, text, n_wait=0, keep=False):
        """entries: titoli da mostrare (None = locandina trasparente); n_wait: altre locandine trasparenti."""
        if token != self.token or self.closed:
            return
        entries = list(entries) + [None] * n_wait
        with self.ui:
            if token != self.token or self.closed:
                return
            lst = self.getControl(400)
            pos = lst.getSelectedPosition() if keep and self.sugg else 0
            old = self.sugg
            self.sugg = entries
            lis = []
            for e in entries:
                if e is None:
                    li = xbmcgui.ListItem("", "")
                    li.setProperty("wait", "1")
                else:
                    li = xbmcgui.ListItem(e["title"], e["label2"])
                    li.setArt({"poster": e["poster"], "thumb": e["poster"]})
                    li.setProperty("data", json.dumps(e))
                lis.append(li)
            lst.reset()
            lst.addItems(lis)  # tutti insieme: niente lista a meta' mentre si ridisegna
            if keep and old and pos > 0 and entries:  # aggiornamento: la selezione resta sullo stesso titolo
                key = old[min(pos, len(old) - 1)]
                idx = min(pos, len(entries) - 1)
                if key is not None:
                    idx = next((i for i, e in enumerate(entries) if e and (e["type"], e["id"]) == (key["type"], key["id"])), idx)
                lst.selectItem(idx)
            found = any(e is not None for e in entries)
            busy = any(e is None for e in entries)
            self.setProperty("SuggHead", head if (found or busy) else ("Nessun suggerimento" if text else ""))

    def _set(self, text, cur=None):
        self.text = text[:40]
        self.cur = len(self.text) if cur is None else max(0, min(cur, len(self.text)))
        self._show()
        self._load()

    def _insert(self, s):
        t, c = self.text, self.cur
        if len(t) + len(s) > 40:
            return
        self._set(t[:c] + s + t[c:], c + len(s))

    def onClick(self, cid):
        t, c = self.text, self.cur
        if cid == 300:
            self._insert(self.getControl(300).getSelectedItem().getLabel().lower())
        elif cid == 301:  # spazio, mai doppio e mai all'inizio
            if c > 0 and t[c - 1] != " " and t[c:c + 1] != " ":
                self._insert(" ")
        elif cid == 302:  # cancella il carattere prima del cursore
            if c > 0:
                self._set(t[:c - 1] + t[c:], c - 1)
        elif cid in (305, 306):  # sposta il cursore indietro / avanti
            self.cur = max(0, c - 1) if cid == 305 else min(len(t), c + 1)
            self._show()
        elif cid == 303:
            r = xbmcgui.Dialog().input("Cerca film o serie", self.text, type=xbmcgui.INPUT_ALPHANUM)
            if r is not None:
                self._set(r)
        elif cid == 304:
            self._all()
        elif cid == 400:
            e = _entry(self.getControl(400).getSelectedItem())
            if e and open_result(e, home=self):
                self.changed = True

    def _all(self):
        t = self.text.strip()
        if not t:
            return
        res = _busy_call(lambda: _marked(sc.classify(tmdb.search(t), lambda: not self.closed))) or []
        if not res:
            xbmcgui.Dialog().notification("Addò-flix", "Nessun risultato", xbmcgui.NOTIFICATION_INFO, 2500)
            return
        g = Grid("VeloceFlixGrid.xml", _path, *SKIN, items=res, heading='Risultati per "%s"' % t)
        g.doModal()
        if g.changed:
            self.changed = True
        del g

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.closed = True
            self.close()


# ------------------------------------------------------------------ home
class Home(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.alive = True
        self.started = False
        self.tmdb_rows = []
        self.top = 0
        self.last = None
        self.mode = "vod"        # si parte sempre da Film e serie; il Live lo sceglie l'utente
        self.live_rows = None    # righe Live (si ricalcolano dopo modifiche o aggiornamenti)
        # le righe si ridisegnano sia dal thread di caricamento sia dai tasti: mai insieme
        self.ui = threading.RLock()
        self.reopen = None       # serie da riaprire quando finisce la visione (scheda chiusa da s4me)
        self.player = _HomePlayer(self._after_play)

    def _after_play(self):
        if _reopen_after(self, lambda: self.alive):
            self._personal_refresh()

    # -- dati
    def rows(self):
        if self.mode == "live":
            if self.live_rows is None:
                try:
                    self.live_rows = livemenu.rows()
                except Exception as ex:
                    xbmc.log("[veloceflix] righe live: %r" % (ex,), xbmc.LOGERROR)
                    self.live_rows = [("Gestisci canali", livemenu.action_entries())]
            return self.live_rows
        r = []
        cw = progress.continue_watching()
        if cw:
            r.append(("Continua a guardare", cw))
        if store.get("recent"):
            r.append(("Visti di recente", store.get("recent")))
        if store.get("mylist"):
            r.append(("La mia lista", store.get("mylist")))
        return r + self.tmdb_rows

    def onInit(self):
        if self.started:
            return
        self.started = True
        self.setProperty("Mode", "vod")
        self.setProperty("Loading", "1")
        _spawn(self._boot)
        _spawn(self._hero_loop)

    def _boot(self, refresh=False):
        self.tmdb_rows = []
        self.top = 0
        first = True
        try:
            if refresh:
                tmdb.clear_cache()
                sc.clear()
            if not tmdb.has_key():
                xbmcgui.Dialog().ok("Addò-flix", "Manca la chiave TMDB: inseriscila nelle impostazioni dell'addon (gratis su themoviedb.org) oppure installa Stream for Me.")
            else:
                for title, entries in tmdb.home_rows():
                    if not self.alive:
                        return
                    # solo i titoli presenti su StreamingCommunity (ITA): niente "film non trovato"
                    ok = sc.filter_available(entries, alive=lambda: self.alive)
                    if not self.alive:
                        return
                    if not ok:
                        continue
                    self.tmdb_rows.append((title, ok))
                    if self.mode != "vod":  # l'utente e' nel Live: si carica senza ridisegnare
                        first = False
                        continue
                    n = len(self.rows())
                    if first:
                        first = False
                        self.render(focus=ROW_A)
                        self.clearProperty("Loading")
                    elif n - 1 <= self.top + 1:  # la riga nuova e' tra quelle visibili
                        self._personal_refresh()
        except Exception as ex:
            xbmc.log("[veloceflix] boot error: %r" % (ex,), xbmc.LOGERROR)
        if not self.alive:
            return
        if first and self.mode == "vod":  # nessuna riga TMDB: mostra almeno recenti/lista
            self.render(focus=ROW_A if self.rows() else BTN_SEARCH)
        self.clearProperty("Loading")

    # -- disegno delle due righe visibili
    def render(self, focus=None, pos=0):
        with self.ui:
            if self.alive:
                self._render(focus, pos)

    def _render(self, focus, pos):
        rows = self.rows()
        n = len(rows)
        self.top = max(0, min(self.top, n - 1))
        for slot, rid, key in ((0, ROW_A, "Row1"), (1, ROW_B, "Row2")):
            c = self.getControl(rid)
            c.reset()
            i = self.top + slot
            if i < n:
                self.setProperty(key, rows[i][0])
                c.addItems([_li(e) for e in rows[i][1]])
            else:
                self.clearProperty(key)
        self.setProperty("CanUp", "1" if self.top > 0 else "")
        self.setProperty("CanDown", "1" if self.top + 1 < n else "")
        self.last = None
        if focus:
            self.setFocusId(focus)
            if focus in (ROW_A, ROW_B) and pos:
                c = self.getControl(focus)
                c.selectItem(min(pos, max(0, c.size() - 1)))

    def _shift(self, delta):
        """Scorre di una riga in su/giu mantenendo la colonna selezionata."""
        with self.ui:
            from_id = ROW_A
            pos = self.getControl(from_id).getSelectedPosition()
            self.top += delta
            self.render(focus=from_id, pos=pos)

    def _scroll(self, delta):
        """Scorrimento da touch/mouse: solo se c'e' una riga in quella direzione."""
        if (delta > 0 and self.top + 1 < len(self.rows())) or (delta < 0 and self.top > 0):
            self._shift(delta)

    def onFocus(self, cid):
        if cid == GUARD_DOWN:
            if self.top + 1 < len(self.rows()):
                self._shift(+1)
            else:
                self.setFocusId(ROW_A)
        elif cid == GUARD_UP:
            if self.top > 0:
                self._shift(-1)
            else:
                self.setFocusId(BTN_SEARCH)

    # -- hero che segue il focus
    def _hero_loop(self):
        mon = xbmc.Monitor()
        while self.alive and not mon.waitForAbort(0.15):
            try:
                with self.ui:
                    if self.alive:
                        self._hero_once()
            except Exception:
                pass

    def _hero_once(self):
        fid = self.getFocusId()
        if fid not in (ROW_A, ROW_B):
            return
        li = self.getControl(fid).getSelectedItem()
        if li is None:
            return
        key = (fid, li.getProperty("data"))
        if key == self.last:
            return
        e = _entry(li)
        if not e:
            return
        self.last = key
        self._show_hero(e)

    def _show_hero(self, e):
        if e.get("type") in ("live", "action"):
            title, meta, plot = livemenu.hero(e)
            self.setProperty("HeroTitle", title)
            self.setProperty("HeroMeta", meta)
            self.setProperty("HeroRating", "")
            self.setProperty("HeroPlot", plot)
            self.setProperty("HeroBackdrop", "")
            return
        self.setProperty("HeroTitle", e["title"])
        meta = "%s   \u00b7   %s" % (e["year"], "Serie TV" if e["type"] == "tv" else "Film")
        saved = progress.get(e)
        if saved:
            meta += "   \u00b7   Riprendi %s" % progress.label(saved)
        self.setProperty("HeroMeta", meta)
        self.setProperty("HeroRating", "%s" % e["vote"] if e["vote"] else "")
        self.setProperty("HeroPlot", e["plot"])
        self.setProperty("HeroBackdrop", e["backdrop"])

    # -- eventi
    def _drop(self, e):
        with self.ui:
            same = lambda x: x.get("id") == e.get("id") and x.get("type") == e.get("type")
            self.tmdb_rows = [(t, [x for x in lst if not same(x)]) for t, lst in self.tmdb_rows]
            self.tmdb_rows = [(t, lst) for t, lst in self.tmdb_rows if lst]

    # -- Live
    def set_mode(self, mode):
        with self.ui:
            if mode == self.mode or not self.alive:
                return
            self.mode = mode
            self.setProperty("Mode", mode)
            self.top = 0
            self.live_rows = None
            # la selezione resta sull'interruttore: un altro OK torna indietro, freccia giu' va alle righe
            self.render(focus=BTN_MODE)
            rows = self.rows()
            if rows and rows[0][1]:  # riquadro in alto: il primo titolo/canale della nuova modalita'
                self._show_hero(rows[0][1][0])
            else:
                for k in ("HeroTitle", "HeroMeta", "HeroRating", "HeroPlot", "HeroBackdrop"):
                    self.clearProperty(k)
        if mode == "live" and progress.setting("live_url", ""):
            _spawn(self._live_sync, False)

    def _live_sync(self, force):
        n = live.sync(force)
        if force:
            if n < 0:
                xbmcgui.Dialog().notification("Addò-flix Live", "Lista online non raggiungibile: uso l'ultima copia",
                                              xbmcgui.NOTIFICATION_INFO, 3000)
            self.clearProperty("Loading")
        self._live_reload()

    def _live_reload(self):
        with self.ui:
            if self.alive and self.mode == "live":
                self.live_rows = None
                self._personal_refresh()

    def _live_search(self):
        t = xbmcgui.Dialog().input("Cerca canale", type=xbmcgui.INPUT_ALPHANUM)
        if not t:
            return
        res = livemenu.search(t)
        if not res:
            xbmcgui.Dialog().notification("Addò-flix Live", "Nessun canale trovato", xbmcgui.NOTIFICATION_INFO, 2500)
            return
        g = Grid("VeloceFlixGrid.xml", _path, *SKIN, items=res, heading='Canali: "%s"' % t)
        g.doModal()
        changed = g.changed
        del g
        if changed:
            self._live_reload()

    def onClick(self, cid):
        if cid in (ROW_A, ROW_B):
            e = _entry(self.getControl(cid).getSelectedItem())
            if not e:
                return
            if e.get("type") == "live":
                live_play(e)
            elif e.get("type") == "action":
                if livemenu.do_action(e["id"]):
                    self._live_reload()
            else:
                open_detail(e, home=self)
                if sc.gone(e):  # non c'e' ne' su StreamingCommunity ne' su CB01: via dalle righe
                    self._drop(e)
                self._personal_refresh()
        elif cid == BTN_MODE:
            self.set_mode("vod" if self.mode == "live" else "live")
        elif cid == BTN_SEARCH and self.mode == "live":
            self._live_search()
        elif cid == BTN_REFRESH and self.mode == "live":
            self.setProperty("Loading", "1")
            _spawn(self._live_sync, True)
        elif cid == BTN_SEARCH:
            s = Search("VeloceFlixSearch.xml", _path, *SKIN)
            s.doModal()
            s.closed = True
            del s
            self._personal_refresh()
        elif cid in (BTN_UP, BTN_DOWN):
            self._scroll(-1 if cid == BTN_UP else +1)
        elif cid == 12:  # impostazioni dell'addon (avvio automatico, chiave TMDB)
            xbmcaddon.Addon("plugin.video.veloceflix").openSettings()
        elif cid == BTN_REFRESH:
            self.setProperty("Loading", "1")
            _spawn(self._boot, True)

    def _personal_refresh(self):
        with self.ui:
            if not self.alive:
                return
            fid = self.getFocusId()
            pos = self.getControl(fid).getSelectedPosition() if fid in (ROW_A, ROW_B) else 0
            self.render(focus=fid if fid in (ROW_A, ROW_B, BTN_SEARCH, BTN_REFRESH, BTN_MODE) else ROW_A, pos=pos)

    def onAction(self, action):
        aid = action.getId()
        if aid in CLOSE:
            self.alive = False
            self.close()
        elif aid in CONTEXT and self.mode == "live" and self.getFocusId() in (ROW_A, ROW_B):
            e = _entry(self.getControl(self.getFocusId()).getSelectedItem())
            if e and e.get("type") == "live" and live_context(e):
                self._live_reload()
        elif aid in SWIPE_UP or aid == WHEEL_DOWN:
            self._scroll(+1)
        elif aid in SWIPE_DOWN or aid == WHEEL_UP:
            self._scroll(-1)


def run(addon):
    global _path
    _path = addon.getAddonInfo("path")
    if not xbmc.Player().isPlaying():
        progress.restore_quality()  # dopo un crash durante la visione
    w = Home("VeloceFlixHome.xml", _path, *SKIN)
    w.doModal()
    w.alive = False
    del w
    # Lo script finisce solo quando tutti i suoi thread sono fermi (la finestra e' gia' chiusa:
    # l'attesa non si vede). Thread vivi alla chiusura dell'interprete possono far cadere Kodi.
    # Il controllo della visione resta vivo finche' il video va (continua a salvare il punto).
    mon = xbmc.Monitor()
    me = threading.current_thread()
    while not mon.abortRequested():
        alive = [t for t in threading.enumerate() if t is not me and t.is_alive() and not t.name.startswith("Dummy")]
        if not alive:
            break
        mon.waitForAbort(0.2)
