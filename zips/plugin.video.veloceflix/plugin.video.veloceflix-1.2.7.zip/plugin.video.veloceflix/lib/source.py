"""Avvio diretto di un titolo tramite il canale StreamingCommunity (HD, ITA) di Stream for Me.

Flusso: cerca il titolo sul canale (via JSON-RPC verso plugin.video.s4me), sceglie il risultato
ITA con titolo/anno corrispondenti, poi lancia la riproduzione. Nessuna finestra di ricerca canali.
"""
import base64
import json
import re
import threading
import time
import unicodedata
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import progress

S4ME = "plugin.video.s4me"
CHANNEL = "streamingcommunity"
BASE = "plugin://%s/?" % S4ME

OK, NOTFOUND, NOSOURCE, FAIL, CANCEL = "ok", "notfound", "nosource", "fail", "cancel"


def available():
    return xbmc.getCondVisibility("System.HasAddon(%s)" % S4ME)


# ---------- utilita ----------
import sc  # noqa: E402
from sc import host as _host, norm as _norm  # noqa: E402


def _encode(d):
    return BASE + urllib.parse.quote(base64.b64encode(json.dumps(d).encode("utf8")).decode())


def _decode(url):
    try:
        q = url.split("?", 1)[1]
        return json.loads(base64.b64decode(urllib.parse.unquote(q)).decode("utf8"))
    except Exception:
        return {}


def _listdir(url):
    """Elenco file di una cartella plugin (blocca finche' s4me ha finito)."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": url, "media": "files", "properties": ["title"]}}
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return []
    return (r.get("result") or {}).get("files") or []


def _entries(url):
    out = []
    for f in _listdir(url):
        d = _decode(f.get("file", ""))
        if d:
            out.append((f.get("file"), d))
    return out


def _title_ok(cand, e):
    c = _norm(cand)
    return bool(c) and c in (_norm(e.get("title")), _norm(e.get("orig")))


def _year_ok(d, e):
    try:
        y1, y2 = int(d.get("year") or (d.get("infoLabels") or {}).get("year") or 0), int(e.get("year") or 0)
    except Exception:
        return True
    return not y1 or not y2 or abs(y1 - y2) <= 1


def pick(entries, e):
    """Sceglie tra i risultati del canale: stesso tipo, ITA (non Sub-ITA), stesso titolo, anno compatibile."""
    want = "tvshow" if e["type"] == "tv" else "movie"
    best = None
    for url, d in entries:
        if d.get("contentType") != want:
            continue
        if (d.get("language") or "").strip().upper() != "ITA":
            continue
        if d.get("action") not in ("findvideos", "episodios"):
            continue
        name = d.get("fulltitle") or d.get("contentTitle") or d.get("contentSerieName") or ""
        if not (_title_ok(name, e) and _year_ok(d, e)):
            continue
        exact = _norm(name) == _norm(e.get("title"))
        score = 2 if exact else 1
        if best is None or score > best[0]:
            best = (score, url, d)
    return (best[1], best[2]) if best else (None, None)


def search_channel(e, status=None):
    host = _host()
    if not host:
        return None, None
    terms = [e["title"]]
    if e.get("orig") and _norm(e["orig"]) != _norm(e["title"]):
        terms.append(e["orig"])
    for t in terms:
        if status:
            status('Cerco "%s"...' % t)
        item = {"channel": CHANNEL, "action": "peliculas", "search": True, "folder": True,
                "contentType": "tvshow" if e["type"] == "tv" else "movie",
                "url": "%s/it/search?q=%s" % (host, urllib.parse.quote(t))}
        url, d = pick(_entries(_encode(item)), e)
        if url:
            return url, d
    return None, None


# risposta da dare al dialogo "Riprendi" di Stream for Me: 3012 = riprendi, 3013 = dall'inizio.
# Se il punto di visione lo gestisce Addò-flix (piu' aggiornato, salvato anche in caso di crash)
# si sceglie "dall'inizio" e poi Addò-flix porta il video al punto giusto.
_s4me = {"choice": 3012}


def _auto_choose():
    """Risponde da solo ai dialoghi di s4me: lista 'Riproduci ...' (sceglie HD) e 'Riprendi'
    (altrimenti s4me aspetterebbe fino a 10 secondi)."""
    if xbmc.getCondVisibility("Window.IsActive(ResumePlayback.xml)"):
        xbmc.executebuiltin("SetFocus(%d)" % _s4me["choice"])
        xbmc.sleep(150)
        xbmc.executebuiltin("Action(Select)")
        xbmc.sleep(400)
        return
    if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        return
    try:
        n = int(xbmc.getInfoLabel("Container(3).NumItems") or 0)
    except Exception:
        return
    labels = [xbmc.getInfoLabel("Container(3).ListItemAbsolute(%d).Label" % i) for i in range(n)]
    play = [i for i, l in enumerate(labels) if l.lower().startswith("riproduci")]
    if not play:
        return  # e' un'altra finestra: la lasciamo all'utente
    hd = [i for i in play if "hd" in labels[i].lower() and "sd" not in labels[i].lower().replace("hd", "")]
    idx = (hd or play)[0]
    xbmc.executebuiltin("SetFocus(3,%d)" % idx)
    xbmc.sleep(250)
    xbmc.executebuiltin("Action(Select)")
    xbmc.sleep(800)


def _wait_playing(timeout=50):
    mon = xbmc.Monitor()
    player = xbmc.Player()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if player.isPlaying():
            return True
        _auto_choose()
        mon.waitForAbort(0.5)
    return False


def _episodes(e, show_url, status=None, fresh=False):
    """Elenco episodi [[stagione, episodio, url, titolo]], memorizzato per un giorno."""
    k = "eps:%s" % e["id"]
    eps = None if fresh else progress.link_get(k, progress.LIST_TTL)
    if eps:
        return eps
    if status:
        status("Carico gli episodi...")

    def num(d, *names):
        for n in names:
            try:
                return int(d.get(n) or 0)
            except Exception:
                pass
        return 0

    eps = []
    for u, d in _entries(show_url):
        if d.get("action") != "findvideos":
            continue
        s, n = num(d, "contentSeason", "season"), num(d, "contentEpisodeNumber", "episode")
        t = re.sub(r"\[/?[^\]]*\]", "", d.get("title", "")).strip()
        eps.append([s, n, u, t or "Episodio %d" % n])
    eps.sort(key=lambda x: (x[0], x[1]))
    if eps:
        progress.link_put(k, eps)
    return eps


def _choose_episode(eps, want=None):
    """Dialoghi stagione/episodio; 'want' = episodio da proporre gia' selezionato."""
    seasons = sorted({x[0] for x in eps})
    s = seasons[0]
    if want and want.get("s") in seasons:
        s = want["s"]
    if len(seasons) > 1:
        i = xbmcgui.Dialog().select("Stagione", ["Stagione %d" % x for x in seasons], preselect=seasons.index(s))
        if i < 0:
            return CANCEL, None
        s = seasons[i]
    lst = [x for x in eps if x[0] == s]
    pre = 0
    if want and want.get("s") == s:
        pre = next((i for i, x in enumerate(lst) if x[1] == want.get("e")), 0)
    i = xbmcgui.Dialog().select("Stagione %d" % s, [x[3] for x in lst], preselect=pre)
    if i < 0:
        return CANCEL, None
    x = lst[i]
    return x[2], {"s": x[0], "e": x[1], "title": x[3]}


def _resolve(e, status=None, fresh=False, want=None, ask=True):
    """Trova il collegamento s4me da avviare. Ritorna (esito, url, episodio).
    Usa i collegamenti memorizzati (avvio rapido) salvo fresh=True."""
    k = progress.key(e)
    if e["type"] == "movie" and not fresh:
        url = progress.link_get(k)
        if url:
            return OK, url, None
    show = None if fresh else progress.link_get("show:%s" % e["id"])
    if not show:
        url, d = search_channel(e, status)
        if not url:
            return NOTFOUND, None, None
        if d.get("action") == "findvideos":
            m = re.search(r"/watch/(\d+)", d.get("url") or "")
            if m and sc.movie_playable(int(m.group(1))) is False:
                return NOTFOUND, None, None  # titolo nel catalogo ma senza video disponibile
            progress.link_put(k, url)
            return OK, url, None
        show = url
        progress.link_put("show:%s" % e["id"], show)
    eps = _episodes(e, show, status, fresh)
    if not eps:
        return NOTFOUND, None, None
    if want and not ask:  # stesso episodio, senza dialoghi (riavvio dopo un errore)
        for x in eps:
            if x[0] == want.get("s") and x[1] == want.get("e"):
                return OK, x[2], {"s": x[0], "e": x[1], "title": x[3]}
    url, ep = _choose_episode(eps, want)
    if url == CANCEL:
        return CANCEL, None, None
    return OK, url, ep


def _ask_resume(v, series):
    """True = riprendi, False = dall'inizio / altro episodio, None = annullato."""
    if progress.setting("resume", "ask") == "auto":
        return True
    other = "Scegli un altro episodio" if series else "Guarda dall'inizio"
    i = xbmcgui.Dialog().select("Addò-flix", ["Riprendi %s" % progress.label(v), other])
    return None if i < 0 else i == 0


def _notify(msg, ms=4000):
    xbmcgui.Dialog().notification("Addò-flix", msg, xbmcgui.NOTIFICATION_INFO, ms)


# ---------- controllo della visione (salvataggio continuo + riavvio se cade lo stream) ----------
_gen = {"n": 0}


class _Watch(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.user_stop = self.ended = self.error = False

    def onPlayBackStopped(self):
        self.user_stop = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackError(self):
        self.error = True


def _track(e, url, ep, start, gen, retries=2):
    p, mon = _Watch(), xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < 60 and not mon.abortRequested():
        try:
            if p.isPlayingVideo() and p.getTotalTime() > 0:
                break
        except Exception:
            pass
        mon.waitForAbort(0.5)
    try:
        playing = p.getPlayingFile()
    except Exception:
        playing = ""
    if start >= progress.MIN_RESUME:
        try:
            if abs(p.getTime() - start) > 20:
                p.seekTime(max(0, start - 5))  # qualche secondo prima, per riprendere il filo
        except Exception:
            pass
    if playing:
        progress.even_volume()  # vale solo per questo video (anche dopo un riavvio dello stream)
    pos = total = 0.0
    last = 0.0
    t_start = time.time()
    stalls = []          # momenti in cui il video si e' fermato a caricare
    caching = False
    lowered = False
    while not mon.abortRequested():
        try:
            if not p.isPlaying() or p.getPlayingFile() != playing:
                break
            pos, total = p.getTime(), p.getTotalTime()
        except Exception:
            break
        if time.time() - last >= 5 and pos > 5 and not progress.is_done(pos, total):
            progress.put(e, pos, total, url, ep)  # ogni 5 s: un crash perde al massimo pochi secondi
            last = time.time()
        # blocchi per caricamento (dopo i primi 20 s, quando il buffer iniziale e' pieno)
        now_caching = xbmc.getCondVisibility("Player.Caching")
        if now_caching and not caching and time.time() - t_start > 20:
            stalls = [t for t in stalls if time.time() - t < 300] + [time.time()]
            if len(stalls) >= 3 and not lowered:
                # linea in calo: dalla prossima partenza (o dal riavvio) un gradino piu' in basso
                progress.step_down()
                lowered = True
        caching = now_caching
        mon.waitForAbort(1)
    mon.waitForAbort(1.5)  # lascia arrivare le notifiche del player (fine, errore, stop)
    if progress.is_done(pos, total):
        progress.clear(e)
    elif pos > 5:
        progress.put(e, pos, total, url, ep)
    broken = (p.error or p.ended) and not p.user_stop and total > 0 and not progress.is_done(pos, total)
    if (broken and retries > 0 and gen == _gen["n"] and not mon.abortRequested()
            and progress.setting("auto_retry", "true") == "true"):
        cap = progress.effective_cap() if lowered else progress.step_down()
        _notify("Connessione persa: riprendo da %s (max %s)" % (progress.fmt(pos), cap))
        mon.waitForAbort(3)
        _s4me["choice"] = 3013
        progress.cap_quality()  # il nuovo tetto vale dal riavvio
        xbmc.executebuiltin("RunPlugin(%s)" % url)
        if _wait_playing():
            return _track(e, url, ep, pos, gen, retries - 1)
        _notify("Non riesco a riprendere: riprova tra poco")
    elif not broken and not stalls and time.time() - t_start > 20 * 60:
        progress.step_up()  # 20 minuti senza blocchi: la linea regge, si risale di un gradino
    if gen == _gen["n"]:
        progress.restore_quality()


def _play(e, url, ep, start, status=None):
    if status:
        status("Avvio la riproduzione...")
    progress.cap_quality()
    xbmc.executebuiltin("RunPlugin(%s)" % url)
    if not _wait_playing():
        progress.restore_quality()
        return FAIL
    _gen["n"] += 1
    threading.Thread(target=_track, args=(e, url, ep, start, _gen["n"]), daemon=True).start()
    return OK


# ---------- API ----------
def watch(e, status=None):
    """Ritorna OK, NOTFOUND, NOSOURCE, FAIL o CANCEL. Da chiamare in un thread (blocca)."""
    if not available():
        return NOSOURCE
    progress.restore_quality()  # se un crash precedente l'avesse lasciata limitata
    saved = progress.get(e)
    series = e["type"] == "tv"
    start, url, ep, want = 0, None, None, None
    if saved:
        r = _ask_resume(saved, series)
        if r is None:
            return CANCEL
        if r:
            start, url, ep = saved["pos"], saved.get("url"), saved.get("ep")
        elif series:
            want = saved.get("ep")  # propone l'ultimo episodio gia' selezionato
    # col nostro punto di visione si fa partire s4me dall'inizio e si porta noi il video al punto giusto
    _s4me["choice"] = 3013 if saved else 3012
    if not url:
        rc, url, ep = _resolve(e, status, want=want)
        if rc != OK:
            return rc
        if ep and saved and ep != saved.get("ep"):
            start = 0  # altro episodio: si parte dall'inizio
    res = _play(e, url, ep, start, status)
    if res == FAIL:
        # il collegamento memorizzato potrebbe essere scaduto: nuova ricerca e un altro tentativo
        if status:
            status("Riprovo...")
        rc, url2, ep2 = _resolve(e, status, fresh=True, want=ep, ask=ep is None and series)
        if rc == OK and url2:
            res = _play(e, url2, ep2 or ep, start, status)
    return res
