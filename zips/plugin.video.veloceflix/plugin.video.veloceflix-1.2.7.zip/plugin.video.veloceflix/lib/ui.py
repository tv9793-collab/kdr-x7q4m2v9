import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import tmdb
import store
import source
import sc
import progress
import live
import livemenu

SKIN = ("default", "1080i")
CLOSE = (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU)
ROW_A, ROW_B = 101, 102          # le due righe visibili
GUARD_UP, GUARD_DOWN = 121, 120  # controlli "sentinella" per scorrere le righe
BTN_SEARCH, BTN_REFRESH = 10, 11
BTN_MODE = 13                     # interruttore Film e serie | Live
CONTEXT = (117, 101)              # ACTION_CONTEXT_MENU, pressione lunga del tasto OK/mouse destro
BTN_UP, BTN_DOWN = 130, 131       # frecce touch per scorrere le righe
ACC = "FFF5A524"
# swipe (touch) e rotella del mouse: il dito verso l'alto mostra le righe sotto
SWIPE_UP = set(range(531, 541))     # ACTION_GESTURE_SWIPE_UP .. _TEN
SWIPE_DOWN = set(range(541, 551))   # ACTION_GESTURE_SWIPE_DOWN .. _TEN
WHEEL_UP, WHEEL_DOWN = 104, 105     # ACTION_MOUSE_WHEEL_UP / _DOWN
_path = ""

# Thread in background: si tengono tutti qui e si aspettano prima che lo script finisca.
# Chiudere l'interprete Python con thread ancora vivi (magari dentro una richiesta di rete)
# puo' far cadere Kodi, soprattutto su Android: era la causa dei crash aprendo/chiudendo spesso.
_threads = []
_tlock = threading.Lock()


def _spawn(fn, *args):
    t = threading.Thread(target=fn, args=args, daemon=True)
    with _tlock:
        _threads[:] = [x for x in _threads if x.is_alive()] + [t]
    t.start()
    return t


def _join(threads, timeout):
    end = time.time() + timeout
    for t in threads:
        if t is not threading.current_thread():
            t.join(max(0.0, end - time.time()))


class Cancelled(Exception):
    pass


def _li(e):
    li = xbmcgui.ListItem(e["title"], e.get("label2", ""))
    li.setArt({"poster": e["poster"], "thumb": e["poster"]})
    if e.get("type") in ("live", "action"):
        li.setProperty("tile", e["type"])        # tessera con logo/icona al posto della locandina
        li.setProperty("initials", e.get("initials", ""))
    li.setProperty("data", json.dumps(e))
    return li


# ------------------------------------------------------------------ live
_live = {"busy": False}


def live_play(e, first=None):
    """Avvia un canale in background (controllo dei link, poi visione seguita)."""
    ch = live.get(e.get("key"))
    if not ch:
        return
    _spawn(_live_worker, ch, first)


def _live_worker(ch, first):
    mon = xbmc.Monitor()
    if _live["busy"]:  # un altro canale e' in corso: lo si ferma e si aspetta che il suo controllo finisca
        try:
            xbmc.Player().stop()
        except Exception:
            pass
        t0 = time.time()
        while _live["busy"] and time.time() - t0 < 8 and not mon.waitForAbort(0.2):
            pass
    _live["busy"] = True
    bg = xbmcgui.DialogProgressBG()
    bg.create("Addò-flix Live", ch["name"])
    st = {"open": True}

    def close():
        if st["open"]:
            st["open"] = False
            bg.close()

    def status(t):
        if st["open"]:
            bg.update(message=t)

    res = live.FAIL
    try:
        res = live.watch(ch, status, on_start=close, first=first)
    except Exception as ex:
        xbmc.log("[veloceflix] live error: %r" % (ex,), xbmc.LOGERROR)
    finally:
        close()
        _live["busy"] = False
    if res == live.FAIL:
        xbmcgui.Dialog().ok("Addò-flix Live", "Nessun link di %s funziona in questo momento.\n"
                            "Riprova tra poco o aggiungi un altro link (tieni premuto OK sul canale)." % ch["name"])


def live_context(e):
    """Menu del canale. Ritorna True se i canali sono cambiati."""
    what, link = livemenu.channel_menu(e)
    if what == "play":
        live_play(e, link)
    return what == "changed"


def _meta(e):
    parts = [e["year"], "Serie TV" if e["type"] == "tv" else "Film"]
    if e["vote"]:
        parts.append("★ %s" % e["vote"])
    return "   ·   ".join(p for p in parts if p)


def _entry(li):
    try:
        return json.loads(li.getProperty("data"))
    except Exception:
        return None


# ---------------------------------------------------------------- dettaglio
class Detail(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.e = k["entry"]
        self.busy = False
        self.changed = False
        self.closed = False   # finestra chiusa: il thread non la tocca piu'
        self.worker = None

    def onInit(self):
        e = self.e
        self.setProperty("Title", e["title"])
        self.setProperty("Year", e["year"] or "-")
        self.setProperty("Kind", "Serie TV" if e["type"] == "tv" else "Film")
        self.setProperty("Rating", "%s" % e["vote"] if e["vote"] else "")
        self.setProperty("Plot", e["plot"] or "Nessuna trama disponibile.")
        self.setProperty("Poster", e["poster"])
        self.setProperty("Backdrop", e["backdrop"])
        self._lbl()
        self.setFocusId(20)

    def _lbl(self):
        inl = store.in_list(self.e)
        self.setProperty("ListLabel", "Nella mia lista" if inl else "Aggiungi alla mia lista")
        self.setProperty("InList", "1" if inl else "")
        saved = progress.get(self.e)
        self.setProperty("PlayLabel", "Riprendi" if saved else "Guarda")
        self.setProperty("Resume", progress.label(saved).capitalize() if saved else "")

    def _status(self, txt):
        if self.closed:  # l'utente e' tornato indietro: si interrompe la ricerca
            raise Cancelled()
        self.setProperty("Status", txt)

    def _watch(self):
        try:
            res = source.watch(self.e, self._status)
        except Cancelled:
            res = source.CANCEL
        except Exception as ex:  # mai lasciare la UI bloccata
            xbmc.log("[veloceflix] watch error: %r" % (ex,), xbmc.LOGERROR)
            res = source.FAIL
        self.busy = False
        if res == source.OK:
            store.add_recent(self.e)
            self.changed = True
        if self.closed:
            return
        self.clearProperty("Status")
        self._lbl()
        if res == source.NOTFOUND:
            xbmcgui.Dialog().ok("Addò-flix", "Film non trovato in italiano.")
        elif res == source.NOSOURCE:
            xbmcgui.Dialog().ok("Addò-flix", "Serve l'addon Stream for Me (plugin.video.s4me).")
        elif res == source.FAIL:
            xbmcgui.Dialog().ok("Addò-flix", "Film non trovato: nessun video disponibile in italiano.")

    def onClick(self, cid):
        if cid == 20:
            if self.busy:
                return
            self.busy = True
            self._status("Cerco il film...")
            self.worker = _spawn(self._watch)
        elif cid == 21:
            store.toggle_list(self.e)
            self.changed = True
            self._lbl()
        elif cid == 22:
            self._leave()

    def _leave(self):
        # anche durante la ricerca: il thread si ferma al passo successivo
        self.closed = True
        self.close()

    def onAction(self, action):
        if action.getId() in CLOSE:
            self._leave()


def open_detail(e):
    d = Detail("VeloceFlixDetail.xml", _path, *SKIN, entry=e)
    d.doModal()
    d.closed = True  # un'eventuale ricerca in corso si ferma da sola; run() la aspetta all'uscita
    changed = d.changed
    del d
    return changed


# -------------------------------------------------------------- griglia
class Grid(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.items = k["items"]
        self.heading = k["heading"]
        self.changed = False

    def onInit(self):
        self.setProperty("Heading", self.heading)
        self.getControl(200).addItems([_li(e) for e in self.items])
        self.setFocusId(200)

    def onClick(self, cid):
        if cid == 200:
            e = _entry(self.getControl(200).getSelectedItem())
            if e and e.get("type") == "live":
                live_play(e)
            elif e and open_detail(e):
                self.changed = True

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.close()
        elif action.getId() in CONTEXT and self.getFocusId() == 200:
            e = _entry(self.getControl(200).getSelectedItem())
            if e and e.get("type") == "live" and live_context(e):
                self.changed = True
                self.close()  # la home si ridisegna con le modifiche


# --------------------------------------------------------------- ricerca
KEYS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")


class Search(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.text = ""
        self.cur = 0  # posizione del cursore nel testo
        self.token = 0
        self.sugg = []
        self.changed = False
        self.closed = False

    def onInit(self):
        self.getControl(300).addItems([xbmcgui.ListItem(k) for k in KEYS])
        self._show()
        self._load()
        self.setFocusId(300)

    def _show(self):
        t, c = self.text, self.cur
        start, n = 0, 22  # caratteri visibili nel campo: la finestra segue il cursore
        if len(t) > n:
            start = max(0, min(c - n // 2, len(t) - n))
        vis = t[start:start + n]
        cc = c - start
        esc = lambda x: x.replace("[", "(").replace("]", ")")
        self.setProperty("Query", "%s%s[COLOR %s]|[/COLOR]%s%s" % (
            "…" if start else "", esc(vis[:cc]), ACC, esc(vis[cc:]), "…" if start + n < len(t) else ""))
        self.setProperty("HasText", "1" if self.text else "")

    def _load(self):
        self.token += 1
        _spawn(self._worker, self.token, self.text)

    def _worker(self, token, text):
        try:
            self._fill(token, text)
        except Exception as ex:
            xbmc.log("[veloceflix] suggerimenti: %r" % (ex,), xbmc.LOGERROR)

    def _fill(self, token, text):
        if text:
            time.sleep(0.3)  # attende che l'utente finisca di digitare
            if token != self.token or self.closed:
                return
            res = tmdb.suggest(text)
            head = "Suggerimenti"
        else:
            res = tmdb.trending_all()
            head = "Di tendenza oggi"
        if token != self.token or self.closed:
            return
        self.sugg = res
        lst = self.getControl(400)
        lst.reset()
        for e in res:
            kind = "Serie TV" if e["type"] == "tv" else "Film"
            li = xbmcgui.ListItem(e["title"], "%s  ·  %s" % (e["year"], kind) if e["year"] else kind)
            li.setArt({"poster": e["poster"], "thumb": e["poster"]})
            li.setProperty("data", json.dumps(e))
            lst.addItem(li)
        self.setProperty("SuggHead", head if res else ("Nessun suggerimento" if text else ""))

    def _set(self, text, cur=None):
        self.text = text[:40]
        self.cur = len(self.text) if cur is None else max(0, min(cur, len(self.text)))
        self._show()
        self._load()

    def _insert(self, s):
        t, c = self.text, self.cur
        if len(t) + len(s) > 40:
            return
        self._set(t[:c] + s + t[c:], c + len(s))

    def onClick(self, cid):
        t, c = self.text, self.cur
        if cid == 300:
            self._insert(self.getControl(300).getSelectedItem().getLabel().lower())
        elif cid == 301:  # spazio, mai doppio e mai all'inizio
            if c > 0 and t[c - 1] != " " and t[c:c + 1] != " ":
                self._insert(" ")
        elif cid == 302:  # cancella il carattere prima del cursore
            if c > 0:
                self._set(t[:c - 1] + t[c:], c - 1)
        elif cid in (305, 306):  # sposta il cursore indietro / avanti
            self.cur = max(0, c - 1) if cid == 305 else min(len(t), c + 1)
            self._show()
        elif cid == 303:
            r = xbmcgui.Dialog().input("Cerca film o serie", self.text, type=xbmcgui.INPUT_ALPHANUM)
            if r is not None:
                self._set(r)
        elif cid == 304:
            self._all()
        elif cid == 400:
            e = _entry(self.getControl(400).getSelectedItem())
            if e and open_detail(e):
                self.changed = True

    def _all(self):
        t = self.text.strip()
        if not t:
            return
        res = tmdb.search(t)
        if not res:
            xbmcgui.Dialog().notification("Addò-flix", "Nessun risultato", xbmcgui.NOTIFICATION_INFO, 2500)
            return
        g = Grid("VeloceFlixGrid.xml", _path, *SKIN, items=res, heading='Risultati per "%s"' % t)
        g.doModal()
        if g.changed:
            self.changed = True
        del g

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.closed = True
            self.close()


# ------------------------------------------------------------------ home
class Home(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.alive = True
        self.started = False
        self.tmdb_rows = []
        self.top = 0
        self.last = None
        self.mode = "vod"        # si parte sempre da Film e serie; il Live lo sceglie l'utente
        self.live_rows = None    # righe Live (si ricalcolano dopo modifiche o aggiornamenti)
        # le righe si ridisegnano sia dal thread di caricamento sia dai tasti: mai insieme
        self.ui = threading.RLock()

    # -- dati
    def rows(self):
        if self.mode == "live":
            if self.live_rows is None:
                try:
                    self.live_rows = livemenu.rows()
                except Exception as ex:
                    xbmc.log("[veloceflix] righe live: %r" % (ex,), xbmc.LOGERROR)
                    self.live_rows = [("Gestisci canali", livemenu.action_entries())]
            return self.live_rows
        r = []
        cw = progress.continue_watching()
        if cw:
            r.append(("Continua a guardare", cw))
        if store.get("recent"):
            r.append(("Visti di recente", store.get("recent")))
        if store.get("mylist"):
            r.append(("La mia lista", store.get("mylist")))
        return r + self.tmdb_rows

    def onInit(self):
        if self.started:
            return
        self.started = True
        self.setProperty("Mode", "vod")
        self.setProperty("Loading", "1")
        _spawn(self._boot)
        _spawn(self._hero_loop)

    def _boot(self, refresh=False):
        self.tmdb_rows = []
        self.top = 0
        first = True
        try:
            if refresh:
                tmdb.clear_cache()
                sc.clear()
            if not tmdb.has_key():
                xbmcgui.Dialog().ok("Addò-flix", "Manca la chiave TMDB: inseriscila nelle impostazioni dell'addon (gratis su themoviedb.org) oppure installa Stream for Me.")
            else:
                for title, entries in tmdb.home_rows():
                    if not self.alive:
                        return
                    # solo i titoli presenti su StreamingCommunity (ITA): niente "film non trovato"
                    ok = sc.filter_available(entries, alive=lambda: self.alive)
                    if not self.alive:
                        return
                    if not ok:
                        continue
                    self.tmdb_rows.append((title, ok))
                    if self.mode != "vod":  # l'utente e' nel Live: si carica senza ridisegnare
                        first = False
                        continue
                    n = len(self.rows())
                    if first:
                        first = False
                        self.render(focus=ROW_A)
                        self.clearProperty("Loading")
                    elif n - 1 <= self.top + 1:  # la riga nuova e' tra quelle visibili
                        self._personal_refresh()
        except Exception as ex:
            xbmc.log("[veloceflix] boot error: %r" % (ex,), xbmc.LOGERROR)
        if not self.alive:
            return
        if first and self.mode == "vod":  # nessuna riga TMDB: mostra almeno recenti/lista
            self.render(focus=ROW_A if self.rows() else BTN_SEARCH)
        self.clearProperty("Loading")

    # -- disegno delle due righe visibili
    def render(self, focus=None, pos=0):
        with self.ui:
            if self.alive:
                self._render(focus, pos)

    def _render(self, focus, pos):
        rows = self.rows()
        n = len(rows)
        self.top = max(0, min(self.top, n - 1))
        for slot, rid, key in ((0, ROW_A, "Row1"), (1, ROW_B, "Row2")):
            c = self.getControl(rid)
            c.reset()
            i = self.top + slot
            if i < n:
                self.setProperty(key, rows[i][0])
                c.addItems([_li(e) for e in rows[i][1]])
            else:
                self.clearProperty(key)
        self.setProperty("CanUp", "1" if self.top > 0 else "")
        self.setProperty("CanDown", "1" if self.top + 1 < n else "")
        self.last = None
        if focus:
            self.setFocusId(focus)
            if focus in (ROW_A, ROW_B) and pos:
                c = self.getControl(focus)
                c.selectItem(min(pos, max(0, c.size() - 1)))

    def _shift(self, delta):
        """Scorre di una riga in su/giu mantenendo la colonna selezionata."""
        with self.ui:
            from_id = ROW_A
            pos = self.getControl(from_id).getSelectedPosition()
            self.top += delta
            self.render(focus=from_id, pos=pos)

    def _scroll(self, delta):
        """Scorrimento da touch/mouse: solo se c'e' una riga in quella direzione."""
        if (delta > 0 and self.top + 1 < len(self.rows())) or (delta < 0 and self.top > 0):
            self._shift(delta)

    def onFocus(self, cid):
        if cid == GUARD_DOWN:
            if self.top + 1 < len(self.rows()):
                self._shift(+1)
            else:
                self.setFocusId(ROW_A)
        elif cid == GUARD_UP:
            if self.top > 0:
                self._shift(-1)
            else:
                self.setFocusId(BTN_SEARCH)

    # -- hero che segue il focus
    def _hero_loop(self):
        mon = xbmc.Monitor()
        while self.alive and not mon.waitForAbort(0.15):
            try:
                with self.ui:
                    if self.alive:
                        self._hero_once()
            except Exception:
                pass

    def _hero_once(self):
        fid = self.getFocusId()
        if fid not in (ROW_A, ROW_B):
            return
        li = self.getControl(fid).getSelectedItem()
        if li is None:
            return
        key = (fid, li.getProperty("data"))
        if key == self.last:
            return
        e = _entry(li)
        if not e:
            return
        self.last = key
        self._show_hero(e)

    def _show_hero(self, e):
        if e.get("type") in ("live", "action"):
            title, meta, plot = livemenu.hero(e)
            self.setProperty("HeroTitle", title)
            self.setProperty("HeroMeta", meta)
            self.setProperty("HeroRating", "")
            self.setProperty("HeroPlot", plot)
            self.setProperty("HeroBackdrop", "")
            return
        self.setProperty("HeroTitle", e["title"])
        meta = "%s   \u00b7   %s" % (e["year"], "Serie TV" if e["type"] == "tv" else "Film")
        saved = progress.get(e)
        if saved:
            meta += "   \u00b7   Riprendi %s" % progress.label(saved)
        self.setProperty("HeroMeta", meta)
        self.setProperty("HeroRating", "%s" % e["vote"] if e["vote"] else "")
        self.setProperty("HeroPlot", e["plot"])
        self.setProperty("HeroBackdrop", e["backdrop"])

    # -- eventi
    # -- Live
    def set_mode(self, mode):
        with self.ui:
            if mode == self.mode or not self.alive:
                return
            self.mode = mode
            self.setProperty("Mode", mode)
            self.top = 0
            self.live_rows = None
            # la selezione resta sull'interruttore: un altro OK torna indietro, freccia giu' va alle righe
            self.render(focus=BTN_MODE)
            rows = self.rows()
            if rows and rows[0][1]:  # riquadro in alto: il primo titolo/canale della nuova modalita'
                self._show_hero(rows[0][1][0])
            else:
                for k in ("HeroTitle", "HeroMeta", "HeroRating", "HeroPlot", "HeroBackdrop"):
                    self.clearProperty(k)
        if mode == "live" and progress.setting("live_url", ""):
            _spawn(self._live_sync, False)

    def _live_sync(self, force):
        n = live.sync(force)
        if force:
            if n < 0:
                xbmcgui.Dialog().notification("Addò-flix Live", "Lista online non raggiungibile: uso l'ultima copia",
                                              xbmcgui.NOTIFICATION_INFO, 3000)
            self.clearProperty("Loading")
        self._live_reload()

    def _live_reload(self):
        with self.ui:
            if self.alive and self.mode == "live":
                self.live_rows = None
                self._personal_refresh()

    def _live_search(self):
        t = xbmcgui.Dialog().input("Cerca canale", type=xbmcgui.INPUT_ALPHANUM)
        if not t:
            return
        res = livemenu.search(t)
        if not res:
            xbmcgui.Dialog().notification("Addò-flix Live", "Nessun canale trovato", xbmcgui.NOTIFICATION_INFO, 2500)
            return
        g = Grid("VeloceFlixGrid.xml", _path, *SKIN, items=res, heading='Canali: "%s"' % t)
        g.doModal()
        changed = g.changed
        del g
        if changed:
            self._live_reload()

    def onClick(self, cid):
        if cid in (ROW_A, ROW_B):
            e = _entry(self.getControl(cid).getSelectedItem())
            if not e:
                return
            if e.get("type") == "live":
                live_play(e)
            elif e.get("type") == "action":
                if livemenu.do_action(e["id"]):
                    self._live_reload()
            else:
                open_detail(e)
                self._personal_refresh()
        elif cid == BTN_MODE:
            self.set_mode("vod" if self.mode == "live" else "live")
        elif cid == BTN_SEARCH and self.mode == "live":
            self._live_search()
        elif cid == BTN_REFRESH and self.mode == "live":
            self.setProperty("Loading", "1")
            _spawn(self._live_sync, True)
        elif cid == BTN_SEARCH:
            s = Search("VeloceFlixSearch.xml", _path, *SKIN)
            s.doModal()
            s.closed = True
            del s
            self._personal_refresh()
        elif cid in (BTN_UP, BTN_DOWN):
            self._scroll(-1 if cid == BTN_UP else +1)
        elif cid == 12:  # impostazioni dell'addon (avvio automatico, chiave TMDB)
            xbmcaddon.Addon("plugin.video.veloceflix").openSettings()
        elif cid == BTN_REFRESH:
            self.setProperty("Loading", "1")
            _spawn(self._boot, True)

    def _personal_refresh(self):
        with self.ui:
            if not self.alive:
                return
            fid = self.getFocusId()
            pos = self.getControl(fid).getSelectedPosition() if fid in (ROW_A, ROW_B) else 0
            self.render(focus=fid if fid in (ROW_A, ROW_B, BTN_SEARCH, BTN_REFRESH, BTN_MODE) else ROW_A, pos=pos)

    def onAction(self, action):
        aid = action.getId()
        if aid in CLOSE:
            self.alive = False
            self.close()
        elif aid in CONTEXT and self.mode == "live" and self.getFocusId() in (ROW_A, ROW_B):
            e = _entry(self.getControl(self.getFocusId()).getSelectedItem())
            if e and e.get("type") == "live" and live_context(e):
                self._live_reload()
        elif aid in SWIPE_UP or aid == WHEEL_DOWN:
            self._scroll(+1)
        elif aid in SWIPE_DOWN or aid == WHEEL_UP:
            self._scroll(-1)


def run(addon):
    global _path
    _path = addon.getAddonInfo("path")
    if not xbmc.Player().isPlaying():
        progress.restore_quality()  # dopo un crash durante la visione
    w = Home("VeloceFlixHome.xml", _path, *SKIN)
    w.doModal()
    w.alive = False
    del w
    # Lo script finisce solo quando tutti i suoi thread sono fermi (la finestra e' gia' chiusa:
    # l'attesa non si vede). Thread vivi alla chiusura dell'interprete possono far cadere Kodi.
    # Il controllo della visione resta vivo finche' il video va (continua a salvare il punto).
    mon = xbmc.Monitor()
    me = threading.current_thread()
    while not mon.abortRequested():
        alive = [t for t in threading.enumerate() if t is not me and t.is_alive() and not t.name.startswith("Dummy")]
        if not alive:
            break
        mon.waitForAbort(0.2)
