﻿import sys
import os
import xbmcaddon

ADDON = xbmcaddon.Addon("plugin.video.veloceflix")
sys.path.insert(0, os.path.join(ADDON.getAddonInfo("path"), "lib"))

import ui

ui.run(ADDON)

