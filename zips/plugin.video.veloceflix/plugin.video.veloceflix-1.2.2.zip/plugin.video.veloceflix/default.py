﻿import sys
import os
import xbmc
import xbmcaddon
import xbmcplugin

ADDON = xbmcaddon.Addon()
sys.path.insert(0, os.path.join(ADDON.getAddonInfo("path"), "lib"))

if __name__ == "__main__":
    # Chiude subito la "cartella" plugin e apre l'interfaccia come script separato
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    except Exception:
        pass
    xbmc.executebuiltin("RunScript(%s)" % os.path.join(ADDON.getAddonInfo("path"), "launcher.py"))

