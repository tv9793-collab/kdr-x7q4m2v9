import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import tmdb
import store
import source
import sc

SKIN = ("default", "1080i")
CLOSE = (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU)
ROW_A, ROW_B = 101, 102          # le due righe visibili
GUARD_UP, GUARD_DOWN = 121, 120  # controlli "sentinella" per scorrere le righe
BTN_SEARCH, BTN_REFRESH = 10, 11
_path = ""


def _li(e):
    li = xbmcgui.ListItem(e["title"])
    li.setArt({"poster": e["poster"], "thumb": e["poster"]})
    li.setProperty("data", json.dumps(e))
    return li


def _meta(e):
    parts = [e["year"], "Serie TV" if e["type"] == "tv" else "Film"]
    if e["vote"]:
        parts.append("★ %s" % e["vote"])
    return "   ·   ".join(p for p in parts if p)


def _entry(li):
    try:
        return json.loads(li.getProperty("data"))
    except Exception:
        return None


# ---------------------------------------------------------------- dettaglio
class Detail(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.e = k["entry"]
        self.busy = False
        self.changed = False

    def onInit(self):
        e = self.e
        self.setProperty("Title", e["title"])
        self.setProperty("Year", e["year"] or "-")
        self.setProperty("Kind", "Serie TV" if e["type"] == "tv" else "Film")
        self.setProperty("Rating", "%s" % e["vote"] if e["vote"] else "")
        self.setProperty("Plot", e["plot"] or "Nessuna trama disponibile.")
        self.setProperty("Poster", e["poster"])
        self.setProperty("Backdrop", e["backdrop"])
        self._lbl()
        self.setFocusId(20)

    def _lbl(self):
        inl = store.in_list(self.e)
        self.setProperty("ListLabel", "Nella mia lista" if inl else "Aggiungi alla mia lista")
        self.setProperty("InList", "1" if inl else "")

    def _status(self, txt):
        self.setProperty("Status", txt)

    def _watch(self):
        try:
            res = source.watch(self.e, self._status)
        except Exception as ex:  # mai lasciare la UI bloccata
            xbmc.log("[veloceflix] watch error: %r" % (ex,), xbmc.LOGERROR)
            res = source.FAIL
        self.clearProperty("Status")
        self.busy = False
        if res == source.OK:
            store.add_recent(self.e)
            self.changed = True
        elif res == source.NOTFOUND:
            xbmcgui.Dialog().ok("Addò-flix", "Film non trovato in italiano.")
        elif res == source.NOSOURCE:
            xbmcgui.Dialog().ok("Addò-flix", "Serve l'addon Stream for Me (plugin.video.s4me).")
        elif res == source.FAIL:
            xbmcgui.Dialog().ok("Addò-flix", "Film non trovato: nessun video disponibile in italiano.")

    def onClick(self, cid):
        if cid == 20:
            if self.busy:
                return
            self.busy = True
            self._status("Cerco il film...")
            threading.Thread(target=self._watch, daemon=True).start()
        elif cid == 21:
            store.toggle_list(self.e)
            self.changed = True
            self._lbl()
        elif cid == 22:
            self.close()

    def onAction(self, action):
        if action.getId() in CLOSE and not self.busy:
            self.close()


def open_detail(e):
    d = Detail("VeloceFlixDetail.xml", _path, *SKIN, entry=e)
    d.doModal()
    changed = d.changed
    del d
    return changed


# -------------------------------------------------------------- griglia
class Grid(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.items = k["items"]
        self.heading = k["heading"]
        self.changed = False

    def onInit(self):
        self.setProperty("Heading", self.heading)
        self.getControl(200).addItems([_li(e) for e in self.items])
        self.setFocusId(200)

    def onClick(self, cid):
        if cid == 200:
            e = _entry(self.getControl(200).getSelectedItem())
            if e and open_detail(e):
                self.changed = True

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.close()


# --------------------------------------------------------------- ricerca
KEYS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")


class Search(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.text = ""
        self.token = 0
        self.sugg = []
        self.changed = False

    def onInit(self):
        self.getControl(300).addItems([xbmcgui.ListItem(k) for k in KEYS])
        self._show()
        self._load()
        self.setFocusId(300)

    def _show(self):
        self.setProperty("Query", self.text)
        self.setProperty("HasText", "1" if self.text else "")

    def _load(self):
        self.token += 1
        threading.Thread(target=self._worker, args=(self.token, self.text), daemon=True).start()

    def _worker(self, token, text):
        try:
            self._fill(token, text)
        except Exception as ex:
            xbmc.log("[veloceflix] suggerimenti: %r" % (ex,), xbmc.LOGERROR)

    def _fill(self, token, text):
        if text:
            time.sleep(0.3)  # attende che l'utente finisca di digitare
            if token != self.token:
                return
            res = tmdb.suggest(text)
            head = "Suggerimenti"
        else:
            res = tmdb.trending_all()
            head = "Di tendenza oggi"
        if token != self.token:
            return
        self.sugg = res
        lst = self.getControl(400)
        lst.reset()
        for e in res:
            kind = "Serie TV" if e["type"] == "tv" else "Film"
            li = xbmcgui.ListItem(e["title"], "%s  ·  %s" % (e["year"], kind) if e["year"] else kind)
            li.setArt({"poster": e["poster"], "thumb": e["poster"]})
            li.setProperty("data", json.dumps(e))
            lst.addItem(li)
        self.setProperty("SuggHead", head if res else ("Nessun suggerimento" if text else ""))

    def _set(self, text):
        self.text = text[:40]
        self._show()
        self._load()

    def onClick(self, cid):
        if cid == 300:
            self._set(self.text + self.getControl(300).getSelectedItem().getLabel().lower())
        elif cid == 301:
            self._set(self.text + " " if self.text and not self.text.endswith(" ") else self.text)
        elif cid == 302:
            self._set(self.text[:-1])
        elif cid == 303:
            t = xbmcgui.Dialog().input("Cerca film o serie", self.text, type=xbmcgui.INPUT_ALPHANUM)
            if t is not None:
                self._set(t)
        elif cid == 304:
            self._all()
        elif cid == 400:
            e = _entry(self.getControl(400).getSelectedItem())
            if e and open_detail(e):
                self.changed = True

    def _all(self):
        t = self.text.strip()
        if not t:
            return
        res = tmdb.search(t)
        if not res:
            xbmcgui.Dialog().notification("Addò-flix", "Nessun risultato", xbmcgui.NOTIFICATION_INFO, 2500)
            return
        g = Grid("VeloceFlixGrid.xml", _path, *SKIN, items=res, heading='Risultati per "%s"' % t)
        g.doModal()
        if g.changed:
            self.changed = True
        del g

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.close()


# ------------------------------------------------------------------ home
class Home(xbmcgui.WindowXML):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.alive = True
        self.started = False
        self.tmdb_rows = []
        self.top = 0
        self.last = None

    # -- dati
    def rows(self):
        r = []
        if store.get("recent"):
            r.append(("Visti di recente", store.get("recent")))
        if store.get("mylist"):
            r.append(("La mia lista", store.get("mylist")))
        return r + self.tmdb_rows

    def onInit(self):
        if self.started:
            return
        self.started = True
        self.setProperty("Loading", "1")
        threading.Thread(target=self._boot, daemon=True).start()
        threading.Thread(target=self._hero_loop, daemon=True).start()

    def _boot(self, refresh=False):
        self.tmdb_rows = []
        self.top = 0
        first = True
        try:
            if refresh:
                tmdb.clear_cache()
                sc.clear()
            if not tmdb.has_key():
                xbmcgui.Dialog().ok("Addò-flix", "Manca la chiave TMDB: inseriscila nelle impostazioni dell'addon (gratis su themoviedb.org) oppure installa Stream for Me.")
            else:
                for title, entries in tmdb.home_rows():
                    if not self.alive:
                        return
                    # solo i titoli presenti su StreamingCommunity (ITA): niente "film non trovato"
                    ok = sc.filter_available(entries)
                    if not ok:
                        continue
                    self.tmdb_rows.append((title, ok))
                    n = len(self.rows())
                    if first:
                        first = False
                        self.render(focus=ROW_A)
                        self.clearProperty("Loading")
                    elif n - 1 <= self.top + 1:  # la riga nuova e' tra quelle visibili
                        self._personal_refresh()
        except Exception as ex:
            xbmc.log("[veloceflix] boot error: %r" % (ex,), xbmc.LOGERROR)
        if first:  # nessuna riga TMDB: mostra almeno recenti/lista
            self.render(focus=ROW_A if self.rows() else BTN_SEARCH)
        self.clearProperty("Loading")

    # -- disegno delle due righe visibili
    def render(self, focus=None, pos=0):
        rows = self.rows()
        n = len(rows)
        self.top = max(0, min(self.top, n - 1))
        for slot, rid, key in ((0, ROW_A, "Row1"), (1, ROW_B, "Row2")):
            c = self.getControl(rid)
            c.reset()
            i = self.top + slot
            if i < n:
                self.setProperty(key, rows[i][0])
                c.addItems([_li(e) for e in rows[i][1]])
            else:
                self.clearProperty(key)
        self.last = None
        if focus:
            self.setFocusId(focus)
            if focus in (ROW_A, ROW_B) and pos:
                c = self.getControl(focus)
                c.selectItem(min(pos, max(0, c.size() - 1)))

    def _shift(self, delta):
        """Scorre di una riga in su/giu mantenendo la colonna selezionata."""
        from_id = ROW_A
        pos = self.getControl(from_id).getSelectedPosition()
        self.top += delta
        self.render(focus=from_id, pos=pos)

    def onFocus(self, cid):
        if cid == GUARD_DOWN:
            if self.top + 1 < len(self.rows()):
                self._shift(+1)
            else:
                self.setFocusId(ROW_A)
        elif cid == GUARD_UP:
            if self.top > 0:
                self._shift(-1)
            else:
                self.setFocusId(BTN_SEARCH)

    # -- hero che segue il focus
    def _hero_loop(self):
        mon = xbmc.Monitor()
        while self.alive and not mon.waitForAbort(0.15):
            try:
                fid = self.getFocusId()
                if fid in (ROW_A, ROW_B):
                    li = self.getControl(fid).getSelectedItem()
                    if li is not None:
                        key = (fid, li.getProperty("data"))
                        if key != self.last:
                            e = _entry(li)
                            if e:
                                self.last = key
                                self.setProperty("HeroTitle", e["title"])
                                self.setProperty("HeroMeta", "%s   \u00b7   %s" % (e["year"], "Serie TV" if e["type"] == "tv" else "Film"))
                                self.setProperty("HeroRating", "%s" % e["vote"] if e["vote"] else "")
                                self.setProperty("HeroPlot", e["plot"])
                                self.setProperty("HeroBackdrop", e["backdrop"])
            except Exception:
                pass

    # -- eventi
    def onClick(self, cid):
        if cid in (ROW_A, ROW_B):
            e = _entry(self.getControl(cid).getSelectedItem())
            if e:
                open_detail(e)
                self._personal_refresh()
        elif cid == BTN_SEARCH:
            s = Search("VeloceFlixSearch.xml", _path, *SKIN)
            s.doModal()
            del s
            self._personal_refresh()
        elif cid == 12:  # impostazioni dell'addon (avvio automatico, chiave TMDB)
            xbmcaddon.Addon("plugin.video.veloceflix").openSettings()
        elif cid == BTN_REFRESH:
            self.setProperty("Loading", "1")
            threading.Thread(target=self._boot, args=(True,), daemon=True).start()

    def _personal_refresh(self):
        fid = self.getFocusId()
        pos = self.getControl(fid).getSelectedPosition() if fid in (ROW_A, ROW_B) else 0
        self.render(focus=fid if fid in (ROW_A, ROW_B, BTN_SEARCH, BTN_REFRESH) else ROW_A, pos=pos)

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.alive = False
            self.close()


def run(addon):
    global _path
    _path = addon.getAddonInfo("path")
    w = Home("VeloceFlixHome.xml", _path, *SKIN)
    w.doModal()
    w.alive = False
    del w
