"""Accesso a TMDB con cache su file (leggero per box con poca RAM)."""
import gzip
import json
import os
import re
import time
import threading
import urllib.parse
import urllib.request

import xbmcaddon
import xbmcvfs

HOST = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/"
TTL = 12 * 3600

_ADDON = xbmcaddon.Addon("plugin.video.veloceflix")
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_CACHE = os.path.join(_PROFILE, "cache")


def _key():
    k = _ADDON.getSetting("tmdb_key").strip()
    if k:
        return k
    # fallback: chiave di Stream for Me, se installato sul dispositivo
    p = xbmcvfs.translatePath("special://home/addons/plugin.video.s4me/core/tmdb.py")
    try:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            m = re.search(r"^api\s*=\s*'([0-9a-f]{32})'", f.read(), re.M)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ""


def has_key():
    return bool(_key())


def _get(path, params=None, cache=True):
    params = dict(params or {})
    params["api_key"] = _key()
    params.setdefault("language", _ADDON.getSetting("lang") or "it-IT")
    q = urllib.parse.urlencode(sorted(params.items()))
    name = re.sub(r"[^a-z0-9]+", "_", (path + "_" + q.replace(params["api_key"], "")).lower())[:120] + ".json"
    fn = os.path.join(_CACHE, name)
    if cache and os.path.exists(fn) and time.time() - os.path.getmtime(fn) < TTL:
        try:
            with open(fn, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    req = urllib.request.Request(HOST + path + "?" + q, headers={"User-Agent": "VeloceFlix/1.0", "Accept-Encoding": "gzip"})
    with urllib.request.urlopen(req, timeout=15) as r:
        raw = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        data = json.loads(raw.decode("utf-8"))
    try:
        os.makedirs(_CACHE, exist_ok=True)
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass
    return data


def clear_cache():
    if os.path.isdir(_CACHE):
        for n in os.listdir(_CACHE):
            try:
                os.remove(os.path.join(_CACHE, n))
            except Exception:
                pass


def norm(r, default_type=None):
    t = r.get("media_type") or default_type or ("tv" if "name" in r else "movie")
    if t not in ("movie", "tv"):
        return None
    title = r.get("title") or r.get("name") or ""
    date = r.get("release_date") or r.get("first_air_date") or ""
    return {
        "id": r.get("id"),
        "type": t,
        "title": title,
        "orig": r.get("original_title") or r.get("original_name") or "",
        "year": date[:4],
        "plot": r.get("overview") or "",
        "poster": (IMG + "w342" + r["poster_path"]) if r.get("poster_path") else "",
        "backdrop": (IMG + "w780" + r["backdrop_path"]) if r.get("backdrop_path") else "",
        "vote": round(r.get("vote_average") or 0, 1),
    }


def _list(path, default_type=None, params=None):
    try:
        res = _get(path, params).get("results", [])
    except Exception:
        return []
    out = [norm(r, default_type) for r in res]
    return [x for x in out if x and x["title"]][:20]


ROWS = [
    ("Film in tendenza", "/trending/movie/week", "movie", None),
    ("Serie TV in tendenza", "/trending/tv/week", "tv", None),
    ("Al cinema", "/movie/now_playing", "movie", {"region": "IT"}),
    ("I più votati", "/movie/top_rated", "movie", None),
]


def home_rows():
    """Scarica le righe in parallelo; ritorna [(titolo, [items])]."""
    res = [None] * len(ROWS)

    def work(i):
        t, p, d, prm = ROWS[i]
        res[i] = _list(p, d, prm)

    th = [threading.Thread(target=work, args=(i,)) for i in range(len(ROWS))]
    [t.start() for t in th]
    [t.join() for t in th]
    return [(ROWS[i][0], res[i]) for i in range(len(ROWS)) if res[i]]


def search(text):
    try:
        res = _get("/search/multi", {"query": text, "include_adult": "false"}, cache=False).get("results", [])
    except Exception:
        return []
    out = [norm(r) for r in res]
    return [x for x in out if x and x["title"]]



def suggest(text, n=8):
    """Suggerimenti di completamento mentre si scrive (film e serie)."""
    q = re.sub(r"\s+", " ", text.strip().lower())
    res = search(text)
    # prima i titoli che iniziano con quanto scritto (completamento), poi gli altri
    def rank(e):
        t = e["title"].lower()
        if t.startswith(q):
            return 0
        return 1 if any(w.startswith(q) for w in re.split(r"[^\w]+", t)) else 2
    res.sort(key=rank)
    return res[:n]


def trending_all(n=8):
    try:
        res = _get("/trending/all/day").get("results", [])
    except Exception:
        return []
    out = [norm(r) for r in res]
    return [x for x in out if x and x["title"]][:n]
