"""Disponibilita' dei titoli su StreamingCommunity (ITA), con cache su disco.

Serve a mostrare in home solo i titoli che "Guarda" riuscira' ad avviare.
Ottimizzato per connessioni lente: risposte gzip, formato JSON compatto (Inertia), connessioni HTTPS
riutilizzate per thread, cache 7 giorni (esito positivo) / 2 giorni (negativo).
"""
import gzip
import html
import http.client
import json
import os
import re
import ssl
import threading
import time
import unicodedata
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon
import xbmcvfs

S4ME = "plugin.video.s4me"
CHANNEL = "streamingcommunity"
UA = "Mozilla/5.0 (Linux; Android 8.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
TTL_YES, TTL_NO = 7 * 86400, 2 * 86400

_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.veloceflix").getAddonInfo("profile"))
_FILE = os.path.join(_PROFILE, "avail2.json")
_lock = threading.Lock()
_tl = threading.local()
_state = {"version": None, "cache": None}
_ctx = ssl.create_default_context()


def host():
    p = xbmcvfs.translatePath("special://home/addons/%s/channels.json" % S4ME)
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)["direct"][CHANNEL].rstrip("/")
    except Exception:
        return ""


def norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()
    return re.sub(r"^(il|lo|la|i|gli|le|l|the|a|an) ", "", s)


# ---------------------------------------------------------------- cache
def _cache():
    if _state["cache"] is None:
        try:
            with open(_FILE, "r", encoding="utf-8") as f:
                _state["cache"] = json.load(f)
        except Exception:
            _state["cache"] = {}
    return _state["cache"]


def _save():
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with _lock, open(_FILE, "w", encoding="utf-8") as f:
            json.dump(_cache(), f)
    except Exception:
        pass


def clear():
    _state["cache"] = {}
    try:
        os.remove(_FILE)
    except Exception:
        pass


def _known(key):
    v = _cache().get(key)
    if not v:
        return None
    age = time.time() - v[0]
    if age < (TTL_YES if v[1] else TTL_NO):
        return v[1]
    return None


# ----------------------------------------------------------------- http
def _conn(netloc):
    c = getattr(_tl, "conn", None)
    if c is None:
        c = http.client.HTTPSConnection(netloc, timeout=15, context=_ctx)
        _tl.conn = c
    return c


def _drop():
    c = getattr(_tl, "conn", None)
    if c is not None:
        try:
            c.close()
        except Exception:
            pass
    _tl.conn = None


def _get_text(h, path, inertia=False):
    netloc = urllib.parse.urlparse(h).netloc
    for _ in range(2):
        try:
            headers = {"User-Agent": UA, "Accept-Encoding": "gzip", "Accept": "text/html, application/xhtml+xml"}
            use_json = inertia and _state["version"]
            if use_json:
                headers.update({"X-Inertia": "true", "X-Inertia-Version": _state["version"], "X-Requested-With": "XMLHttpRequest"})
            c = _conn(netloc)
            c.request("GET", path, headers=headers)
            r = c.getresponse()
            body = r.read()
            if r.getheader("Content-Encoding") == "gzip":
                body = gzip.decompress(body)
            if r.status == 409 and use_json:  # versione cambiata: si ricarica l'HTML
                _state["version"] = None
                continue
            if r.status != 200:
                _drop()
                continue
            return body.decode("utf-8", "ignore")
        except Exception:
            _drop()
    return None


def _fetch(h, path):
    """Ritorna il dict 'props' della pagina (JSON compatto se possibile) oppure None."""
    text = _get_text(h, path, inertia=True)
    if text is None:
        return None
    try:
        if text.lstrip().startswith("{"):
            return json.loads(text).get("props")
        m = re.search(r'data-page="([^"]+)', text)
        if not m:
            return None
        page = json.loads(html.unescape(m.group(1)))
        _state["version"] = page.get("version") or _state["version"]
        return page.get("props")
    except Exception:
        return None


def movie_playable(title_id):
    """Per 'Guarda': True/False, None se non verificabile."""
    h = host()
    if not h:
        return None
    return _playable(h, {"type": "movie", "id": title_id})


def _playable(h, title):
    """Un film e' riproducibile solo se la pagina player contiene un id video (embed/<numero>)."""
    if title.get("type") != "movie":
        return True
    text = _get_text(h, "/it/iframe/%s" % title.get("id"))
    if text is None:
        return None
    return bool(re.search(r"/embed/\d+", text))


def _search(h, term):
    props = _fetch(h, "/it/search?q=" + urllib.parse.quote(term))
    return None if props is None else (props.get("titles") or [])


def _match(titles, e):
    want = "tv" if e["type"] == "tv" else "movie"
    names = {norm(e.get("title")), norm(e.get("orig"))} - {""}
    for t in titles:
        if t.get("type") != want or t.get("sub_ita"):
            continue
        if norm(t.get("name")) not in names:
            continue
        if want == "movie":
            try:
                y1, y2 = int((t.get("last_air_date") or "")[:4]), int(e.get("year") or 0)
                if y2 and abs(y1 - y2) > 1:
                    continue
            except Exception:
                pass
        return t
    return None


def _check(h, e):
    """True/False, oppure None se la rete non risponde (non va in cache)."""
    terms = [e["title"]]
    if e.get("orig") and norm(e["orig"]) != norm(e["title"]):
        terms.append(e["orig"])
    for t in terms:
        titles = _search(h, t)
        if titles is None:
            return None
        found = _match(titles, e)
        if found:
            return _playable(h, found)
    return False


def filter_available(entries):
    """Tiene solo i titoli presenti su StreamingCommunity. Se il sito non e' raggiungibile li tiene tutti."""
    h = host()
    if not h or not entries:
        return list(entries)
    result = {}
    todo = []
    for e in entries:
        k = "%s:%s" % (e["type"], e["id"])
        v = _known(k)
        if v is None:
            todo.append((k, e))
        else:
            result[k] = v
    if todo:
        # la prima richiesta ottiene la versione del sito: poi le altre usano il formato compatto
        first = todo[0]
        out = {first[0]: _check(h, first[1])}
        rest = todo[1:]
        if rest:
            with ThreadPoolExecutor(max_workers=6) as ex:
                for (k, _e), v in zip(rest, ex.map(lambda kv: _check(h, kv[1]), rest)):
                    out[k] = v
        errors = [k for k, v in out.items() if v is None]
        for k, v in out.items():
            if v is None:
                result[k] = True  # rete in errore: meglio mostrarlo che nasconderlo
            else:
                result[k] = v
                _cache()[k] = [time.time(), v]
        if len(errors) < len(out):
            _save()
        xbmc.log("[veloceflix] sc check: %d richieste, %d errori" % (len(out), len(errors)), xbmc.LOGINFO)
    return [e for e in entries if result.get("%s:%s" % (e["type"], e["id"]), True)]
