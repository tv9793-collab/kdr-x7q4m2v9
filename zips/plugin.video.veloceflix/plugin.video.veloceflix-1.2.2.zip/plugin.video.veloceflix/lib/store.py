﻿"""La mia lista e Visti di recente, in JSON nel profilo dell'addon."""
import json
import os
import xbmcaddon
import xbmcvfs

_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.veloceflix").getAddonInfo("profile"))
_FILE = os.path.join(_PROFILE, "store.json")


def _load():
    try:
        with open(_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    d.setdefault("mylist", [])
    d.setdefault("recent", [])
    return d


def _save(d):
    os.makedirs(_PROFILE, exist_ok=True)
    with open(_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f)


def get(name):
    return _load()[name]


def in_list(e):
    return any(x["id"] == e["id"] and x["type"] == e["type"] for x in get("mylist"))


def toggle_list(e):
    d = _load()
    if in_list(e):
        d["mylist"] = [x for x in d["mylist"] if not (x["id"] == e["id"] and x["type"] == e["type"])]
        added = False
    else:
        d["mylist"].insert(0, e)
        added = True
    _save(d)
    return added


def add_recent(e):
    d = _load()
    d["recent"] = [e] + [x for x in d["recent"] if not (x["id"] == e["id"] and x["type"] == e["type"])]
    d["recent"] = d["recent"][:20]
    _save(d)

