"""Avvio diretto di un titolo tramite il canale StreamingCommunity (HD, ITA) di Stream for Me.

Flusso: cerca il titolo sul canale (via JSON-RPC verso plugin.video.s4me), sceglie il risultato
ITA con titolo/anno corrispondenti, poi lancia la riproduzione. Nessuna finestra di ricerca canali.
"""
import base64
import json
import re
import time
import unicodedata
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

S4ME = "plugin.video.s4me"
CHANNEL = "streamingcommunity"
BASE = "plugin://%s/?" % S4ME

OK, NOTFOUND, NOSOURCE, FAIL, CANCEL = "ok", "notfound", "nosource", "fail", "cancel"


def available():
    return xbmc.getCondVisibility("System.HasAddon(%s)" % S4ME)


# ---------- utilita ----------
import sc  # noqa: E402
from sc import host as _host, norm as _norm  # noqa: E402


def _encode(d):
    return BASE + urllib.parse.quote(base64.b64encode(json.dumps(d).encode("utf8")).decode())


def _decode(url):
    try:
        q = url.split("?", 1)[1]
        return json.loads(base64.b64decode(urllib.parse.unquote(q)).decode("utf8"))
    except Exception:
        return {}


def _listdir(url):
    """Elenco file di una cartella plugin (blocca finche' s4me ha finito)."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": url, "media": "files", "properties": ["title"]}}
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return []
    return (r.get("result") or {}).get("files") or []


def _entries(url):
    out = []
    for f in _listdir(url):
        d = _decode(f.get("file", ""))
        if d:
            out.append((f.get("file"), d))
    return out


def _title_ok(cand, e):
    c = _norm(cand)
    return bool(c) and c in (_norm(e.get("title")), _norm(e.get("orig")))


def _year_ok(d, e):
    try:
        y1, y2 = int(d.get("year") or (d.get("infoLabels") or {}).get("year") or 0), int(e.get("year") or 0)
    except Exception:
        return True
    return not y1 or not y2 or abs(y1 - y2) <= 1


def pick(entries, e):
    """Sceglie tra i risultati del canale: stesso tipo, ITA (non Sub-ITA), stesso titolo, anno compatibile."""
    want = "tvshow" if e["type"] == "tv" else "movie"
    best = None
    for url, d in entries:
        if d.get("contentType") != want:
            continue
        if (d.get("language") or "").strip().upper() != "ITA":
            continue
        if d.get("action") not in ("findvideos", "episodios"):
            continue
        name = d.get("fulltitle") or d.get("contentTitle") or d.get("contentSerieName") or ""
        if not (_title_ok(name, e) and _year_ok(d, e)):
            continue
        exact = _norm(name) == _norm(e.get("title"))
        score = 2 if exact else 1
        if best is None or score > best[0]:
            best = (score, url, d)
    return (best[1], best[2]) if best else (None, None)


def search_channel(e, status=None):
    host = _host()
    if not host:
        return None, None
    terms = [e["title"]]
    if e.get("orig") and _norm(e["orig"]) != _norm(e["title"]):
        terms.append(e["orig"])
    for t in terms:
        if status:
            status('Cerco "%s"...' % t)
        item = {"channel": CHANNEL, "action": "peliculas", "search": True, "folder": True,
                "contentType": "tvshow" if e["type"] == "tv" else "movie",
                "url": "%s/it/search?q=%s" % (host, urllib.parse.quote(t))}
        url, d = pick(_entries(_encode(item)), e)
        if url:
            return url, d
    return None, None


def _auto_choose():
    """Se s4me mostra la lista 'Riproduci ...', sceglie la voce HD (altrimenti la prima 'Riproduci')."""
    if not xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        return
    try:
        n = int(xbmc.getInfoLabel("Container(3).NumItems") or 0)
    except Exception:
        return
    labels = [xbmc.getInfoLabel("Container(3).ListItemAbsolute(%d).Label" % i) for i in range(n)]
    play = [i for i, l in enumerate(labels) if l.lower().startswith("riproduci")]
    if not play:
        return  # e' un'altra finestra: la lasciamo all'utente
    hd = [i for i in play if "hd" in labels[i].lower() and "sd" not in labels[i].lower().replace("hd", "")]
    idx = (hd or play)[0]
    xbmc.executebuiltin("SetFocus(3,%d)" % idx)
    xbmc.sleep(250)
    xbmc.executebuiltin("Action(Select)")
    xbmc.sleep(800)


def _wait_playing(timeout=50):
    mon = xbmc.Monitor()
    player = xbmc.Player()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if player.isPlaying():
            return True
        _auto_choose()
        mon.waitForAbort(0.5)
    return False


def _choose_episode(url, status=None):
    if status:
        status("Carico gli episodi...")
    eps = _entries(url)
    eps = [(u, d) for u, d in eps if d.get("action") == "findvideos"]
    if not eps:
        return None

    def sn(d):
        return int(d.get("contentSeason") or d.get("season") or 0)

    def en(d):
        return int(d.get("contentEpisodeNumber") or d.get("episode") or 0)

    seasons = sorted({sn(d) for _, d in eps})
    s = seasons[0]
    if len(seasons) > 1:
        i = xbmcgui.Dialog().select("Stagione", ["Stagione %d" % x for x in seasons])
        if i < 0:
            return CANCEL
        s = seasons[i]
    lst = sorted([(en(d), u, d) for u, d in eps if sn(d) == s], key=lambda x: x[0])
    labels = []
    for n, u, d in lst:
        t = re.sub(r"\[/?[^\]]*\]", "", d.get("title", "")).strip()
        labels.append(t or "Episodio %d" % n)
    i = xbmcgui.Dialog().select("Stagione %d" % s, labels)
    if i < 0:
        return CANCEL
    return lst[i][1]


# ---------- API ----------
def watch(e, status=None):
    """Ritorna OK, NOTFOUND, NOSOURCE, FAIL o CANCEL. Da chiamare in un thread (blocca)."""
    if not available():
        return NOSOURCE
    url, d = search_channel(e, status)
    if not url:
        return NOTFOUND
    if d.get("action") == "findvideos":
        m = re.search(r"/watch/(\d+)", d.get("url") or "")
        if m and sc.movie_playable(int(m.group(1))) is False:
            return NOTFOUND  # titolo nel catalogo ma senza video disponibile
    if d.get("action") == "episodios":
        url = _choose_episode(url, status)
        if url == CANCEL:
            return CANCEL
        if not url:
            return NOTFOUND
    if status:
        status("Avvio la riproduzione...")
    xbmc.executebuiltin("RunPlugin(%s)" % url)
    return OK if _wait_playing() else FAIL
