"""Avvio automatico di Addò-flix all'avvio di Kodi (se attivato nelle impostazioni)."""
import os
import xbmc
import xbmcaddon

ID = "plugin.video.veloceflix"


def main():
    mon = xbmc.Monitor()
    addon = xbmcaddon.Addon(ID)
    if addon.getSetting("autostart") != "true":
        return
    # attende che Kodi abbia finito di avviarsi (schermata Home pronta) e che i popup iniziali siano chiusi
    waited = 0
    while not mon.abortRequested() and waited < 60:
        if xbmc.getCondVisibility("Window.IsActive(home)"):
            break
        mon.waitForAbort(1)
        waited += 1
    mon.waitForAbort(6)
    if mon.abortRequested() or xbmc.Player().isPlaying():
        return
    xbmc.executebuiltin("RunScript(%s)" % os.path.join(addon.getAddonInfo("path"), "launcher.py"))


main()
