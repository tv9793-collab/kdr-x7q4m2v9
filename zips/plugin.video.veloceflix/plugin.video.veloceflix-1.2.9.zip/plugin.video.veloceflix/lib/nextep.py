"""Episodio successivo in stile Netflix: popup in basso a destra a fine puntata, con conto alla rovescia,
'Annulla' e 'Guarda ora'. Dopo alcuni episodi di fila senza toccare niente chiede se stai ancora guardando.
Tutto regolabile dalle impostazioni (categoria Serie TV)."""
import time

import xbmc
import xbmcaddon
import xbmcgui

import progress

GO, AUTO, CANCEL, STOPPED = "go", "auto", "cancel", "stopped"
CLOSE = (getattr(xbmcgui, "ACTION_NAV_BACK", 92), getattr(xbmcgui, "ACTION_PREVIOUS_MENU", 10))
BTN_NOW, BTN_CANCEL = 40, 41
STILL_AFTER = 3          # episodi partiti da soli di fila prima di chiedere "Stai ancora guardando?"
_chain = {"n": 0}


def enabled():
    return progress.setting("autoplay_next", "true") == "true"


def _int(name, default):
    try:
        return int(progress.setting(name, str(default)))
    except ValueError:
        return default


def trigger_secs():
    """Quanti secondi prima della fine compare il popup (titoli di coda)."""
    return _int("next_at", 60)


def countdown_secs():
    return _int("next_countdown", 15)


def find_next(eps, ep):
    """eps = [[s, n, url, titolo]] ordinati. Ritorna l'episodio dopo 'ep' (anche nella stagione dopo) o None."""
    cur = (ep.get("s"), ep.get("e"))
    keys = [(x[0], x[1]) for x in eps]
    if cur not in keys:
        return None
    i = keys.index(cur)
    if i + 1 >= len(eps):
        return None
    x = eps[i + 1]
    return {"s": x[0], "e": x[1], "url": x[2], "title": x[3]}


class Popup(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        super().__init__(*a)
        self.info = k["info"]
        self.result = None

    def onInit(self):
        for k, v in self.info.items():
            self.setProperty(k, v)
        self.setFocusId(BTN_NOW)

    def onClick(self, cid):
        if cid in (BTN_NOW, BTN_CANCEL):
            self.result = GO if cid == BTN_NOW else CANCEL
            self.close()

    def onAction(self, action):
        if action.getId() in CLOSE:
            self.result = CANCEL
            self.close()


def ask(nxt, player, playing, mon, thumb=""):
    """Mostra il popup mentre l'episodio finisce. Ritorna GO (premuto), AUTO (conto finito o puntata
    finita), CANCEL (annullato o 'basta per ora') oppure STOPPED (video fermato / cambiato)."""
    still = progress.setting("still_watching", "true") == "true" and _chain["n"] >= STILL_AFTER
    secs = countdown_secs()
    label = "S%s E%s  ·  %s" % (nxt["s"], nxt["e"], nxt["title"])
    info = {"NextTitle": label, "Thumb": thumb or "",
            "Head": "Stai ancora guardando?" if still else "Prossimo episodio",
            "NowLabel": "Continua" if still else "Guarda ora",
            "CancelLabel": "Basta per ora" if still else "Annulla",
            "Ask": "1" if still else "", "Countdown": "" if still else "Inizia tra %d s" % secs}
    path = xbmcaddon.Addon(progress.ID).getAddonInfo("path")
    w = Popup("VeloceFlixNext.xml", path, "default", "1080i", info=info)
    w.show()
    end = time.time() + secs
    res = None
    try:
        while res is None and not mon.abortRequested():
            if w.result is not None:
                res = w.result
                break
            try:
                alive = player.isPlaying() and player.getPlayingFile() == playing
            except Exception:
                alive = False
            if not alive:
                # finita da sola: si va avanti (se non serve la conferma); fermata dall'utente: stop
                res = STOPPED if player.user_stop else (CANCEL if still else AUTO)
                break
            if not still:
                left = end - time.time()
                if left <= 0:
                    res = AUTO
                    break
                w.setProperty("Countdown", "Inizia tra %d s" % max(1, int(left + 0.99)))
            mon.waitForAbort(0.25)
    finally:
        try:
            w.close()
        except Exception:
            pass
        del w
    if res == AUTO:
        _chain["n"] += 1
    elif res == GO:
        _chain["n"] = 0      # l'utente c'e': si ricomincia a contare
    elif res == CANCEL:
        _chain["n"] = 0
    xbmc.log("[veloceflix] prossimo episodio: %s" % res, xbmc.LOGINFO)
    return res
