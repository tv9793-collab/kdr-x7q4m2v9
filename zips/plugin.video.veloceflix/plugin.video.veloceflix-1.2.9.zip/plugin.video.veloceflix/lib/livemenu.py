"""Parte Live della home: righe dei canali, tessere di gestione e menu del canale."""
import json
import time

import xbmc
import xbmcaddon
import xbmcgui

import live
import progress

T = "Addò-flix Live"

HELP = """[B]Come aggiungere i canali[/B]

[B]1. Lista online (comoda dal telefono)[/B]
Scrivi la lista in un file di testo pubblicato su internet (per esempio un file nel tuo repository GitHub, o un servizio di note che dia un link "raw"). Poi: Gestisci canali > Lista online, e incolla l'indirizzo. Addò-flix la rilegge da sola ogni 6 ore (o subito con "Aggiorna canali").

[B]2. File sul dispositivo[/B]
Copia il file (per esempio canali.txt o canali.m3u) nella memoria del box o su una chiavetta USB, poi: Gestisci canali > Importa canali > Da file.

[B]3. A mano[/B]
Gestisci canali > Aggiungi canale: nome, link e gruppo.

[B]Formato del file[/B]
Una riga per link, con il nome del canale, il segno = e il link. Le righe tra parentesi quadre sono i gruppi (diventano le righe della home):

[COLOR FFF5A524][Notizie][/COLOR]
[COLOR FFF5A524]Nome canale = https://esempio.it/live/index.m3u8[/COLOR]
[COLOR FFF5A524]Nome canale = https://altro.esempio.it/live.m3u8[/COLOR]

Lo stesso nome su più righe = link alternativi dello stesso canale: Addò-flix li prova tutti e parte dal più veloce; se uno cade passa da solo al successivo.
Va bene anche una lista M3U (#EXTINF con group-title e tvg-logo).
Servono link diretti al video (.m3u8, .mpd, .ts...), non pagine web.

[B]Durante l'uso[/B]
OK su un canale: parte subito.
Tieni premuto OK (o il tasto menu / clic destro): scegli il link, aggiungi o togli link, rinomina, cambia gruppo o logo, elimina."""


def _initials(name):
    w = [x for x in name.replace("-", " ").split() if x]
    return "".join(x[0] for x in w[:3]).upper() if len(w) > 1 else name[:4].upper()


def entry(c, light=None):
    n = len(c["links"])
    if light is None:
        light = progress.setting("light_images", "false") == "true"
    # Immagini leggere: niente loghi da scaricare (con liste lunghe pesano sul box), solo le iniziali
    logo = "" if light else c["logo"]
    return {"type": "live", "id": c["key"], "key": c["key"], "title": c["name"], "poster": logo,
            "backdrop": "", "year": "", "vote": "", "label2": "%d link" % n if n > 1 else "1 link",
            "initials": _initials(c["name"]), "group": c["group"] or live.DEFAULT_GROUP,
            "plot": "OK per guardare: %s\nTieni premuto OK (o tasto menu) per gestire il canale." % (
                "provo i %d link e parto dal più veloce." % n if n > 1 else "parte subito.")}


ACTIONS = [
    ("add", "Aggiungi canale", "i_plus.png", "Nome, link e gruppo, con la tastiera."),
    ("import", "Importa canali", "i_search.png", "Da un file sul dispositivo (anche chiavetta USB) o da un indirizzo web."),
    ("url", "Lista online", "i_gear.png", "Una lista sul web che modifichi dal telefono: Addò-flix la rilegge da sola."),
    ("sync", "Aggiorna canali", "i_refresh.png", "Rilegge subito la lista online."),
    ("help", "Come si fa", "i_check.png", "Formato del file e come aggiungere i canali che vuoi."),
]


def action_entries():
    return [{"type": "action", "id": a, "key": a, "title": t, "poster": icon, "backdrop": "", "year": "",
             "vote": "", "label2": "", "initials": "", "plot": d} for a, t, icon, d in ACTIONS]


def rows():
    light = progress.setting("light_images", "false") == "true"
    out = [(g, [entry(c, light) for c in chs]) for g, chs in live.groups()]
    acts = ("Gestisci canali", action_entries())
    return out + [acts] if out else [acts]


def hero(e):
    """(titolo, meta, trama) per il riquadro in alto."""
    if e["type"] == "action":
        return e["title"], "Gestisci canali", e["plot"]
    meta = "[COLOR FFE5484D]●[/COLOR] Live   ·   %s   ·   %s" % (e["group"], e["label2"])
    return e["title"], meta, e["plot"]


def search(text):
    t = live.norm(text)
    light = progress.setting("light_images", "false") == "true"
    return [entry(c, light) for c in live.channels() if t and t in live.norm(c["name"])]


# ------------------------------------------------------------------ azioni
def _input(head, default=""):
    r = xbmcgui.Dialog().input(head, default, type=xbmcgui.INPUT_ALPHANUM)
    return r.strip() if r else ""


def _pick_group(current=""):
    gs = [g for g, _ in live.groups()]
    opts = gs + ["Nuovo gruppo..."]
    i = xbmcgui.Dialog().select("Gruppo", opts, preselect=gs.index(current) if current in gs else 0)
    if i < 0:
        return None
    if i == len(gs):
        return _input("Nome del nuovo gruppo") or None
    return gs[i]


def do_action(a):
    """Tessere di 'Gestisci canali'. Ritorna True se i canali sono cambiati."""
    d = xbmcgui.Dialog()
    if a == "add":
        name = _input("Nome del canale")
        if not name:
            return False
        url = _input("Link del video (.m3u8, .mpd, .ts...)", "https://")
        if not url or url == "https://":
            return False
        g = _pick_group() if live.groups() else (_input("Gruppo (facoltativo)") or "")
        if g is None:
            g = ""
        if not live.add_channel(name, url, g):
            d.ok(T, "Il link deve iniziare con http:// o https:// ed essere un link diretto al video.")
            return False
        d.notification(T, "Aggiunto: %s" % name, xbmcgui.NOTIFICATION_INFO, 2500)
        return True
    if a == "import":
        i = d.select("Importa canali", ["Da file (memoria del dispositivo o USB)", "Da indirizzo web"])
        try:
            if i == 0:
                fn = d.browse(1, "Scegli il file dei canali", "files", ".txt|.m3u|.m3u8")
                if not fn:
                    return False
                import xbmcvfs
                f = xbmcvfs.File(fn)
                try:
                    text = f.read()
                finally:
                    f.close()
            elif i == 1:
                url = _input("Indirizzo della lista", "https://")
                if not url or url == "https://":
                    return False
                text = live._download(url)
            else:
                return False
        except Exception as ex:
            xbmc.log("[veloceflix] import canali: %r" % (ex,), xbmc.LOGINFO)
            d.ok(T, "Non riesco a leggere la lista.")
            return False
        n = live.import_text(text)
        d.ok(T, "Aggiunti %d link." % n if n else "Nessun canale trovato. Controlla il formato (vedi \"Come si fa\").")
        return n > 0
    if a == "url":
        cur = progress.setting("live_url", "")
        url = d.input("Indirizzo della lista online (vuoto = nessuna)", cur or "https://", type=xbmcgui.INPUT_ALPHANUM)
        if url is None or url == cur:
            return False
        url = "" if url.strip() in ("", "https://") else url.strip()
        xbmcaddon.Addon(progress.ID).setSetting("live_url", url)
        return _sync_report(url)
    if a == "sync":
        if not progress.setting("live_url", ""):
            d.ok(T, "Nessuna lista online impostata: usa \"Lista online\".")
            return False
        return _sync_report(progress.setting("live_url", ""))
    if a == "help":
        d.textviewer(T, HELP)
    return False


def _sync_report(url):
    if not url:
        return True
    n = live.sync(force=True)
    d = xbmcgui.Dialog()
    if n < 0:
        d.ok(T, "Non riesco a scaricare la lista. Controlla l'indirizzo e la rete.")
        return False
    d.notification(T, "Lista aggiornata: %d link" % n, xbmcgui.NOTIFICATION_INFO, 3000)
    return True


def _link_label(u, i):
    s = progress._read(live._STATS).get(u, {})
    host = u.split("|", 1)[0].split("/")[2] if "://" in u else u
    if s.get("ok", 0) >= s.get("fail", 0) and s.get("ok"):
        st = "ok %s" % time.strftime("%d/%m %H:%M", time.localtime(s["ok"]))
    elif s.get("fail"):
        st = "non andava %s" % time.strftime("%d/%m %H:%M", time.localtime(s["fail"]))
    else:
        st = "mai provato"
    return "Link %d  -  %s  (%s)" % (i + 1, host, st)


def channel_menu(e):
    """Menu del canale. Ritorna ('play', link o None), ('changed', None) oppure (None, None)."""
    c = live.get(e["key"])
    if not c:
        return None, None
    d = xbmcgui.Dialog()
    opts = ["Guarda (link più veloce)", "Scegli il link", "Aggiungi un link", "Togli un link",
            "Rinomina", "Cambia gruppo", "Cambia logo", "Elimina canale"]
    i = d.select(c["name"], opts)
    if i == 0:
        return "play", None
    if i == 1:
        j = d.select("Scegli il link", [_link_label(u, k) for k, u in enumerate(c["links"])])
        return ("play", c["links"][j]) if j >= 0 else (None, None)
    if i == 2:
        url = _input("Nuovo link per %s" % c["name"], "https://")
        if url and url != "https://":
            if live.add_link(c["key"], url):
                return "changed", None
            d.ok(T, "Il link deve iniziare con http:// o https://.")
    elif i == 3:
        j = d.select("Togli un link", [_link_label(u, k) for k, u in enumerate(c["links"])])
        if j >= 0 and d.yesno(T, "Tolgo il link %d di %s?" % (j + 1, c["name"])):
            live.remove_link(c["key"], c["links"][j])
            return "changed", None
    elif i == 4:
        n = _input("Nuovo nome", c["name"])
        if n and n != c["name"]:
            live.update(c["key"], name=n)
            return "changed", None
    elif i == 5:
        g = _pick_group(c["group"])
        if g is not None:
            live.update(c["key"], group=g)
            return "changed", None
    elif i == 6:
        lg = _input("Indirizzo dell'immagine del logo (vuoto = nessuno)", c["logo"] or "https://")
        live.update(c["key"], logo="" if lg in ("", "https://") else lg)
        return "changed", None
    elif i == 7:
        if d.yesno(T, "Elimino %s e tutti i suoi link?" % c["name"]):
            live.delete(c["key"])
            return "changed", None
    return None, None


def dump(e):
    return json.dumps(e)
