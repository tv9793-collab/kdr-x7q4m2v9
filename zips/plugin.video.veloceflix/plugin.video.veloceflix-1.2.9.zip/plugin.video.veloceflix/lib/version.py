"""Versione installata e confronto con l'ultima pubblicata, mostrati nelle impostazioni.

L'indirizzo del repository non e' scritto qui: si legge dall'addon repository installato in Kodi
(lo stesso da cui arrivano gli aggiornamenti automatici). Senza rete o senza repository si mostra
solo la versione installata.
"""
import os
import re
import urllib.request

import xbmc
import xbmcaddon
import xbmcvfs

ID = "plugin.video.veloceflix"
REPO = "repository.addoflix"
SETTING = "version_info"


def _tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4]) or (0,)


def _repo_index():
    path = os.path.join(xbmcvfs.translatePath("special://home/addons"), REPO, "addon.xml")
    with open(path, "r", encoding="utf-8") as f:
        m = re.search(r"<info[^>]*>\s*([^<\s]+)\s*</info>", f.read())
    return m.group(1) if m else None


def latest(timeout=8):
    """Ultima versione pubblicata (stringa) oppure None se non si riesce a saperlo."""
    url = _repo_index()
    if not url:
        return None
    req = urllib.request.Request(url, headers={"User-Agent": "Addoflix", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        xml = r.read().decode("utf-8", "replace")
    m = re.search(r'<addon[^>]*\bid="%s"[^>]*>' % re.escape(ID), xml)
    if not m:
        return None
    v = re.search(r'\bversion="([^"]+)"', m.group(0))
    return v.group(1) if v else None


def describe(installed, last):
    if not last:
        return "%s (controllo aggiornamenti non riuscito)" % installed
    if _tuple(last) > _tuple(installed):
        return "%s - disponibile la %s (Kodi la installa da solo)" % (installed, last)
    return "%s - ultima versione" % installed


def refresh(timeout=8):
    """Aggiorna la voce "Versione" nelle impostazioni. Ritorna il testo scritto."""
    addon = xbmcaddon.Addon(ID)
    installed = addon.getAddonInfo("version")
    try:
        last = latest(timeout)
    except Exception as ex:
        xbmc.log("[veloceflix] controllo versione: %r" % (ex,), xbmc.LOGINFO)
        last = None
    text = describe(installed, last)
    if addon.getSetting(SETTING) != text:
        addon.setSetting(SETTING, text)
    return text
