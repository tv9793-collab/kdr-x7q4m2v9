"""Ripresa della visione e ottimizzazioni per connessioni lente.

- progress.json: punto di visione per titolo (per le serie: ultimo episodio). Si salva ogni pochi
  secondi con scrittura atomica (file temporaneo + os.replace), quindi sopravvive a crash di Kodi,
  blocchi del box e mancanza di corrente: al massimo si perdono gli ultimi secondi.
- links.json: collegamenti di Stream for Me gia' trovati (film ed episodi), per ripartire senza
  rifare la ricerca sul sito: avvio molto piu' rapido, soprattutto su linee lente.
- qualita' massima di inputstream.adaptive limitata solo durante la visione con Addò-flix e poi
  ripristinata (un backup su disco la ripristina anche dopo un crash).
"""
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

ID = "plugin.video.veloceflix"
ISA = "inputstream.adaptive"
_ADDON = xbmcaddon.Addon(ID)
_PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_PROGRESS = os.path.join(_PROFILE, "progress.json")
_LINKS = os.path.join(_PROFILE, "links.json")
_ISA_BACKUP = os.path.join(_PROFILE, "isa_backup.json")
_HISTORY = os.path.join(_PROFILE, "history.json")

MIN_RESUME = 60          # sotto il minuto si riparte dall'inizio
DONE_RATIO = 0.93        # oltre il 93% (o negli ultimi minuti) il titolo e' visto
DONE_TAIL = 150
KEEP = 30                # titoli ricordati in "Continua a guardare"
LINK_TTL = 7 * 86400     # collegamento di un film/episodio
LIST_TTL = 86400         # elenco episodi di una serie

_lock = threading.RLock()
_mem = {}


def setting(name, default=""):
    try:
        v = xbmcaddon.Addon(ID).getSetting(name)
    except Exception:
        v = ""
    return v if v != "" else default


# ------------------------------------------------------------ file sicuri
def _read(fn):
    with _lock:
        if fn in _mem:
            return _mem[fn]
        try:
            with open(fn, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            d = {}
        _mem[fn] = d
        return d


def _write(fn, d):
    """Scrittura atomica: un crash a meta' scrittura lascia intatto il file precedente."""
    with _lock:
        _mem[fn] = d
        try:
            os.makedirs(_PROFILE, exist_ok=True)
            tmp = fn + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, fn)
        except Exception as ex:
            xbmc.log("[veloceflix] salvataggio %s: %r" % (os.path.basename(fn), ex), xbmc.LOGWARNING)


def key(e):
    return "%s:%s" % (e["type"], e["id"])


def fmt(sec):
    sec = int(sec or 0)
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


# ------------------------------------------------------- punto di visione
def get(e):
    """Punto salvato per il titolo (per le serie: ultimo episodio), o None."""
    v = _read(_PROGRESS).get(key(e))
    if v and v.get("pos", 0) >= MIN_RESUME:
        return v
    return None


def put(e, pos, total, url=None, ep=None):
    with _lock:
        d = dict(_read(_PROGRESS))
        d[key(e)] = {"pos": int(pos), "total": int(total or 0), "t": time.time(), "entry": e, "url": url, "ep": ep}
        if len(d) > KEEP:  # tiene solo i piu' recenti
            for k in sorted(d, key=lambda k: d[k].get("t", 0))[:len(d) - KEEP]:
                d.pop(k, None)
        _write(_PROGRESS, d)
    record(e, pos, total, ep)


# ------------------------------------------------------- cronologia (visti e barre rosse)
# history.json: per ogni titolo l'avanzamento (film) o quello di ogni episodio (serie).
# Si tengono al massimo N titoli (impostazione "Titoli ricordati"), i meno recenti si dimenticano:
# il file resta piccolo (circa 1 kB per serie) e la home non rallenta.
HIST_EVERY = 60          # durante la visione si salva al massimo ogni minuto (meno scritture sul box)
_hist_last = {}


def hist_max():
    try:
        return max(50, int(setting("history_max", "300")))
    except ValueError:
        return 300


def ep_key(ep):
    return "%sx%s" % (ep.get("s"), ep.get("e"))


def record(e, pos, total, ep=None, force=False):
    """Aggiorna la cronologia. 'done' quando il titolo/episodio e' finito."""
    k = key(e)
    done = is_done(pos, total)
    now = time.time()
    if not force and not done and now - _hist_last.get(k, 0) < HIST_EVERY:
        return
    _hist_last[k] = now
    with _lock:
        d = dict(_read(_HISTORY))
        h = dict(d.get(k) or {})
        h["entry"] = {x: e.get(x) for x in ("id", "type", "title", "orig", "year", "plot", "poster", "backdrop", "vote")}
        h["t"] = now
        st = [int(pos), int(total or 0), 1 if done else 0, int(now)]
        if ep and ep.get("s") is not None:
            eps = dict(h.get("eps") or {})
            old = eps.get(ep_key(ep))
            if old and old[2] and not done:
                st[2] = 1          # un episodio gia' visto resta visto anche se lo si riguarda
            eps[ep_key(ep)] = st
            h["eps"] = eps
            h["last"] = {"s": ep.get("s"), "e": ep.get("e")}
        else:
            if h.get("st") and h["st"][2] and not done:
                st[2] = 1
            h["st"] = st
        d[k] = h
        n = hist_max()
        if len(d) > n:
            for kk in sorted(d, key=lambda x: d[x].get("t", 0))[:len(d) - n]:
                d.pop(kk, None)
        _write(_HISTORY, d)


def set_watched(e, eps, watched):
    """Segna a mano episodi [(s, n)] come visti o da vedere (menu dell'episodio nella scheda)."""
    k = key(e)
    now = time.time()
    with _lock:
        d = dict(_read(_HISTORY))
        h = dict(d.get(k) or {})
        h["entry"] = {x: e.get(x) for x in ("id", "type", "title", "orig", "year", "plot", "poster", "backdrop", "vote")}
        h["t"] = now
        st = dict(h.get("eps") or {})
        for s, n in eps:
            kk = ep_key({"s": s, "e": n})
            if watched:
                old = st.get(kk)
                tot = old[1] if old and old[1] else 1
                st[kk] = [tot, tot, 1, int(now)]
            else:
                st.pop(kk, None)
        h["eps"] = st
        # 'ultimo episodio' = il piu' avanti tra quelli rimasti: da li' riparte "Riprendi/Guarda"
        def num(x):
            a, _, b = x.partition("x")
            return (int(a), int(b)) if a.isdigit() and b.isdigit() else (0, 0)
        if st:
            s, n = max((num(x) for x in st), default=(0, 0))
            h["last"] = {"s": s, "e": n}
        else:
            h.pop("last", None)
        d[k] = h
        _write(_HISTORY, d)


def _migrate():
    """Prima volta con la cronologia: si parte dai titoli di 'Continua a guardare'."""
    if os.path.exists(_HISTORY) or _HISTORY in _mem:
        return
    with _lock:
        for v in sorted(_read(_PROGRESS).values(), key=lambda x: x.get("t", 0)):
            if v.get("entry") and v.get("total"):
                _hist_last.pop(key(v["entry"]), None)
                record(v["entry"], v.get("pos", 0), v["total"], v.get("ep"), force=True)
        if _HISTORY not in _mem:
            _write(_HISTORY, {})


def history(e):
    _migrate()
    return _read(_HISTORY).get(key(e)) or {}


def episode_state(e, ep):
    """(posizione, durata, visto) di un episodio, oppure None."""
    st = (history(e).get("eps") or {}).get(ep_key(ep))
    return (st[0], st[1], bool(st[2])) if st else None


def percent(e):
    """Barra rossa sotto la locandina: avanzamento del film o dell'ultimo episodio (0 = nessuna)."""
    h = history(e)
    if not h:
        return 0
    st = h.get("st")
    if h.get("last"):
        st = (h.get("eps") or {}).get(ep_key(h["last"]))
    if not st or not st[1]:
        return 0
    if st[2]:
        return 100
    return max(3, min(99, int(st[0] * 100 / st[1]))) if st[0] >= MIN_RESUME else 0


def next_episode(e, eps):
    """Episodio da proporre su 'Riprendi'/'Guarda' di una serie. eps = [(s, n)] in ordine.
    Ritorna (s, n, posizione di partenza)."""
    h = history(e)
    if not eps:
        return None
    last = h.get("last")
    if not last:
        return eps[0][0], eps[0][1], 0
    st = (h.get("eps") or {}).get(ep_key(last))
    cur = (last.get("s"), last.get("e"))
    if st and not st[2] and st[0] >= MIN_RESUME:
        return cur[0], cur[1], st[0]            # a meta': si riprende da li'
    if st and st[2] and cur in eps:
        i = eps.index(cur)
        if i + 1 < len(eps):
            return eps[i + 1][0], eps[i + 1][1], 0   # finito: il successivo
    if cur in eps:
        return cur[0], cur[1], 0
    return eps[0][0], eps[0][1], 0


def clear(e):
    with _lock:
        d = dict(_read(_PROGRESS))
        if d.pop(key(e), None) is not None:
            _write(_PROGRESS, d)


def is_done(pos, total):
    return bool(total) and (pos >= total * DONE_RATIO or total - pos <= DONE_TAIL)


def continue_watching():
    """Titoli da riprendere, dal piu' recente."""
    d = _read(_PROGRESS)
    items = sorted((v for v in d.values() if v.get("pos", 0) >= MIN_RESUME and v.get("entry")),
                   key=lambda v: v.get("t", 0), reverse=True)
    return [v["entry"] for v in items]


def label(v):
    """Es. 'S1 E3 da 12:40' oppure 'da 1:02:10'."""
    if not v:
        return ""
    ep = v.get("ep") or {}
    where = "S%s E%s " % (ep.get("s"), ep.get("e")) if ep.get("s") is not None else ""
    return "%sda %s" % (where, fmt(v.get("pos")))


# ------------------------------------------------- collegamenti gia' trovati
def link_get(k, ttl=LINK_TTL):
    v = _read(_LINKS).get(k)
    if v and time.time() - v.get("t", 0) < ttl:
        return v.get("v")
    return None


def link_put(k, value):
    with _lock:
        d = dict(_read(_LINKS))
        d[k] = {"t": time.time(), "v": value}
        now = time.time()
        d = {kk: vv for kk, vv in d.items() if now - vv.get("t", 0) < LINK_TTL}
        _write(_LINKS, d)


def link_drop(k):
    with _lock:
        d = dict(_read(_LINKS))
        if d.pop(k, None) is not None:
            _write(_LINKS, d)


# ------------------------------------- qualita' adattiva (inputstream.adaptive)
# inputstream.adaptive misura la banda e cambia qualita' al volo tra quelle offerte dallo stream.
# Durante la visione con Addò-flix lo forziamo in modalita' adattiva (non "risoluzione fissa" o
# "chiedi qualita'") e gli diamo un tetto massimo: quello scelto dall'utente oppure quello
# "imparato" dalla linea (dopo blocchi o cadute si scende di un gradino, con linea stabile si risale).
LEVELS = ["auto", "1080p", "720p", "480p"]   # dal piu' alto al piu' basso
_NET = os.path.join(_PROFILE, "net.json")
LEARN_TTL = 24 * 3600                          # il gradino imparato vale un giorno
_ISA_KEYS = ("adaptivestream.type", "adaptivestream.bandwidth.init.auto", "adaptivestream.res.max")


def _lvl(name):
    return LEVELS.index(name) if name in LEVELS else 0


def learned():
    v = _read(_NET)
    if v.get("cap") in LEVELS and time.time() - v.get("t", 0) < LEARN_TTL:
        return v["cap"]
    return "auto"


def effective_cap():
    """Il tetto piu' prudente tra quello scelto dall'utente e quello imparato dalla linea."""
    return LEVELS[max(_lvl(setting("max_res", "auto")), _lvl(learned()))]


def step_down():
    """Linea in difficolta': un gradino piu' in basso (fino a 480p). Ritorna il nuovo tetto."""
    new = LEVELS[min(len(LEVELS) - 1, _lvl(effective_cap()) + 1)]
    _write(_NET, {"cap": new, "t": time.time()})
    return new


def step_up():
    """Visione fluida: si risale di un gradino (fino a nessun limite)."""
    cur = _lvl(learned())
    if cur > 0:
        _write(_NET, {"cap": LEVELS[cur - 1], "t": time.time()})


def cap_quality():
    """Prepara inputstream.adaptive per la visione con Addò-flix (ripristinato a fine visione)."""
    want = {"adaptivestream.type": "default",               # adattiva, cambia qualita' al volo
            "adaptivestream.bandwidth.init.auto": "true",   # misura la banda reale all'avvio
            "adaptivestream.res.max": effective_cap()}
    try:
        isa = xbmcaddon.Addon(ISA)
        if not os.path.exists(_ISA_BACKUP):
            _write(_ISA_BACKUP, {k: isa.getSetting(k) for k in _ISA_KEYS})
        for k, v in want.items():
            if isa.getSetting(k) != v:
                isa.setSetting(k, v)
    except Exception as ex:
        xbmc.log("[veloceflix] qualita' adattiva non impostata: %r" % (ex,), xbmc.LOGINFO)


def restore_quality():
    """Rimette le impostazioni di inputstream.adaptive di prima (anche dopo un crash)."""
    if not os.path.exists(_ISA_BACKUP):
        return
    try:
        old = _read(_ISA_BACKUP)
        isa = xbmcaddon.Addon(ISA)
        for k in _ISA_KEYS:
            if old.get(k) is not None and isa.getSetting(k) != old[k]:
                isa.setSetting(k, old[k])
        with _lock:
            _mem.pop(_ISA_BACKUP, None)
            os.remove(_ISA_BACKUP)
    except Exception as ex:
        xbmc.log("[veloceflix] ripristino qualita': %r" % (ex,), xbmc.LOGINFO)


# ------------------------------------- volume uniforme (dialoghi piu' chiari)
# Kodi non ha un vero compressore audio comandabile, ma la sua "Amplificazione volume" (OSD audio)
# alza tutto di N dB e un limitatore interno tiene i picchi sotto il massimo: le parti basse
# (dialoghi) salgono, quelle forti (esplosioni, musica) quasi no. Si abbassa poi il volume della TV.
# L'amplificazione e' un'impostazione del singolo video, non di Kodi: a fine visione (o dopo un
# crash) non resta nulla da ripristinare, gli altri video e addon non ne risentono.
EVEN_DB = {"off": 0, "6": 6, "9": 9, "12": 12}
_AMP_RESET = 60   # passi da 1 dB verso il basso: azzera un valore rimasto salvato su questo video


def even_volume():
    """Da chiamare quando il video e' partito. Ritorna i dB applicati (0 = opzione spenta)."""
    db = EVEN_DB.get(setting("even_volume", "off"), 0)
    if not db:
        return 0
    try:
        for _ in range(_AMP_RESET):   # sotto 0 dB Kodi si ferma da solo
            xbmc.executebuiltin("Action(volampdown)")
        for _ in range(db):
            xbmc.executebuiltin("Action(volampup)")
    except Exception as ex:
        xbmc.log("[veloceflix] volume uniforme non applicato: %r" % (ex,), xbmc.LOGINFO)
        return 0
    return db
