"""Canali live scelti dall'utente: elenco, link alternativi, controllo dei link e visione ottimizzata.

Da dove arrivano i canali (si sommano, i canali con lo stesso nome uniscono i link):
- "I miei canali" aggiunti dall'addon (live_channels.json);
- una lista online in formato M3U o semplice (impostazione live_url), riletta ogni 6 ore;
- un file sul dispositivo nello stesso formato (impostazione live_file).

Formato semplice (facile da scrivere dal telefono):
    [Notizie]
    Nome canale = https://.../index.m3u8
    Nome canale = https://.../altro-link.m3u8        <- stesso nome: link alternativo
L'addon riproduce solo link diretti a flussi video (HLS, DASH, TS...), inseriti dall'utente.

Visione: si provano i link in parallelo e si parte dal migliore; qualita' adattiva con tetto
(lo stesso imparato per film e serie: la linea e' la stessa), ritardo dalla diretta piu' ampio per
le linee lente, cambio automatico di link se cade, volume uniforme se attivo.
"""
import os
import re
import threading
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcgui

import probe
import progress

_MANUAL = os.path.join(progress._PROFILE, "live_channels.json")
_LIST = os.path.join(progress._PROFILE, "live_list.json")
_STATS = os.path.join(progress._PROFILE, "live_stats.json")
LIST_TTL = 6 * 3600
DEFAULT_GROUP = "Canali"
OK, FAIL, CANCEL, EMPTY = "ok", "fail", "cancel", "empty"


def norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def clean_name(s):
    """'Rai 1 (720p) [Geo-blocked]' -> 'Rai 1': le versioni dello stesso canale diventano link alternativi."""
    s = re.sub(r"\s*\[[^\]]*\]", "", s or "")
    s = re.sub(r"\s*\((?:\d{3,4}p|sd|hd|fhd|uhd|4k|backup|alt\.?\s*\d*)\)", "", s, flags=re.I)
    return s.strip() or (s or "").strip()


# ------------------------------------------------------------------ lettura liste
def parse(text):
    """M3U (#EXTINF) oppure formato semplice 'Nome = link' con [Gruppo]. Ritorna [{name, group, logo, url}]."""
    out = []
    text = (text or "").lstrip("﻿")
    if "#EXTINF" in text:
        info, vlc = None, {}
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("#EXTINF"):
                attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
                name = line.rsplit(",", 1)[1].strip() if "," in line else ""
                info = {"name": clean_name(name or attrs.get("tvg-name", "")), "group": attrs.get("group-title", ""),
                        "logo": attrs.get("tvg-logo", "")}
                vlc = {}
            elif line.startswith("#EXTGRP:") and info is not None:
                info["group"] = info["group"] or line[8:].strip()
            elif line.startswith("#EXTVLCOPT:"):
                k, _, v = line[11:].partition("=")
                k = k.strip().lower()
                if k == "http-user-agent":
                    vlc["User-Agent"] = v.strip()
                elif k in ("http-referrer", "http-referer"):
                    vlc["Referer"] = v.strip()
            elif line and not line.startswith("#") and info is not None:
                url = line
                if vlc and "|" not in url:
                    url += "|" + "&".join("%s=%s" % (k, urllib.parse.quote(v)) for k, v in vlc.items())
                if info["name"] and _is_stream(url):
                    out.append(dict(info, url=url))
                info, vlc = None, {}
        return out
    group = ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        if line.startswith("[") and line.endswith("]"):
            group = line[1:-1].strip()
            continue
        m = re.match(r"^(.+?)\s*=\s*(\w+://\S+)$", line)
        if m and _is_stream(m.group(2)):
            out.append({"name": m.group(1).strip(), "group": group, "logo": "", "url": m.group(2)})
    return out


def _is_stream(url):
    return urllib.parse.urlparse(url.split("|", 1)[0]).scheme in ("http", "https", "rtmp", "rtsp", "rtp", "udp")


def _download(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": probe.UA, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(4 * 1024 * 1024).decode("utf-8", "replace")


def sync(force=False):
    """Rilegge la lista online (al massimo ogni 6 ore). Senza rete resta l'ultima copia."""
    url = progress.setting("live_url", "").strip()
    cache = progress._read(_LIST)
    if not url:
        return 0
    if not force and cache.get("src") == url and time.time() - cache.get("t", 0) < LIST_TTL:
        return len(cache.get("channels", []))
    try:
        items = parse(_download(url))
    except Exception as ex:
        xbmc.log("[veloceflix] lista live non scaricata: %r" % (ex,), xbmc.LOGINFO)
        return -1
    progress._write(_LIST, {"t": time.time(), "src": url, "channels": items})
    return len(items)


def _file_items():
    fn = progress.setting("live_file", "").strip()
    if not fn:
        return []
    try:
        import xbmcvfs
        f = xbmcvfs.File(fn)
        try:
            return parse(f.read())
        finally:
            f.close()
    except Exception as ex:
        xbmc.log("[veloceflix] file canali: %r" % (ex,), xbmc.LOGINFO)
        return []


# ------------------------------------------------------------------ elenco unito
def _manual():
    d = progress._read(_MANUAL)
    d.setdefault("channels", [])
    d.setdefault("hidden", [])
    d.setdefault("hidden_links", [])
    return d


def channels():
    """Tutti i canali: [{key, name, group, logo, links, mine}] nell'ordine delle liste."""
    m = _manual()
    hidden, hidden_links = set(m["hidden"]), set(m["hidden_links"])
    out, idx = [], {}

    def add(name, group, logo, links, mine):
        k = norm(name)
        if not k:
            return
        if k not in idx:
            if not mine and k in hidden:
                return
            idx[k] = len(out)
            out.append({"key": k, "name": name, "group": group or "", "logo": logo or "", "links": [], "mine": mine})
        c = out[idx[k]]
        c["group"] = c["group"] or group or ""
        c["logo"] = c["logo"] or logo or ""
        for u in links:
            if u and u not in c["links"] and (mine or u not in hidden_links):
                c["links"].append(u)

    for c in m["channels"]:
        add(c["name"], c.get("group"), c.get("logo"), c.get("links", []), True)
    for it in progress._read(_LIST).get("channels", []) + _file_items():
        add(it["name"], it.get("group"), it.get("logo"), [it["url"]], False)
    return [c for c in out if c["links"]]


def get(key):
    return next((c for c in channels() if c["key"] == key), None)


def groups():
    """[(gruppo, [canali])] nell'ordine in cui compaiono."""
    res, idx = [], {}
    for c in channels():
        g = c["group"] or DEFAULT_GROUP
        if g not in idx:
            idx[g] = len(res)
            res.append((g, []))
        res[idx[g]][1].append(c)
    return res


# ------------------------------------------------------------------ modifiche
def _own(m, key):
    """Il canale tra 'i miei' (se viene da una lista, se ne fa una copia modificabile)."""
    for c in m["channels"]:
        if norm(c["name"]) == key:
            return c
    src = get(key)
    if not src:
        return None
    c = {"name": src["name"], "group": src["group"], "logo": src["logo"], "links": list(src["links"])}
    m["channels"].append(c)
    if key not in m["hidden"]:
        m["hidden"].append(key)
    return c


def add_channel(name, url, group=""):
    name = (name or "").strip()
    if not name or not _is_stream(url or ""):
        return False
    m = _manual()
    c = next((x for x in m["channels"] if norm(x["name"]) == norm(name)), None)
    if c is None:
        m["channels"].append({"name": name, "group": group.strip(), "logo": "", "links": [url.strip()]})
    elif url.strip() not in c["links"]:
        c["links"].append(url.strip())
    progress._write(_MANUAL, m)
    return True


def add_link(key, url):
    if not _is_stream(url or ""):
        return False
    m = _manual()
    c = _own(m, key)
    if c is None:
        return False
    if url.strip() not in c["links"]:
        c["links"].append(url.strip())
    progress._write(_MANUAL, m)
    return True


def remove_link(key, url):
    m = _manual()
    c = _own(m, key)
    if c is None:
        return
    c["links"] = [u for u in c["links"] if u != url]
    if url not in m["hidden_links"]:
        m["hidden_links"].append(url)
    progress._write(_MANUAL, m)


def update(key, name=None, group=None, logo=None):
    m = _manual()
    c = _own(m, key)
    if c is None:
        return
    if name and name.strip():
        c["name"] = name.strip()
    if group is not None:
        c["group"] = group.strip()
    if logo is not None:
        c["logo"] = logo.strip()
    progress._write(_MANUAL, m)


def delete(key):
    m = _manual()
    m["channels"] = [c for c in m["channels"] if norm(c["name"]) != key]
    if key not in m["hidden"]:
        m["hidden"].append(key)
    progress._write(_MANUAL, m)


def import_text(text):
    """Aggiunge a 'i miei canali' tutti i canali di un testo/lista. Ritorna quanti link nuovi."""
    m = _manual()
    n = 0
    for it in parse(text):
        c = next((x for x in m["channels"] if norm(x["name"]) == norm(it["name"])), None)
        if c is None:
            c = {"name": it["name"], "group": it.get("group", ""), "logo": it.get("logo", ""), "links": []}
            m["channels"].append(c)
        if it["url"] not in c["links"]:
            c["links"].append(it["url"])
            n += 1
        k = norm(it["name"])
        if k in m["hidden"]:
            m["hidden"].remove(k)
    progress._write(_MANUAL, m)
    return n


# ------------------------------------------------------------------ statistiche dei link
def _stat(url, ok, kbps=0):
    s = dict(progress._read(_STATS))
    e = dict(s.get(url, {}))
    if ok:
        e["ok"] = time.time()
        if kbps:
            e["kbps"] = kbps
    else:
        e["fail"] = time.time()
    s[url] = e
    if len(s) > 400:  # si tengono i piu' recenti
        s = dict(sorted(s.items(), key=lambda x: max(x[1].get("ok", 0), x[1].get("fail", 0)))[-300:])
    progress._write(_STATS, s)


def remembered(links):
    """Ordine senza controllo: prima i link che hanno funzionato di recente; tra quelli caduti, prima
    chi almeno ogni tanto va; in fondo quelli che non sono mai partiti. Pari merito: ordine della lista."""
    s = progress._read(_STATS)

    def k(u):
        e = s.get(u, {})
        good = e.get("ok", 0) >= e.get("fail", 0)
        return (1 if good else 0, e.get("ok", 0))
    return sorted(links, key=k, reverse=True)


# ------------------------------------------------------------------ visione
def _item(ch, url, kind):
    base, hdrs = probe.split(url)
    li = xbmcgui.ListItem(ch["name"])
    if ch.get("logo"):
        li.setArt({"icon": ch["logo"], "thumb": ch["logo"]})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(ch["name"])
    except Exception:
        pass
    if kind in ("hls", "dash") and xbmc.getCondVisibility("System.HasAddon(%s)" % progress.ISA):
        li.setPath(base)
        li.setContentLookup(False)
        li.setMimeType("application/vnd.apple.mpegurl" if kind == "hls" else "application/dash+xml")
        li.setProperty("inputstream", progress.ISA)
        li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
        cap = progress.effective_cap()
        if cap != "auto":
            li.setProperty("inputstream.adaptive.chooser_resolution_max", cap)
        delay = progress.setting("live_delay", "auto")
        if delay.isdigit():
            li.setProperty("inputstream.adaptive.live_delay", delay)
        if hdrs:
            hs = urllib.parse.urlencode(hdrs)
            li.setProperty("inputstream.adaptive.manifest_headers", hs)
            li.setProperty("inputstream.adaptive.stream_headers", hs)
        return base, li
    li.setPath(url)
    return url, li


class _Watch(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.user_stop = self.ended = self.error = False

    def onPlayBackStopped(self):
        self.user_stop = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackError(self):
        self.error = True


# ------------------------------------------------------------------ memoria dei controlli
# I risultati dei controlli valgono qualche minuto: tornando su un canale (o cambiando link) si parte
# subito, senza riprovare tutto. I link guasti si ricontrollano prima di quelli buoni.
CHECK_TTL_OK, CHECK_TTL_BAD = 300, 90
BACKUP_FIRST, BACKUP_EVERY = 20, 300        # riserva: primo controllo dopo 20 s di visione, poi ogni 5 min
BACKUP_SAMPLE = 128 * 1024                  # durante la visione si scarica poco, per non rubare banda
STEP_UP_AFTER = 20 * 60                     # 20 minuti senza blocchi: la qualita' puo' risalire
_checks = {}
_checks_lock = threading.Lock()


def cached(url):
    """Risultato recente del controllo di un link, oppure None."""
    with _checks_lock:
        v = _checks.get(url)
    if not v:
        return None
    ttl = CHECK_TTL_OK if v[1].get("ok") else CHECK_TTL_BAD
    return v[1] if time.time() - v[0] < ttl else None


def check(urls, cap, sample=probe.SAMPLE_MAX, workers=4):
    """Classifica i link usando i risultati recenti e provando solo gli altri. [(url, risultato)]."""
    urls = list(dict.fromkeys(urls))
    results = {u: cached(u) for u in urls}
    todo = [u for u in urls if results[u] is None]
    if todo:
        for u, r in probe.rank(todo, cap, workers=workers, sample=sample):
            if r is not None:
                with _checks_lock:
                    _checks[u] = (time.time(), r)
                results[u] = r
    return probe.order_by_score(urls, results)


def _backup_check(urls, cap):
    try:
        check(urls, cap, sample=BACKUP_SAMPLE, workers=2)
    except Exception as ex:
        xbmc.log("[veloceflix] controllo riserva: %r" % (ex,), xbmc.LOGINFO)


def _best_next(rest):
    """Ordina i link rimasti con i controlli piu' recenti (i buoni prima), il resto com'era."""
    return [u for u, _ in probe.order_by_score(rest, {u: cached(u) for u in rest})]


def _play_one(ch, url, kind, mon, alive, on_start=None, backups=()):
    """Avvia un link e lo segue finche' va. Ritorna 'user' (stop/altro video), 'fail' (non parte),
    'drop' (caduto), 'slow' (troppi blocchi) oppure 'abort'.
    backups = link di riserva da ricontrollare in silenzio durante la visione."""
    path, li = _item(ch, url, kind)
    p = _Watch()
    progress.cap_quality()
    p.play(path, li)
    t0 = time.time()
    playing = None
    while time.time() - t0 < 25 and not mon.abortRequested() and alive():
        if p.error:
            return "fail"
        try:
            if p.isPlayingVideo() and p.getTime() > 0:
                playing = p.getPlayingFile()
                break
        except Exception:
            pass
        mon.waitForAbort(0.4)
    if playing is None:
        if not alive():
            return "user"
        try:
            p.stop()
        except Exception:
            pass
        return "abort" if mon.abortRequested() else "fail"
    if on_start:
        on_start()
    progress.even_volume()
    _stat(url, True)
    stalls, caching, t_start = [], False, time.time()
    any_stall, stepped = False, False
    next_backup = t_start + BACKUP_FIRST
    cap = progress.effective_cap()
    while not mon.abortRequested():
        try:
            if not p.isPlaying() or p.getPlayingFile() != playing:
                break
        except Exception:
            break
        now = xbmc.getCondVisibility("Player.Caching")
        if now and not caching and time.time() - t_start > 15:
            any_stall = True
            stalls = [t for t in stalls if time.time() - t < 300] + [time.time()]
            if len(stalls) >= 3:
                return "slow"
        caching = now
        if backups and time.time() >= next_backup and not now:
            # riserva pronta: se questo link cade si passa subito a quello che va meglio adesso
            threading.Thread(target=_backup_check, args=(list(backups), cap), daemon=True).start()
            next_backup = time.time() + BACKUP_EVERY
        if not stepped and not any_stall and time.time() - t_start >= STEP_UP_AFTER:
            progress.step_up()  # la linea regge: dalla prossima partenza un gradino piu' in alto
            stepped = True
        mon.waitForAbort(1)
    if mon.abortRequested():
        return "abort"
    mon.waitForAbort(1.5)  # lascia arrivare le notifiche del player
    if p.user_stop and not (p.error or p.ended):
        return "user"
    try:
        if p.isPlaying() and p.getPlayingFile() != playing:
            return "user"  # l'utente ha avviato altro
    except Exception:
        pass
    return "drop"


def watch(ch, status=None, alive=lambda: True, on_start=None, first=None):
    """Guarda un canale: controlla i link, parte dal migliore, cambia link se cade.
    first = link scelto a mano (si parte da quello, senza controllo). Da chiamare in un thread.
    Ritorna OK, FAIL, CANCEL o EMPTY."""
    links = list(ch.get("links") or [])
    if not links:
        return EMPTY
    progress.restore_quality()  # se un crash precedente l'avesse lasciata limitata
    mon = xbmc.Monitor()
    cap = progress.effective_cap()
    order = remembered(links)
    kinds = {u: probe.guess_kind(u) for u in links}
    if first in links:
        order = [first] + [u for u in order if u != first]
    elif len(links) > 1 and progress.setting("live_check", "true") == "true":
        if status:
            fresh = sum(1 for u in links if cached(u) is not None)
            status("Controllo %d link..." % (len(links) - fresh) if fresh < len(links) else "Avvio %s..." % ch["name"])
        ranked = check(order, cap)
        for u, r in ranked:
            if r is not None:
                kinds[u] = r["kind"] if r["ok"] else kinds[u]
                if not r["ok"]:
                    _stat(u, False)
        good = [u for u, r in ranked if r and r["ok"]]
        rest = [u for u, r in ranked if not (r and r["ok"])]
        order = good + rest
        if ranked and ranked[0][1] and ranked[0][1]["ok"]:
            xbmc.log("[veloceflix] live %s: link migliore %s kbps" % (ch["name"], ranked[0][1]["kbps"]), xbmc.LOGINFO)
    if not alive():
        return CANCEL
    auto = progress.setting("auto_retry", "true") == "true"
    tries = 0
    i = 0
    started = False
    retried = set()   # un link che andava e cade si riprova una volta prima di cambiarlo
    try:
        while i < len(order) and tries < len(order) * 2 and not mon.abortRequested():
            url = order[i]
            if status and not started:
                status("Avvio %s..." % ch["name"])
            backups = [u for u in order if u != url] if progress.setting("live_check", "true") == "true" else []
            res = _play_one(ch, url, kinds.get(url, "direct"), mon, alive, on_start, backups)
            tries += 1
            if res in ("user", "abort"):
                return OK if started or res == "user" else CANCEL
            if res == "fail":
                _stat(url, False)
                with _checks_lock:
                    _checks[url] = (time.time(), {"ok": False, "kind": kinds.get(url, "direct"), "kbps": 0, "need": 0})
            elif res in ("drop", "slow"):
                started = True
                if res == "slow":
                    old = progress.effective_cap()
                    new = progress.step_down()
                    if new != old:
                        _notify("Linea lenta: continuo a %s" % new)
                        continue  # stesso link, qualita' piu' bassa
                elif auto and url not in retried:
                    retried.add(url)
                    _notify("Diretta interrotta: mi ricollego")
                    mon.waitForAbort(2)
                    continue
                _stat(url, False)
            if not auto and started:
                return OK
            i += 1
            # i link rimasti nell'ordine dei controlli piu' recenti (anche quelli fatti durante la visione)
            order[i:] = _best_next(order[i:])
            if i < len(order):
                _notify("Link non disponibile: provo il %d di %d" % (i + 1, len(order)))
                mon.waitForAbort(1)
        return OK if started else FAIL
    finally:
        progress.restore_quality()


def _notify(msg, ms=3500):
    xbmcgui.Dialog().notification("Addò-flix Live", msg, xbmcgui.NOTIFICATION_INFO, ms)
