"""Controllo dei link live prima della visione: quali funzionano e quale va meglio sulla linea.

Per ogni link (in parallelo, con tempi massimi brevi):
- HLS (.m3u8): legge l'indice; se ci sono piu' qualita' sceglie quella entro il tetto, legge la
  sua lista e scarica un pezzo di video vicino alla diretta, misurando la velocita' reale;
- DASH (.mpd): controlla che l'indice risponda;
- flussi diretti (TS, MP4...): scarica i primi kB e misura la velocita'.
Si parte dal link che funziona ed e' piu' veloce rispetto a quello che serve per guardarlo.
Nessuna dipendenza da Kodi: si prova anche fuori da Kodi.
"""
import concurrent.futures as cf
import re
import time
import urllib.parse
import urllib.request

UA = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
MANIFEST_MAX = 256 * 1024
SAMPLE_MAX = 384 * 1024
HEIGHT = {"1080p": 1080, "720p": 720, "480p": 480}


def split(url):
    """'http://x/a.m3u8|User-Agent=..&Referer=..' -> ('http://x/a.m3u8', {'User-Agent': .., ...})."""
    base, _, hs = (url or "").strip().partition("|")
    hdrs = {}
    for part in hs.split("&"):
        k, _, v = part.partition("=")
        if k.strip():
            hdrs[urllib.parse.unquote(k.strip())] = urllib.parse.unquote(v.strip())
    return base, hdrs


def guess_kind(url):
    p = urllib.parse.urlparse(split(url)[0]).path.lower()
    if p.endswith(".m3u8") or p.endswith(".m3u"):
        return "hls"
    if p.endswith(".mpd"):
        return "dash"
    return "direct"


def _fetch(url, hdrs, limit, timeout):
    h = {"User-Agent": UA}
    h.update(hdrs)
    t0 = time.time()
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        first = time.time() - t0
        data = bytearray()
        while len(data) < limit:
            chunk = r.read(min(65536, limit - len(data)))
            if not chunk:
                break
            data += chunk
        return bytes(data), first, time.time() - t0, r.geturl()


def _variants(text, base):
    out, pending = [], None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXT-X-STREAM-INF"):
            bw = re.search(r"[^-]BANDWIDTH=(\d+)", line) or re.search(r"BANDWIDTH=(\d+)", line)
            res = re.search(r"RESOLUTION=\d+x(\d+)", line)
            pending = (int(bw.group(1)) if bw else 0, int(res.group(1)) if res else 0)
        elif line and not line.startswith("#") and pending:
            out.append({"bw": pending[0], "h": pending[1], "url": urllib.parse.urljoin(base, line)})
            pending = None
    return out


def pick_variant(variants, cap_h):
    """La qualita' piu' alta entro il tetto (o la piu' bassa se nessuna ci sta)."""
    if not variants:
        return None
    vs = sorted(variants, key=lambda v: (v["h"] or 0, v["bw"]))
    if cap_h:
        bw_max = {1080: 9000000, 720: 4500000, 480: 1800000}.get(cap_h, 0)
        ok = [v for v in vs if (v["h"] and v["h"] <= cap_h) or (not v["h"] and v["bw"] and v["bw"] <= bw_max)]
        if ok:
            return ok[-1]
        return min(vs, key=lambda v: v["bw"] or 0)   # nessuna entro il tetto: la piu' leggera
    return vs[-1]


def _segments(text, base):
    return [urllib.parse.urljoin(base, s.strip()) for s in text.splitlines()
            if s.strip() and not s.strip().startswith("#")]


def probe(url, cap="auto", timeout=4.0, sample=SAMPLE_MAX):
    """Ritorna {'ok', 'kind', 'ms', 'kbps', 'need', 'err'} (kbps = velocita' misurata).
    sample = quanti byte di video scaricare per misurare (meno durante la visione)."""
    res = {"ok": False, "kind": guess_kind(url), "ms": None, "kbps": 0, "need": 0, "err": ""}
    base, hdrs = split(url)
    try:
        body, first, total, final = _fetch(base, hdrs, MANIFEST_MAX, timeout)
        res["ms"] = int(first * 1000)
        head = body[:2048].lstrip(b"\xef\xbb\xbf \r\n\t")
        if head.startswith(b"#EXTM3U"):
            res["kind"] = "hls"
            text = body.decode("utf-8", "replace")
            if "#EXT-X-STREAM-INF" in text:
                v = pick_variant(_variants(text, final), HEIGHT.get(cap))
                if not v:
                    res["err"] = "nessuna qualita'"
                    return res
                res["need"] = v["bw"] // 1000
                body, _, _, final = _fetch(v["url"], hdrs, MANIFEST_MAX, timeout)
                text = body.decode("utf-8", "replace")
            segs = _segments(text, final)
            if not segs:
                res["err"] = "lista vuota"
                return res
            seg = segs[-3] if len(segs) >= 3 else segs[-1]   # vicino alla diretta, ma gia' pronto
            data, _, el, _ = _fetch(seg, hdrs, sample, timeout)
            if not data:
                res["err"] = "video vuoto"
                return res
            res["kbps"] = int(len(data) * 8 / max(el, 0.05) / 1000)
            res["ok"] = True
        elif b"<MPD" in body[:4096]:
            res["kind"] = "dash"
            res["ok"] = True
        elif head[:1] in (b"<", b"{"):          # pagina web o errore al posto del video
            res["err"] = "non e' un video"
        elif body:
            res["kind"] = "direct"
            if len(body) >= 32 * 1024 and total > 0.05:
                res["kbps"] = int(len(body) * 8 / total / 1000)
            res["ok"] = True
        else:
            res["err"] = "risposta vuota"
    except Exception as ex:
        res["err"] = type(ex).__name__
    return res


def score(r):
    """Ordine: funziona, poi regge la qualita' scelta (velocita' >= 1,3 x quella che serve), poi piu' veloce."""
    if r is None:                 # non ha risposto in tempo: forse va, prima di quelli guasti
        return (0, 1, 0)
    if not r.get("ok"):
        return (0, 0, 0)
    need = r.get("need") or 0
    fast_enough = 1 if (not need or r.get("kbps", 0) >= need * 1.3) else 0
    return (1, fast_enough, r.get("kbps", 0) or 0)


def rank(urls, cap="auto", timeout=4.0, deadline=10.0, workers=4, sample=SAMPLE_MAX):
    """Prova i link in parallelo. Ritorna [(url, risultato o None)], i migliori per primi.
    I link che non hanno risposto in tempo restano in fondo (None), nell'ordine ricevuto."""
    urls = list(dict.fromkeys(u for u in urls if u))
    if not urls:
        return []
    results = {}
    ex = cf.ThreadPoolExecutor(max_workers=max(1, min(workers, len(urls))))
    try:
        futs = {ex.submit(probe, u, cap, timeout, sample): u for u in urls}
        done, _ = cf.wait(futs, timeout=deadline)
        for f in done:
            try:
                results[futs[f]] = f.result()
            except Exception:
                results[futs[f]] = None
    finally:
        # i controlli ancora in corso finiscono da soli entro il loro timeout
        # (Kodi usa Python 3.8: niente shutdown(cancel_futures=...), si annullano a mano)
        for f in futs:
            f.cancel()
        ex.shutdown(wait=False)
    return order_by_score(urls, results)


def order_by_score(urls, results):
    """[(url, risultato)] dal migliore; a pari merito resta l'ordine ricevuto."""
    order = {u: i for i, u in enumerate(urls)}
    return sorted(((u, results.get(u)) for u in urls),
                  key=lambda x: (score(x[1]), -order[x[0]]), reverse=True)
