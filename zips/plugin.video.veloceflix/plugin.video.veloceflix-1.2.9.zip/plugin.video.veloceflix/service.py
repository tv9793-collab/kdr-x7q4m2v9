"""All'avvio di Kodi: ripristina la qualita' video se un crash l'ha lasciata limitata, poi
avvia Addò-flix in automatico (se attivato nelle impostazioni)."""
import os
import sys
import xbmc
import xbmcaddon

ID = "plugin.video.veloceflix"


def main():
    mon = xbmc.Monitor()
    addon = xbmcaddon.Addon(ID)
    try:
        sys.path.insert(0, os.path.join(addon.getAddonInfo("path"), "lib"))
        import progress
        progress.restore_quality()
    except Exception as ex:
        xbmc.log("[veloceflix] service: %r" % (ex,), xbmc.LOGWARNING)
    try:
        import version
        # niente thread (a fine servizio resterebbe appeso); al massimo pochi secondi,
        # mentre Kodi sta ancora caricando la Home
        version.refresh(timeout=5)
    except Exception as ex:
        xbmc.log("[veloceflix] service versione: %r" % (ex,), xbmc.LOGWARNING)
    if addon.getSetting("autostart") != "true":
        return
    # attende che Kodi abbia finito di avviarsi (schermata Home pronta) e che i popup iniziali siano chiusi
    waited = 0
    while not mon.abortRequested() and waited < 60:
        if xbmc.getCondVisibility("Window.IsActive(home)"):
            break
        mon.waitForAbort(1)
        waited += 1
    mon.waitForAbort(6)
    if mon.abortRequested() or xbmc.Player().isPlaying():
        return
    xbmc.executebuiltin("RunScript(%s)" % os.path.join(addon.getAddonInfo("path"), "launcher.py"))


main()
