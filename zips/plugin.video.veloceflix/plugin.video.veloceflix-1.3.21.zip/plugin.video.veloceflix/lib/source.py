"""Avvio diretto di un titolo tramite il canale StreamingCommunity (HD, ITA) di Stream for Me.

Flusso: cerca il titolo sul canale (via JSON-RPC verso plugin.video.s4me), sceglie il risultato
ITA con titolo/anno corrispondenti, poi lancia la riproduzione. Nessuna finestra di ricerca canali.
"""
import base64
import json
import re
import threading
import time
import unicodedata
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import progress
import nextep

S4ME = "plugin.video.s4me"
CHANNEL = "streamingcommunity"
BASE = "plugin://%s/?" % S4ME

OK, NOTFOUND, NOSOURCE, FAIL, CANCEL = "ok", "notfound", "nosource", "fail", "cancel"
DOWN = "down"      # il sito non risponde (es. bloccato): non si sa se il titolo c'e'
CB01 = "cb01"      # fonte da usare subito (scelta dall'utente nella ricerca)


def available():
    return xbmc.getCondVisibility("System.HasAddon(%s)" % S4ME)


# ---------- utilita ----------
import sc  # noqa: E402
import cb  # noqa: E402
from sc import host as _host, norm as _norm  # noqa: E402


def _encode(d):
    return BASE + urllib.parse.quote(base64.b64encode(json.dumps(d).encode("utf8")).decode())


def _decode(url):
    try:
        q = url.split("?", 1)[1]
        return json.loads(base64.b64decode(urllib.parse.unquote(q)).decode("utf8"))
    except Exception:
        return {}


def _listdir(url):
    """Elenco file di una cartella plugin (blocca finche' s4me ha finito)."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": url, "media": "files", "properties": ["title"]}}
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return []
    return (r.get("result") or {}).get("files") or []


def _entries(url):
    out = []
    for f in _listdir(url):
        d = _decode(f.get("file", ""))
        if d:
            out.append((f.get("file"), d))
    return out


def _title_ok(cand, e):
    c = _norm(cand)
    return bool(c) and c in (_norm(e.get("title")), _norm(e.get("orig")))


def _year_ok(d, e):
    try:
        y1, y2 = int(d.get("year") or (d.get("infoLabels") or {}).get("year") or 0), int(e.get("year") or 0)
    except Exception:
        return True
    return not y1 or not y2 or abs(y1 - y2) <= 1


def pick(entries, e):
    """Sceglie tra i risultati del canale: stesso tipo, ITA (non Sub-ITA), stesso titolo, anno compatibile."""
    want = "tvshow" if e["type"] == "tv" else "movie"
    best = None
    for url, d in entries:
        if d.get("contentType") != want:
            continue
        if (d.get("language") or "").strip().upper() != "ITA":
            continue
        if d.get("action") not in ("findvideos", "episodios"):
            continue
        name = d.get("fulltitle") or d.get("contentTitle") or d.get("contentSerieName") or ""
        if not (_title_ok(name, e) and _year_ok(d, e)):
            continue
        exact = _norm(name) == _norm(e.get("title"))
        score = 2 if exact else 1
        if best is None or score > best[0]:
            best = (score, url, d)
    return (best[1], best[2]) if best else (None, None)


def _close_errors(stop):
    """Durante una ricerca: se il canale di s4me va in errore mostra una finestra (Si'/No o OK)
    che bloccherebbe tutto finche' qualcuno non la chiude. La si chiude da soli."""
    mon = xbmc.Monitor()
    while not stop.is_set() and not mon.abortRequested():
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog) | Window.IsActive(okdialog)"):
            xbmc.executebuiltin("Action(Back)")
        stop.wait(0.5)


def search_channel(e, status=None):
    host = _host()
    if not host:
        return None, None
    terms = [e["title"]]
    if e.get("orig") and _norm(e["orig"]) != _norm(e["title"]):
        terms.append(e["orig"])
    stop = threading.Event()
    threading.Thread(target=_close_errors, args=(stop,), daemon=True).start()
    try:
        for t in terms:
            if status:
                status('Cerco "%s"...' % t)
            item = {"channel": CHANNEL, "action": "peliculas", "search": True, "folder": True,
                    "contentType": "tvshow" if e["type"] == "tv" else "movie",
                    "url": "%s/it/search?q=%s" % (host, urllib.parse.quote(t))}
            url, d = pick(_entries(_encode(item)), e)
            if url:
                return url, d
    finally:
        stop.set()
    return None, None


# risposta da dare al dialogo "Riprendi" di Stream for Me: 3012 = riprendi, 3013 = dall'inizio.
# Se il punto di visione lo gestisce Addò-flix (piu' aggiornato, salvato anche in caso di crash)
# si sceglie "dall'inizio" e poi Addò-flix porta il video al punto giusto.
# skip = quanti server buoni saltare (nuovo tentativo dopo un server rotto); err = s4me ha mostrato
# un errore (es. "il file non esiste"); nohd = nella lista non c'era nessun server HD.
_s4me = {"choice": 3012, "skip": 0, "err": False, "nohd": False}
SERVER_LIST = 6   # lista dei server di Stream for Me (finestra DialogSelect.xml aperta da s4me)


def _labels(cid):
    try:
        n = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
    except Exception:
        n = 0
    return [xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, i)) for i in range(n)]


def _choose(cid, idx):
    xbmc.executebuiltin("SetFocus(%d,%d)" % (cid, idx))
    xbmc.sleep(250)
    xbmc.executebuiltin("Action(Select)")
    xbmc.sleep(800)


def server_choice(labels, skip=0):
    """Indice del server da avviare nella lista di s4me, None se non ce n'e' uno buono.
    Mai i server [SD] ne' le voci che non sono server (videoteca, download); prima quelli [HD]."""
    good = []
    for i, l in enumerate(labels):
        low = l.lower()
        if "[color" in low or "videoteca" in low or "download" in low or not l.strip():
            continue
        if cb.tags(l) and not cb.is_hd(l):
            continue  # [SD] o altra qualita' bassa
        good.append(i)
    good.sort(key=lambda i: 0 if cb.is_hd(labels[i]) else 1)
    return good[skip] if skip < len(good) else None


def _auto_choose():
    """Risponde da solo ai dialoghi di s4me: lista 'Riproduci ...' (sceglie HD), lista dei server
    (sceglie un server HD), errori del server (li chiude) e 'Riprendi'
    (altrimenti s4me aspetterebbe fino a 10 secondi)."""
    if xbmc.getCondVisibility("Window.IsActive(ResumePlayback.xml)"):
        xbmc.executebuiltin("SetFocus(%d)" % _s4me["choice"])
        xbmc.sleep(150)
        xbmc.executebuiltin("Action(Select)")
        xbmc.sleep(400)
        return
    if xbmc.getCondVisibility("Window.IsActive(yesnodialog) | Window.IsActive(okdialog)"):
        # errore di s4me (server rotto, file cancellato): si chiude e si prova un altro server
        _s4me["err"] = True
        xbmc.executebuiltin("Action(Back)")
        xbmc.sleep(500)
        return
    if xbmc.getCondVisibility("Window.IsActive(selectdialog)"):
        labels = _labels(3)
        play = [i for i, l in enumerate(labels) if l.lower().startswith("riproduci")]
        if play:
            hd = [i for i in play if "hd" in labels[i].lower() and "sd" not in labels[i].lower().replace("hd", "")]
            _choose(3, (hd or play)[0])
            return
    labels = _labels(SERVER_LIST)
    if not labels:
        return  # e' un'altra finestra: la lasciamo all'utente
    idx = server_choice(labels, _s4me["skip"])
    if idx is None:
        _s4me["nohd"] = True
        xbmc.executebuiltin("Action(Back)")
        xbmc.sleep(500)
        return
    _choose(SERVER_LIST, idx)


def _close_server_list(timeout=6.0):
    """Se il video si ferma prima della fine, Stream for Me riapre la sua lista dei server (CB01):
    la si chiude, cosi' si torna alla scheda di Addò-flix."""
    mon = xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if xbmc.Player().isPlaying():
            return
        if xbmc.getCondVisibility("Window.IsActive(DialogSelect.xml)") and _labels(SERVER_LIST):
            xbmc.executebuiltin("Action(Back)")
            return
        mon.waitForAbort(0.3)


def _wait_playing(timeout=50):
    mon = xbmc.Monitor()
    player = xbmc.Player()
    t0 = time.time()
    while time.time() - t0 < timeout and not mon.abortRequested():
        if player.isPlaying():
            return True
        _auto_choose()
        if _s4me["err"] or _s4me["nohd"]:
            mon.waitForAbort(1.0)
            return player.isPlaying()
        mon.waitForAbort(0.5)
    return False


_SXE = (re.compile(r"(?<!\d)(\d{1,2})\s*[xX]\s*(\d{1,3})(?!\d)"),            # 1x01
        re.compile(r"[Ss](?:tagione)?\s*0*(\d{1,2})\s*[Ee](?:pisodio)?\s*0*(\d{1,3})"))  # S01E01 / Stagione 1 Episodio 1


def _sxe(title):
    for rx in _SXE:
        m = rx.search(title or "")
        if m:
            return int(m.group(1)), int(m.group(2))
    return 0, 0


def fix_numbers(eps):
    """s4me a volte da' stagione/episodio 0 (quando le sue ricerche TMDB falliscono) ma il numero
    e' nel titolo ('1x01 - ...'): senza questo l'episodio scelto non si trova e si apre la lista."""
    out = []
    for x in eps:
        s, n = x[0], x[1]
        if not s or not n:
            ts, tn = _sxe(x[3])
            s, n = s or ts, n or tn
        out.append([s, n, x[2], x[3]])
    out.sort(key=lambda x: (x[0], x[1]))
    return out


def _episodes(e, show_url, status=None, fresh=False):
    """Elenco episodi [[stagione, episodio, url, titolo]], memorizzato per un giorno."""
    k = "eps:%s" % e["id"]
    eps = None if fresh else progress.link_get(k, progress.LIST_TTL)
    if eps:
        return fix_numbers(eps)
    if status:
        status("Carico gli episodi...")

    def num(d, *names):
        for n in names:
            try:
                return int(d.get(n) or 0)
            except Exception:
                pass
        return 0

    eps = []
    for u, d in _entries(show_url):
        if d.get("action") != "findvideos":
            continue
        s, n = num(d, "contentSeason", "season"), num(d, "contentEpisodeNumber", "episode")
        t = re.sub(r"\[/?[^\]]*\]", "", d.get("title", "")).strip()
        eps.append([s, n, u, t or "Episodio %d" % n])
    eps = fix_numbers(eps)
    if eps:
        progress.link_put(k, eps)
    return eps


def _choose_episode(eps, want=None):
    """Dialoghi stagione/episodio; 'want' = episodio da proporre gia' selezionato."""
    seasons = sorted({x[0] for x in eps})
    s = seasons[0]
    if want and want.get("s") in seasons:
        s = want["s"]
    if len(seasons) > 1:
        i = xbmcgui.Dialog().select("Stagione", ["Stagione %d" % x for x in seasons], preselect=seasons.index(s))
        if i < 0:
            return CANCEL, None
        s = seasons[i]
    lst = [x for x in eps if x[0] == s]
    pre = 0
    if want and want.get("s") == s:
        pre = next((i for i, x in enumerate(lst) if x[1] == want.get("e")), 0)
    i = xbmcgui.Dialog().select("Stagione %d" % s, [x[3] for x in lst], preselect=pre)
    if i < 0:
        return CANCEL, None
    x = lst[i]
    return x[2], {"s": x[0], "e": x[1], "title": x[3]}


def _resolve(e, status=None, fresh=False, want=None, ask=True):
    """Trova il collegamento s4me da avviare. Ritorna (esito, url, episodio).
    Usa i collegamenti memorizzati (avvio rapido) salvo fresh=True."""
    k = progress.key(e)
    if e["type"] == "movie" and not fresh:
        url = progress.link_get(k)
        if url:
            return OK, url, None
    with _eps_lock:   # se l'elenco si sta gia' preparando in sottofondo, si aspetta quello (niente doppio lavoro)
        show = None if fresh else progress.link_get("show:%s" % e["id"])
        if not show:
            # si prova sempre Stream for Me (a volte arriva al sito anche quando il nostro controllo no)
            url, d = search_channel(e, status)
            if not url:
                # "non trovato" vale solo se il sito risponde; altrimenti non si sa (e non si segna)
                return (NOTFOUND if sc.reachable() else DOWN), None, None
            if d.get("action") == "findvideos":
                m = re.search(r"/watch/(\d+)", d.get("url") or "")
                if m and sc.movie_playable(int(m.group(1))) is False:
                    return NOTFOUND, None, None  # titolo nel catalogo ma senza video disponibile
                progress.link_put(k, url)
                return OK, url, None
            show = url
            progress.link_put("show:%s" % e["id"], show)
        eps = _episodes(e, show, status, fresh)
    return _pick_episode(eps, want, ask)


_eps_lock = threading.RLock()


def prefetch(e):
    """Scheda di una serie aperta: l'elenco delle puntate di Stream for Me (lento: una pagina per
    stagione) si prepara subito in sottofondo, cosi' 'Guarda' lo trova gia' pronto.
    Solo se non e' gia' in memoria (vale un giorno): al massimo una volta al giorno per serie."""
    if e.get("type") != "tv" or progress.link_get("eps:%s" % e["id"], progress.LIST_TTL):
        return
    t0 = time.time()
    try:
        with _eps_lock:
            if progress.link_get("eps:%s" % e["id"], progress.LIST_TTL):
                return
            show = progress.link_get("show:%s" % e["id"])
            if not show:
                url, d = search_channel(e)
                if not url or d.get("action") != "episodios":
                    return
                show = url
                progress.link_put("show:%s" % e["id"], show)
            n = len(_episodes(e, show))
        xbmc.log("[veloceflix] puntate preparate in anticipo: %d in %.1f s" % (n, time.time() - t0), xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log("[veloceflix] puntate in anticipo: %r" % (ex,), xbmc.LOGINFO)


def _pick_episode(eps, want, ask):
    if not eps:
        return NOTFOUND, None, None
    if want and not ask:  # stesso episodio, senza dialoghi (riavvio dopo un errore)
        for x in eps:
            if x[0] == want.get("s") and x[1] == want.get("e"):
                return OK, x[2], {"s": x[0], "e": x[1], "title": x[3]}
    url, ep = _choose_episode(eps, want)
    if url == CANCEL:
        return CANCEL, None, None
    return OK, url, ep


# ---------- CB01 (seconda fonte: solo HD, solo italiano) ----------
def _resolve_cb(e, status=None, fresh=False, want=None, ask=True):
    k = progress.key(e)
    if e["type"] == "movie":
        url = None if fresh else progress.link_get("cb:" + k)
        if url:
            return OK, url, None
    show = None if fresh else progress.link_get("cbshow:%s" % e["id"])
    if not show:
        url, d = cb.find(e, status)
        if not url:
            return (DOWN if d is False else NOTFOUND), None, None
        if e["type"] == "movie":
            progress.link_put("cb:" + k, url)
            return OK, url, None
        show = url
        progress.link_put("cbshow:%s" % e["id"], show)
    eps = None if fresh else progress.link_get("cbeps:%s" % e["id"], progress.LIST_TTL)
    if not eps:
        if status:
            status("Carico gli episodi...")
        eps = fix_numbers(cb.episodes(show) or [])
        eps = [x for x in eps if x[0] and x[1]]
        if eps:
            progress.link_put("cbeps:%s" % e["id"], eps)
    return _pick_episode(fix_numbers(eps), want, ask)


def _play_cb(e, url, ep, start, status=None):
    """Prova i server HD della lista uno dopo l'altro (un server puo' avere il file cancellato)."""
    try:
        # ogni server HD si prova due volte (spesso l'errore e' momentaneo), poi il successivo
        for i, skip in enumerate((0, 0, 1, 1, 2)):
            _s4me["skip"] = skip
            if i and status:
                status("Riprovo..." if skip == (0, 0, 1, 1, 2)[i - 1] else "Provo un altro server HD...")
            res = _play(e, url, ep, start, status)
            if res == OK or not _s4me["err"]:
                return res  # partito, oppure nessun altro server HD da provare
        return FAIL
    finally:
        _s4me["skip"] = 0


_ctx = {}   # scelte gia' fatte nel tentativo su StreamingCommunity (punto di ripresa, episodio)


def _watch_cb(e, status=None, episode=None, ctx=None):
    series = e["type"] == "tv"
    start, want, ask = 0, None, True
    if episode and series:
        want, start, ask = {"s": episode["s"], "e": episode["e"]}, int(episode.get("start") or 0), False
    elif ctx and ctx.get("asked"):
        start, want = ctx.get("start") or 0, ctx.get("want")
        ask = not start  # si stava riprendendo: stesso episodio, senza dialoghi
    else:
        saved = progress.get(e)
        if saved:
            r = _ask_resume(saved, series)
            if r is None:
                return CANCEL
            want = saved.get("ep")
            if r:
                start = saved["pos"]
                ask = not series
            elif not series:
                start = 0
    _s4me["choice"] = 3013  # il punto di visione lo gestisce Addò-flix
    rc, url, ep = _resolve_cb(e, status, want=want, ask=ask if series else True)
    if rc != OK:
        return rc
    if want and ep and (ep.get("s"), ep.get("e")) != (want.get("s"), want.get("e")):
        start = 0  # altro episodio: dall'inizio
    res = _play_cb(e, url, ep, start, status)
    if res == FAIL and e["type"] == "movie":
        progress.link_drop("cb:" + progress.key(e))
    return res


def _cb(e, status=None, episode=None, ctx=None):
    res = _watch_cb(e, status, episode, ctx)
    if res == OK:
        sc.mark(e, True, "cb")
    elif res in (NOTFOUND, FAIL):
        sc.mark(e, False, "cb")  # su CB01 non c'e' (o nessun server HD funziona)
    return res




def _ask_resume(v, series):
    """True = riprendi, False = dall'inizio / altro episodio, None = annullato."""
    if progress.setting("resume", "ask") == "auto":
        return True
    other = "Scegli un altro episodio" if series else "Guarda dall'inizio"
    i = xbmcgui.Dialog().select("Addò-flix", ["Riprendi %s" % progress.label(v), other])
    return None if i < 0 else i == 0


def _notify(msg, ms=4000):
    xbmcgui.Dialog().notification("Addò-flix", msg, xbmcgui.NOTIFICATION_INFO, ms)


# ---------- controllo della visione (salvataggio continuo + riavvio se cade lo stream) ----------
_gen = {"n": 0}


class _Watch(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.user_stop = self.ended = self.error = False
        self.seek_to = None      # salto chiesto dall'utente: punto scelto (s) e quando
        self.seek_at = 0.0
        self.own_seek_until = 0.0  # salti fatti da Addo-flix (ripresa): non sono dell'utente

    def onPlayBackSeek(self, target_ms, offset_ms):
        # Kodi lo segnala subito, anche se il tempo mostrato cambia solo a caricamento finito
        if time.time() < self.own_seek_until:
            return
        self.seek_to = max(0.0, (target_ms or 0) / 1000.0)
        self.seek_at = time.time()

    def seek_own(self, secs):
        self.own_seek_until = time.time() + 5
        self.own_to, self.own_at = float(secs), time.time()
        self.seekTime(secs)

    own_to, own_at = None, 0.0   # salto fatto da Addo-flix (ripresa): punto e quando

    def onPlayBackStopped(self):
        self.user_stop = True

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackError(self):
        self.error = True


STUCK_SECS = 20                 # video fermo (non in pausa) per tanto cosi': lo stream non riparte da solo
RETRY_WAITS = (0, 10, 20, 30, 30, 60, 60, 60)  # ripresa: subito, poi con attese crescenti (~5 minuti:
                                               # basta anche per il riavvio del modem)
SETTLE_SECS = 8                 # dopo una ripartenza: qualche secondo in pausa per accumulare video
HUNG_SECS = 15                  # un giro di controllo (1 s) che dura piu' di cosi' = Kodi bloccato sulla rete
NET_RECHECK_SECS = 2            # "stop" con la rete assente: si ricontrolla dopo tanto cosi' (niente falsi allarmi)
NET_POLL_SECS = 6               # durante la visione: ogni tanto cosi' si controlla se la rete c'e'
NET_WAIT_MAX = sum(RETRY_WAITS)  # attesa massima della rete (~5 minuti), poi il film si chiude
CREDITS_SIGNAL_SECS = 300       # salto avanti/stop negli ultimi 5 minuti = li' iniziano i titoli di coda
SEEK_JUMP_SECS = 15            # il tempo salta di piu' in un giro (1 s): e' un salto dell'utente
SEEK_STUCK_SECS = 25            # dopo un salto: fermo da tanto cosi' -> si chiede all'utente cosa fare
SEEK_ASK_WINDOW = 120           # ...ma solo nei primi 2 minuti dopo il salto
SEEK_BACK_SECS = 6             # ripresa dopo l'attesa: salto un po' prima del punto (pezzi di video da ~5 s)
RESUME_GRACE_SECS = 20         # dopo l'attesa: se il video non riparte (o Kodi lo chiude) si ricarica da solo
VIDEO_HOST = "vixcloud.cc"      # server dei video di StreamingCommunity (per sapere se la rete e' tornata)


def _bg(fn):
    """Esegue fn in sottofondo (le prove offline la sostituiscono con una chiamata diretta)."""
    threading.Thread(target=fn, daemon=True).start()


class _WaitDialog:
    """Finestra "In attesa di connessione..." con il tempo che resta; l'utente puo' annullare."""

    def __init__(self, good, total=NET_WAIT_MAX):
        self.good, self.total, self.t0 = good, total, time.time()
        self.d = xbmcgui.DialogProgress()
        self.d.create("Addò-flix", self._text())

    def _text(self):
        left = max(0, int(self.total - (time.time() - self.t0)))
        return ("In attesa di connessione...[CR]Il film riprende da solo da %s appena torna la rete.[CR]"
                "Attendo ancora %d:%02d (Annulla per chiudere il film)" % (progress.fmt(self.good), left // 60, left % 60))

    def left(self):
        return self.total - (time.time() - self.t0)

    def wait(self, secs, mon, net=None, alive=None):
        """Aspetta fino a 'secs' secondi aggiornando la finestra. Ritorna "cancel" (annullato dall'utente),
        "net" (net() dice che la rete e' tornata), "closed" (alive() falso: video chiuso) o "time"."""
        end = time.time() + max(0, min(secs, self.left()))
        next_net = time.time()
        st = {"busy": False, "ok": False}

        def check():
            try:
                st["ok"] = bool(net())
            finally:
                st["busy"] = False
        while True:
            self.d.update(max(0, min(100, int(100 * (time.time() - self.t0) / self.total))), self._text())
            if self.d.iscanceled():
                return "cancel"
            if alive is not None and not alive():
                return "closed"
            if st["ok"]:
                return "net"
            if net is not None and time.time() >= next_net and not st["busy"]:
                # in sottofondo: senza rete il controllo dura qualche secondo e il conto alla rovescia si fermerebbe
                st["busy"] = True
                next_net = time.time() + 3
                _bg(check)
                if st["ok"]:
                    return "net"
            if time.time() >= end:
                return "time"
            if mon.waitForAbort(1):
                return "cancel"

    def close(self):
        try:
            self.d.close()
        except Exception:
            pass


def _net_ok(url):
    """La rete e' tornata? Si prova a raggiungere il server del video (nome + collegamento, 4 s al massimo).
    Ripartire senza rete farebbe solo un altro blocco."""
    import socket
    host = VIDEO_HOST
    if _decode(url).get("channel") == cb.CHANNEL:
        host = urllib.parse.urlparse(cb.host()).netloc or host
    proxy = _kodi_proxy()
    try:
        if proxy:
            # Kodi esce in rete da un proxy HTTP: si prova la stessa strada che usa il video
            s = socket.create_connection(proxy, timeout=4)
            try:
                s.settimeout(4)
                s.sendall(("CONNECT %s:443 HTTP/1.1\r\nHost: %s:443\r\n\r\n" % (host, host)).encode("ascii"))
                return s.recv(64).split(b" ")[1:2] == [b"200"]
            finally:
                s.close()
        socket.create_connection((host, 443), timeout=4).close()
        return True
    except Exception:
        return False


def _wait_network(p, url, mon, good):
    """Rete sparita durante la visione: il film va in pausa (resta aperto) con la finestra
    "In attesa di connessione...". Ritorna "net" (rete tornata: il film riprende), "cancel" (l'utente
    annulla), "time" (attesa massima finita) o "closed" (Kodi ha chiuso il video nel frattempo)."""
    ours = False
    try:
        if not xbmc.getCondVisibility("Player.Paused"):
            p.pause()
            ours = True
    except Exception:
        pass
    dlg = _WaitDialog(good)
    try:
        r = dlg.wait(NET_WAIT_MAX, mon, net=lambda: _net_ok(url), alive=p.isPlaying)
    finally:
        dlg.close()
    if r == "net" and ours:
        try:
            # Durante la pausa il lettore del TV continua a scaricare e, senza rete, rinuncia ai pezzi
            # mancanti: ripartendo cosi' com'e' arriverebbe in fondo al caricato e il film si chiuderebbe.
            # Un salto sullo stesso punto gli fa riscaricare il video da li'. Il lettore riparte solo
            # all'inizio di un pezzo di video (~5 s) DOPO il punto chiesto: si chiede qualche secondo
            # prima, cosi' si riparte al massimo un po' indietro, mai piu' avanti (prove sul PC).
            p.seek_own(max(0.0, good - SEEK_BACK_SECS))
            mon.waitForAbort(1)
        except Exception:
            pass
        try:
            if xbmc.getCondVisibility("Player.Paused"):
                p.pause()
        except Exception:
            pass
    return r


def _kodi_proxy():
    """(server, porta) del proxy HTTP impostato in Kodi, se e' attivo; altrimenti None."""
    def get(k):
        r = json.loads(xbmc.executeJSONRPC(json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue", "params": {"setting": k}})))
        return r.get("result", {}).get("value")
    try:
        if get("network.usehttpproxy") and int(get("network.httpproxytype") or 0) == 0:
            server, port = get("network.httpproxyserver"), int(get("network.httpproxyport") or 0)
            if server and port:
                return (server, port)
    except Exception:
        pass
    return None


def _track(e, url, ep, start, gen, retries=3, settle=0):
    p, mon = _Watch(), xbmc.Monitor()
    t0 = time.time()
    while time.time() - t0 < 60 and not mon.abortRequested():
        try:
            if p.isPlayingVideo() and p.getTotalTime() > 0:
                break
        except Exception:
            pass
        mon.waitForAbort(0.5)
    try:
        playing = p.getPlayingFile()
    except Exception:
        playing = ""
    if start >= progress.MIN_RESUME:
        try:
            if abs(p.getTime() - start) > 20:
                p.seek_own(max(0, start - 5))  # qualche secondo prima, per riprendere il filo
        except Exception:
            pass
    if playing:
        progress.even_volume()  # vale solo per questo video (anche dopo un riavvio dello stream)
    if playing and settle:
        # ripartenza dopo un blocco: qualche secondo in pausa, cosi' il video si carica in anticipo
        # e non riparte a scatti (per poi ribloccarsi) con la linea appena tornata
        try:
            p.pause()
            _notify("Carico qualche secondo di video...", 2500)
            mon.waitForAbort(settle)
            if xbmc.getCondVisibility("Player.Paused"):
                p.pause()
        except Exception:
            pass
    pos = total = 0.0
    last = 0.0
    t_start = time.time()
    stalls = []          # momenti in cui il video si e' fermato a caricare
    caching = False
    lowered = False
    next_checked, go_next = False, None
    stuck = False
    moved_pos, moved_t = -1.0, time.time()   # ultimo momento in cui il video e' andato avanti davvero
    good = float(start)   # ultimo punto visto scorrere bene: da qui si riprende (salvataggio e ripartenza)
    tick = time.time()    # ultimo giro di controllo completato
    hung = False          # Kodi e' rimasto senza rispondere (rete caduta): la chiusura non e' dell'utente
    next_net = time.time() + NET_POLL_SECS
    net_bad = 0           # controlli di rete falliti di fila
    grace_until = 0.0     # rete appena tornata: un blocco o una chiusura adesso non sono dell'utente
    waited = None         # esito dell'attesa della rete: None, "cancel" (utente), "time" (attesa finita)
    seek_t = 0.0          # ultimo salto fatto dall'utente (avanti o indietro)
    seek_retry = False    # ripartenza chiesta dall'utente dopo un salto: la qualita' non scende
    tail = progress.credits_tail(e, nextep.trigger_secs()) if e.get("type") == "tv" else 0
    popup = None          # esito del popup "Prossimo episodio" e posizione in cui e' comparso
    credit_sig = None     # salto avanti dell'utente negli ultimi minuti: li' iniziano i titoli di coda
    user_seek = None   # user_seek = (da, a) dell'ultimo salto dell'utente in questo giro
    while not mon.abortRequested():
        try:
            if not p.isPlaying() or p.getPlayingFile() != playing:
                # chiuso subito dopo il ritorno della rete: e' Kodi (video caricato finito), non l'utente
                hung = time.time() - tick > HUNG_SECS or time.time() < grace_until
                break
            pos, total = p.getTime(), p.getTotalTime()
        except Exception:
            hung = time.time() - tick > HUNG_SECS
            break
        tick = time.time()
        # Durante un blocco (rete in calo) il tempo del lettore puo' continuare ad avanzare anche con
        # l'immagine ferma: conta solo il tempo che avanza SENZA caricamento in corso.
        now_caching = xbmc.getCondVisibility("Player.Caching")
        advancing = abs(pos - moved_pos) > 0.5
        if p.seek_at > seek_t and p.seek_to is not None:
            # salto dell'utente segnalato da Kodi (il tempo mostrato resta quello vecchio finche' carica)
            seek_t = moved_t = time.time()
            user_seek = (moved_pos if moved_pos >= 0 else pos, p.seek_to)
            good = p.seek_to
            xbmc.log("[veloceflix] salto dell'utente a %s" % progress.fmt(good), xbmc.LOGINFO)
        elif moved_pos >= 0 and abs(pos - moved_pos) > SEEK_JUMP_SECS and time.time() - t_start > 20:
            # salto dell'utente: il nuovo punto e' quello scelto, e il caricamento che segue non e' un blocco
            seek_t = moved_t = time.time()
            user_seek = (moved_pos, pos)
            good = pos
            xbmc.log("[veloceflix] salto da %s a %s" % (progress.fmt(moved_pos), progress.fmt(pos)), xbmc.LOGINFO)
        # arrivato al punto del salto: il salto e' finito (poi il video scorre normalmente oltre quel punto)
        if p.seek_to is not None and p.seek_to - 5 <= pos <= p.seek_to + 30:
            p.seek_to = None
        if p.own_to is not None and p.own_to - 15 <= pos <= p.own_to + 60:
            p.own_to = None
        # salto in corso (il tempo mostrato non e' ancora arrivato al punto scelto): il punto buono e' quello scelto
        seeking = ((p.seek_to is not None and seek_t and time.time() - seek_t < SEEK_ASK_WINDOW
                    and abs(pos - p.seek_to) > 5)
                   # ripresa: il video parte da 0:00 e poi salta al punto salvato; finche' non ci arriva
                   # quel punto resta il buono (prova sul PC 25/11: altrimenti ripartiva da 0:00)
                   or (p.own_to is not None and time.time() - p.own_at < SEEK_ASK_WINDOW
                       and abs(pos - p.own_to) > 15 and pos < p.own_to))
        if advancing and not now_caching and not seeking:
            good = pos
        if seeking:
            advancing = False
        paused = xbmc.getCondVisibility("Player.Paused")
        if time.time() >= next_net and not paused:
            # rete sparita? Meglio accorgersene subito, finche' c'e' ancora video caricato
            net_bad = 0 if _net_ok(url) else net_bad + 1
            next_net = time.time() + (NET_RECHECK_SECS if net_bad else NET_POLL_SECS)
            tick = time.time()
            if net_bad >= 2:
                xbmc.log("[veloceflix] rete assente a %s: pausa e attesa della connessione" % progress.fmt(good), xbmc.LOGINFO)
                waited = _wait_network(p, url, mon, good)
                net_bad, tick, moved_t = 0, time.time(), time.time()
                next_net = time.time() + NET_POLL_SECS
                if waited == "net":
                    waited = None
                    grace_until = time.time() + RESUME_GRACE_SECS
                    xbmc.log("[veloceflix] rete tornata: il film riprende", xbmc.LOGINFO)
                    mon.waitForAbort(1)
                    continue
                if waited == "closed":
                    waited = None
                    hung = True  # chiuso da Kodi durante l'attesa: non e' l'utente, si riprova
                    break
                try:
                    p.stop()   # "cancel" (scelta dell'utente) o "time" (attesa massima finita)
                except Exception:
                    pass
                break
        if paused or (advancing and not now_caching):
            moved_t = time.time()
        elif time.time() < grace_until and time.time() - moved_t > SETTLE_SECS:
            # rete tornata ma il video non riparte: si ricarica dallo stesso punto
            stuck = True
            xbmc.log("[veloceflix] il video non riparte dopo l'attesa: lo ricarico da %s" % progress.fmt(good), xbmc.LOGINFO)
            break
        elif seek_t and time.time() - seek_t < SEEK_ASK_WINDOW and time.time() - moved_t > SEEK_STUCK_SECS:
            # fermo dopo un salto dell'utente (la rete funziona): si chiede cosa fare
            xbmc.log("[veloceflix] video fermo dopo il salto a %s: chiedo all'utente" % progress.fmt(good), xbmc.LOGINFO)
            nxt = _next_of(e, ep) if (ep and e.get("type") == "tv") else None
            choice = _ask_stuck(good, nxt)
            if choice == "next" and nxt:
                go_next = nxt
                break
            if choice == "retry":
                stuck = seek_retry = True
                break
            waited = "cancel"
            try:
                p.stop()
            except Exception:
                pass
            break
        elif (time.time() - moved_t > STUCK_SECS and time.time() - t_start > STUCK_SECS
              and not (seek_t and time.time() - seek_t < SEEK_ASK_WINDOW)):
            # video fermo (o in caricamento senza fine): lo stream non riparte da solo
            stuck = True
            xbmc.log("[veloceflix] video fermo da %d s a %s: lo faccio ripartire" % (STUCK_SECS, progress.fmt(good)), xbmc.LOGINFO)
            break
        moved_pos = pos
        # serie: salto in avanti dell'utente negli ultimi ~5 minuti, prima del popup = titoli di coda
        # (vale per le prossime puntate; una volta per puntata; le pause NON contano)
        if (credit_sig is None and ep and e.get("type") == "tv" and total > 300 and not next_checked
                and time.time() - t_start > 20):
            fwd = user_seek is not None and user_seek[1] > user_seek[0] + 5
            left = total - user_seek[0] if fwd else 0   # dove si e' deciso di saltare
            if fwd and tail < left <= CREDITS_SIGNAL_SECS:
                credit_sig = left
                n = progress.learn_tail(e, left)
                xbmc.log("[veloceflix] salto avanti a %d s dalla fine: titoli di coda di questa serie ora %d s"
                         % (left, n), xbmc.LOGINFO)
        user_seek = None
        # serie: ai titoli di coda il popup "Prossimo episodio" (conto alla rovescia, Annulla, Guarda ora)
        if (not next_checked and ep and e.get("type") == "tv" and gen == _gen["n"] and total > 300
                and pos > 60 and total - pos <= tail and nextep.enabled() and not now_caching):
            next_checked = True
            nxt = _next_of(e, ep)
            if nxt:
                res = nextep.ask(nxt, p, playing, mon, nxt.get("thumb", ""))
                popup = (res, pos)
                if res in (nextep.GO, nextep.AUTO):
                    go_next = nxt
                    break
            tick = time.time()  # la finestra "Prossimo episodio" e' durata un po': non e' Kodi bloccato
        if time.time() - last >= 5 and good > 5 and not progress.is_done(good, total):
            # ogni 5 s (un crash perde al massimo pochi secondi); mai un punto "visto" solo dal contatore
            progress.put(e, good, total, url, ep)
            last = time.time()
        # blocchi per caricamento (dopo i primi 20 s, quando il buffer iniziale e' pieno)
        if now_caching and not caching and time.time() - t_start > 20:
            stalls = [t for t in stalls if time.time() - t < 300] + [time.time()]
            if len(stalls) >= 3 and not lowered:
                # linea in calo: dalla prossima partenza (o dal riavvio) un gradino piu' in basso
                progress.step_down()
                lowered = True
        caching = now_caching
        mon.waitForAbort(1)
    if go_next is None:
        threading.Thread(target=_close_server_list, daemon=True).start()
    if go_next is not None and gen == _gen["n"]:
        # puntata finita (siamo ai titoli di coda): segnata come vista, poi parte la successiva
        progress.record(e, total, total, ep, force=True)
        progress.episode_finished(e, ep, go_next)   # la serie resta in "Continua a guardare"
        _play_next(e, go_next)
        return
    mon.waitForAbort(1.5)  # lascia arrivare le notifiche del player (fine, errore, stop)
    if seek_t and time.time() - seek_t < SEEK_ASK_WINDOW + 30 and abs(pos - good) > 3:
        pos = good   # dopo un salto dell'utente vale il punto scelto (anche se il video non ci e' arrivato)
    elif not progress.is_done(pos, total) and pos - good > 3:
        # caduta, blocco, o uscita dell'utente durante un blocco: il contatore era andato avanti da solo.
        # Si salva (e si riprende) l'ultimo punto visto scorrere davvero.
        pos = good
    if pos > 5:
        progress.record(e, pos, total, ep, force=True)  # cronologia: visto / a che punto
    if ep and e.get("type") == "tv" and total > 300 and credit_sig is None:
        _learn_credits(e, p, pos, total, tail, popup)
    if progress.is_done(pos, total):
        if ep and e.get("type") == "tv":
            progress.episode_finished(e, ep, _next_cached(e, ep))   # resta con la prossima puntata
        else:
            progress.clear(e)
    elif pos > 5:
        progress.put(e, pos, total, url, ep)
    if hung:
        xbmc.log("[veloceflix] Kodi e' rimasto bloccato (rete assente): la chiusura del video non e' dell'utente", xbmc.LOGINFO)
    # Se Kodi e' rimasto bloccato a lungo (rete caduta) chiude il video da solo e lo segnala come uno
    # "stop": non e' l'utente, quindi si riparte lo stesso.
    broken = ((p.error or p.ended or stuck or hung) and (hung or not p.user_stop)
              and total > 0 and not progress.is_done(pos, total) and waited is None)
    if waited == "time":
        _notify("Nessuna connessione: film chiuso. Riprendi da %s quando torna la rete" % progress.fmt(pos), 8000)
    elif waited == "cancel":
        _notify("Film chiuso: riprendi da %s quando vuoi" % progress.fmt(pos))
    if (not broken and waited is None and p.user_stop and total > 0 and not progress.is_done(pos, total)
            and not _net_ok(url) and not mon.waitForAbort(NET_RECHECK_SECS) and not _net_ok(url)):
        # Rete caduta: il video va avanti con quello gia' caricato, poi Kodi arriva in fondo e lo chiude
        # da solo segnalandolo come uno "stop" (prove sul TV del 22/11). Con la rete che funziona lo
        # stop e' dell'utente: li' non si riparte mai.
        broken = True
        xbmc.log("[veloceflix] video chiuso senza rete: non e' uno stop dell'utente, riprendo", xbmc.LOGINFO)
    if (broken and retries > 0 and gen == _gen["n"] and not mon.abortRequested()
            and progress.setting("auto_retry", "true") == "true"):
        # un blocco vero (video fermo) scende sempre di un gradino: la linea non regge quella qualita'
        cap = progress.effective_cap() if ((lowered and not stuck) or seek_retry) else progress.step_down()
        what = "Video bloccato" if stuck else "Connessione persa"
        _notify("%s: riprendo da %s (max %s)" % (what, progress.fmt(pos), cap))
        _s4me["choice"] = 3013
        dlg, net_down = None, False
        try:
            for i, wait in enumerate(RETRY_WAITS):
                if i:
                    # si riprova da soli, con attese crescenti; intanto la finestra "In attesa di connessione"
                    # (se la rete torna prima, si riparte subito)
                    if dlg is None:
                        dlg = _WaitDialog(pos)
                    r = dlg.wait(wait, mon, net=(lambda: _net_ok(url)) if net_down else None)
                    if r == "cancel":
                        _notify("Film chiuso: riprendi da %s quando vuoi" % progress.fmt(pos))
                        return
                if gen != _gen["n"] or (i and xbmc.Player().isPlaying()):
                    return  # nel frattempo l'utente ha avviato altro
                _stop_current()
                net_down = not _net_ok(url)
                if net_down:
                    continue  # la rete non e' ancora tornata: si aspetta invece di ripartire a vuoto
                if dlg is not None:
                    dlg.close()
                    dlg = None
                progress.cap_quality()  # il nuovo tetto vale dal riavvio
                _s4me["err"] = _s4me["nohd"] = False
                xbmc.executebuiltin("RunPlugin(%s)" % url)
                if _wait_playing():
                    return _track(e, url, ep, pos, gen, retries - 1, settle=SETTLE_SECS)
            _notify("Non riesco a riprendere: riprova tra poco")
        finally:
            if dlg is not None:
                dlg.close()
    elif not broken and not stalls and time.time() - t_start > 20 * 60:
        progress.step_up()  # 20 minuti senza blocchi: la linea regge, si risale di un gradino
    if gen == _gen["n"]:
        progress.restore_quality()


def _next_cached(e, ep):
    """Puntata dopo 'ep' dall'elenco gia' salvato (nessuna richiesta in rete). None = era l'ultima.
    Elenco non disponibile: si suppone la successiva nella stessa stagione (alla partenza si ricontrolla)."""
    eps = progress.link_get("eps:%s" % e["id"], progress.LINK_TTL)
    if not eps:
        return {"s": ep.get("s"), "e": int(ep.get("e") or 0) + 1}
    try:
        return nextep.find_next(fix_numbers(eps), ep)
    except Exception:
        return {"s": ep.get("s"), "e": int(ep.get("e") or 0) + 1}


def _learn_credits(e, p, pos, total, tail, popup):
    """Impara da come si usa la serie dove iniziano davvero i titoli di coda (un numero per serie):
    - popup comparso, Annulla, e la puntata va avanti fino alla fine: era troppo presto -> meno secondi
    - popup comparso, Annulla, poi stop dell'utente piu' avanti: i titoli iniziano li'
    - nessun popup ancora, stop dell'utente negli ultimi minuti: i titoli iniziavano prima"""
    left = total - pos
    try:
        if popup and popup[0] == nextep.CANCEL:
            if p.ended or left <= 5:
                n = progress.learn_tail(e, tail / 2.0)
            elif p.user_stop and pos > popup[1] + 5:
                n = progress.learn_tail(e, left)
            else:
                return
        elif not popup and p.user_stop and tail < left <= CREDITS_SIGNAL_SECS and progress.is_done(pos, total):
            n = progress.learn_tail(e, left)
        else:
            return
        xbmc.log("[veloceflix] titoli di coda di questa serie: ora %d s prima della fine" % n, xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log("[veloceflix] titoli di coda: %r" % (ex,), xbmc.LOGINFO)


def _ask_stuck(good, nxt):
    """Video fermo dopo un salto: 'retry' (riprova da li'), 'next' (puntata successiva) o 'cancel'."""
    opts = [("retry", "Riprova da %s" % progress.fmt(good))]
    if nxt:
        opts.append(("next", "Puntata successiva: S%s E%s" % (nxt.get("s"), nxt.get("e"))))
    opts.append(("cancel", "Annulla (chiudi il video)"))
    i = xbmcgui.Dialog().select("Video bloccato", [o[1] for o in opts])
    return opts[i][0] if i >= 0 else "cancel"


def _next_of(e, ep):
    """Episodio dopo 'ep' (dall'elenco di s4me gia' trovato), con titolo e immagine di TMDB se ci sono."""
    try:
        show = progress.link_get("show:%s" % e["id"])
        if not show:
            return None
        nxt = nextep.find_next(_episodes(e, show), ep)
        if not nxt:
            return None
        try:
            import tmdb
            info = next((x for x in tmdb.season(e["id"], nxt["s"]) if x["e"] == nxt["e"]), None)
            if info:
                nxt["title"] = info["title"]
                nxt["thumb"] = info["still"]
        except Exception:
            pass
        nxt["title"] = re.sub(r"^\s*\d+\s*[xX]\s*\d+\s*-\s*", "", nxt.get("title") or "") or "Episodio %s" % nxt["e"]
        return nxt
    except Exception as ex:
        xbmc.log("[veloceflix] prossimo episodio: %r" % (ex,), xbmc.LOGINFO)
        return None


def _play_next(e, nxt):
    starting["n"] += 1
    try:
        _play_next_inner(e, nxt)
    finally:
        starting["n"] -= 1


def _play_next_inner(e, nxt):
    _s4me["choice"] = 3013
    rc, url, ep = _resolve(e, None, want={"s": nxt["s"], "e": nxt["e"]}, ask=False)
    if rc == OK and url and _play(e, url, ep, 0) == OK:
        return
    _notify("Non riesco ad avviare il prossimo episodio")
    if not xbmc.Player().isPlaying():
        progress.restore_quality()


def _stop_current(timeout=10):
    """Un video gia' in riproduzione si ferma prima di avviarne un altro: altrimenti l'attesa
    dell'avvio crederebbe partito il nuovo e non risponderebbe ai dialoghi di s4me ("scegli")."""
    p, mon = xbmc.Player(), xbmc.Monitor()
    if not p.isPlaying():
        return
    p.stop()
    t0 = time.time()
    while p.isPlaying() and time.time() - t0 < timeout and not mon.abortRequested():
        mon.waitForAbort(0.2)
    mon.waitForAbort(1.0)  # il controllo della visione precedente salva il punto e si chiude


starting = {"n": 0}   # avvii in corso: la home non riapre la scheda nel cambio tra due episodi


def _play(e, url, ep, start, status=None):
    starting["n"] += 1
    try:
        return _play_inner(e, url, ep, start, status)
    finally:
        starting["n"] -= 1


def _play_inner(e, url, ep, start, status=None):
    if status:
        status("Avvio la riproduzione...")
    _gen["n"] += 1  # prima di tutto: il controllo della visione precedente non tocca piu' la qualita'
    gen = _gen["n"]
    _stop_current()
    progress.cap_quality()
    _s4me["err"] = _s4me["nohd"] = False
    xbmc.executebuiltin("RunPlugin(%s)" % url)
    if not _wait_playing():
        if gen == _gen["n"]:
            progress.restore_quality()
        return FAIL
    threading.Thread(target=_track, args=(e, url, ep, start, gen), daemon=True).start()
    return OK


# ---------- API ----------
def watch(e, status=None, episode=None, prefer=None):
    """Ritorna OK, NOTFOUND, NOSOURCE, FAIL, DOWN o CANCEL. Da chiamare in un thread (blocca).
    episode = {"s", "e", "start"}: avvia direttamente quell'episodio (dalla scheda della serie).
    prefer = CB01: si va subito su CB01 (l'utente l'ha gia' scelto nella ricerca).
    Se StreamingCommunity non ha il titolo (o non risponde) si passa da soli a CB01."""
    if not available():
        return NOSOURCE
    if prefer == CB01:
        return _cb(e, status, episode)
    _ctx.clear()
    res = _watch(e, status, episode)
    if res == NOTFOUND:
        sc.mark(e, False)  # non e' su StreamingCommunity (sparisce solo se manca anche su CB01)
    if res in (NOTFOUND, DOWN, FAIL):
        # passaggio automatico a CB01, senza domande
        if status:
            status("Provo su CB01...")
        res = _cb(e, status, episode, dict(_ctx))
    return res


def _watch(e, status=None, episode=None):
    if not available():
        return NOSOURCE
    progress.restore_quality()  # se un crash precedente l'avesse lasciata limitata
    if episode and e["type"] == "tv":
        want = {"s": episode["s"], "e": episode["e"]}
        start = int(episode.get("start") or 0)
        _s4me["choice"] = 3013  # il punto lo gestisce Addò-flix
        rc, url, ep = _resolve(e, status, want=want, ask=False)
        if rc != OK:
            return rc
        if ep and (ep.get("s"), ep.get("e")) != (want["s"], want["e"]):
            start = 0  # episodio diverso da quello chiesto: dall'inizio
        res = _play(e, url, ep, start, status)
        if res == FAIL:
            if status:
                status("Riprovo...")
            rc, url2, ep2 = _resolve(e, status, fresh=True, want=want, ask=False)
            if rc == OK and url2:
                res = _play(e, url2, ep2 or ep, start, status)
        return res
    saved = progress.get(e)
    series = e["type"] == "tv"
    start, url, ep, want = 0, None, None, None
    if saved:
        r = _ask_resume(saved, series)
        if r is None:
            return CANCEL
        if r:
            start, url, ep = saved["pos"], saved.get("url"), saved.get("ep")
        elif series:
            want = saved.get("ep")  # propone l'ultimo episodio gia' selezionato
    ask = True
    if url and _decode(url).get("channel") == cb.CHANNEL:
        # punto salvato su CB01: prima si riprova StreamingCommunity (qualita' migliore), stesso punto
        url, want, ask = None, ep or want, not (series and ep)
    _ctx.update(asked=True, start=start, want=ep or want)  # per CB01, se qui non si trova
    # col nostro punto di visione si fa partire s4me dall'inizio e si porta noi il video al punto giusto
    _s4me["choice"] = 3013 if saved else 3012
    if not url:
        rc, url, ep = _resolve(e, status, want=want, ask=ask)
        if rc != OK:
            return rc
        if ep and saved and ep != saved.get("ep"):
            start = 0  # altro episodio: si parte dall'inizio
    res = _play(e, url, ep, start, status)
    if res == FAIL:
        # il collegamento memorizzato potrebbe essere scaduto: nuova ricerca e un altro tentativo
        if status:
            status("Riprovo...")
        rc, url2, ep2 = _resolve(e, status, fresh=True, want=ep, ask=ep is None and series)
        if rc == OK and url2:
            res = _play(e, url2, ep2 or ep, start, status)
    return res
