"""CB01 (canale cineblog01 di Stream for Me): seconda fonte, solo HD e solo in italiano.

Il sito blocca le richieste dirette, quindi ogni ricerca passa da Stream for Me (JSON-RPC), come per
StreamingCommunity in source.py. I risultati portano l'id TMDB: il titolo giusto si riconosce con sicurezza.
"""
import base64
import json
import re
import urllib.parse

import xbmc

import sc

S4ME = "plugin.video.s4me"
CHANNEL = "cineblog01"
BASE = "plugin://%s/?" % S4ME

_TAGS = re.compile(r"\[/?(?:B|I|COLOR[^\]]*)\]", re.I)


def host():
    return sc.host(CHANNEL)


# ---------- chiamate a Stream for Me ----------
def encode(d):
    return BASE + urllib.parse.quote(base64.b64encode(json.dumps(d).encode("utf8")).decode())


def decode(url):
    try:
        q = url.split("?", 1)[1]
        return json.loads(base64.b64decode(urllib.parse.unquote(q)).decode("utf8"))
    except Exception:
        return {}


def listdir(url):
    """Elenco di una cartella plugin (blocca finche' s4me ha finito). None se la chiamata fallisce."""
    req = {"jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
           "params": {"directory": url, "media": "files", "properties": ["title"]}}
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception as ex:
        xbmc.log("[veloceflix] CB01: chiamata a Stream for Me fallita: %r" % (ex,), xbmc.LOGINFO)
        return None
    if "result" not in r:
        xbmc.log("[veloceflix] CB01: Stream for Me non ha risposto: %s" % json.dumps(r)[:300], xbmc.LOGINFO)
        return None
    return (r.get("result") or {}).get("files") or []


def entries(url):
    """[(url, item)] oppure None se s4me non ha risposto."""
    files = listdir(url)
    if not files:
        # una ricerca vera senza risultati da' sempre la voce "Nessun elemento da visualizzare":
        # una lista del tutto vuota vuol dire che s4me non ha risposto (es. occupato) -> non si sa
        return None
    out = []
    for f in files:
        d = decode(f.get("file", ""))
        if d:
            out.append((f.get("file"), d))
    return out


# ---------- lingua e qualita' (dalle etichette del sito) ----------
def tags(title):
    """Etichette tra parentesi quadre, maiuscole: '[B]Matrix[/B] [COLOR x][HD][/COLOR]' -> ['HD']."""
    return [t.strip().upper() for t in re.findall(r"\[([^\]]+)\]", _TAGS.sub("", title or ""))]


def is_hd(title):
    return any(re.search(r"(^|/)(HD|FHD|UHD|4K|1080P?|720P?)($|/)", t) for t in tags(title))


def is_sub(d):
    lang = (d.get("contentLanguage") or d.get("language") or "").upper()
    return "SUB" in lang or any("SUB" in t for t in tags(d.get("title")))


# ---------- ricerca del titolo ----------
def _tmdb_id(d):
    try:
        return int((d.get("infoLabels") or {}).get("tmdb_id") or 0)
    except Exception:
        return 0


def pick(items, e):
    """Risultato giusto: stesso id TMDB (o stesso titolo e anno), non Sub-ITA; per i film solo HD."""
    want_tv = e["type"] == "tv"
    best = None
    for url, d in items:
        if d.get("action") != ("episodios" if want_tv else "findvideos"):
            continue
        if is_sub(d):
            continue
        if not want_tv and not is_hd(d.get("title")):
            continue
        tid = _tmdb_id(d)
        if tid:
            if tid != int(e["id"]):
                continue
            score = 3
        else:
            name = d.get("fulltitle") or d.get("contentTitle") or ""
            if sc.norm(name) not in {sc.norm(e.get("title")), sc.norm(e.get("orig"))} - {""}:
                continue
            try:
                y1 = int((d.get("infoLabels") or {}).get("year") or 0)
                y2 = int(e.get("year") or 0)
                if y1 and y2 and abs(y1 - y2) > 1:
                    continue
            except Exception:
                pass
            score = 1
        if best is None or score > best[0]:
            best = (score, url, d)
    return (best[1], best[2]) if best else (None, None)


def find(e, status=None):
    """(url, item) del titolo su CB01; (None, None) se non c'e'; (None, False) se s4me non risponde."""
    h = host()
    if not h:
        xbmc.log("[veloceflix] CB01: indirizzo non trovato in channels.json di Stream for Me", xbmc.LOGINFO)
        return None, False
    terms = [e["title"]]
    if e.get("orig") and sc.norm(e["orig"]) != sc.norm(e["title"]):
        terms.append(e["orig"])
    tv = e["type"] == "tv"
    errors = 0
    for t in terms:
        if status:
            status('Cerco "%s" su CB01...' % t)
        q = re.sub(r"\s+", "+", t.strip())
        item = {"channel": CHANNEL, "action": "peliculas", "search": True, "folder": True,
                "contentType": "tvshow" if tv else "movie",
                "url": "%s%s/search/%s" % (h, "/serietv" if tv else "", urllib.parse.quote(q, safe="+"))}
        found = entries(encode(item))
        if found is None:
            errors += 1
            continue
        url, d = pick(found, e)
        if url:
            return url, d
    return (None, False) if errors == len(terms) else (None, None)


def check(e):
    """Per i filtri di home e ricerca: True/False, None se non verificabile (non va in cache)."""
    url, d = find(e)
    if url:
        return True
    return None if d is False else False


def episodes(show_url):
    """Episodi ITA in HD della serie: [[stagione, episodio, url, titolo]] (None se s4me non risponde)."""
    items = entries(show_url)
    if items is None:
        return None
    out = []
    for u, d in items:
        if d.get("action") != "findvideos" or is_sub(d) or not is_hd(d.get("title")):
            continue
        t = _TAGS.sub("", d.get("title", ""))
        t = re.sub(r"\[[^\]]*\]", "", t).strip()
        out.append([0, 0, u, t])
    return out
